# 🎛️ Exemplos de Comandos

## 📝 Como Usar

### **Passo 1: Escolher um exemplo**

Escolha um dos arquivos desta pasta:
- `usar_mainnet_paper.json` - **⭐ FIX dados repetidos** (usar Mainnet em modo Paper)
- `aumentar_trades.json` - Mais trades (threshold 38%)
- `reduzir_tp_sl.json` - TP/SL conservadores
- `modo_agressivo.json` - Modo agressivo
- `modo_conservador.json` - Modo conservador

### **Passo 2: Copiar para raiz**

```bash
# Exemplo: Aumentar trades
cp EXEMPLOS_COMANDOS/aumentar_trades.json bot_commands.json
```

### **Passo 3: Aguardar (2 minutos)**

Bot detecta e aplica automaticamente:
```
📝 Processando 1 mudança(s) de configuração
✓ min_trade_confidence: 0.5 → 0.38
⚙️  Configuração atualizada!
```

### **Passo 4: Deletar bot_commands.json**

O bot já deletou automaticamente após processar! ✅

---

## 📁 **Exemplos Disponíveis**

### **1. aumentar_trades.json**
```json
{
  "action": "update_config",
  "changes": {
    "min_trade_confidence": 0.38
  }
}
```
**Efeito:** Trades com 38%+ são executados

---

### **2. reduzir_tp_sl.json**
```json
{
  "action": "update_config",
  "changes": {
    "default_tp_pct": 2.0,
    "default_sl_pct": 1.0
  }
}
```
**Efeito:** TP 2%, SL 1% (conservador)

---

### **3. modo_agressivo.json**
```json
{
  "action": "update_config",
  "changes": {
    "min_trade_confidence": 0.35,
    "default_tp_pct": 2.5,
    "default_sl_pct": 1.2,
    "strategy.volume_threshold": 1.0
  }
}
```
**Efeito:** Muitos trades, TP/SL moderados

---

### **4. modo_conservador.json**
```json
{
  "action": "update_config",
  "changes": {
    "min_trade_confidence": 0.60,
    "default_tp_pct": 3.0,
    "default_sl_pct": 0.8,
    "strategy.min_pattern_confidence": 0.7
  }
}
```
**Efeito:** Poucos trades, alta confiança

---

## ⚠️ **IMPORTANTE: JSON Válido**

### ❌ **NÃO FUNCIONA (comentários):**
```json
{
  // Este é um comentário - NÃO permitido em JSON!
  "action": "update_config",
  "changes": {
    "min_trade_confidence": 0.40,  // vírgula extra aqui
  }
}
```

### ✅ **FUNCIONA (JSON puro):**
```json
{
  "action": "update_config",
  "changes": {
    "min_trade_confidence": 0.40
  }
}
```

---

## 🎯 **Criar Seu Próprio**

Crie `bot_commands.json` na raiz:
```json
{
  "action": "update_config",
  "changes": {
    "min_trade_confidence": 0.40,
    "default_tp_pct": 2.0
  }
}
```

**Regras:**
- ✅ Sem comentários (`//` ou `/* */`)
- ✅ Sem vírgulas no último item
- ✅ Aspas duplas em chaves e valores string
- ✅ Valores numéricos sem aspas

---

## 🚀 **Uso Rápido**

```bash
# Aumentar trades
cp EXEMPLOS_COMANDOS/aumentar_trades.json bot_commands.json

# Modo agressivo
cp EXEMPLOS_COMANDOS/modo_agressivo.json bot_commands.json

# Modo conservador
cp EXEMPLOS_COMANDOS/modo_conservador.json bot_commands.json
```

**Aguarde 2 min → Configuração aplicada!** ✅
