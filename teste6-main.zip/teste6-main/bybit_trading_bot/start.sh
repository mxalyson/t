#!/bin/bash
echo "Iniciando Bybit Trading Bot (Paper Mode)..."
python -m src.runner