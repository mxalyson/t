"""
✨ V3.3 - Filtros Avançados para Aumentar Win Rate
Análise de tendência, volatilidade, horários e confirmações
"""
import pandas as pd
import numpy as np
from datetime import datetime, time
import logging
from typing import Dict, Optional, Tuple

logger = logging.getLogger("Filters")


class TradingFilters:
    """Filtros avançados para melhorar win rate"""
    
    def __init__(self, config: Dict):
        self.config = config
        
        # Configurações de filtros (V3.3.5 - RELAXADOS)
        self.max_atr_ratio = 3.0  # ATR máximo (300% da média)
        self.max_spread_pct = 2.0  # Spread máximo 2.0% (era 0.15% - muito restritivo!)
        self.min_volume_ratio = 0.3  # Volume mínimo (30% da média)
        self.max_volume_ratio = 5.0  # Volume máximo (500% da média)
        
        # Horários de liquidez (UTC)
        self.liquidity_start = time(6, 0)  # 06:00 UTC
        self.liquidity_end = time(0, 0)    # 00:00 UTC (meia-noite)
        
        # Multi-timeframe rigoroso
        self.min_tf_agreement = 0.75  # 75% dos timeframes devem concordar
        
        # RSI zones (V3.3.5 - RELAXADOS)
        self.rsi_overbought = 85  # Era 70 - muitas moedas em tendência ficam >70
        self.rsi_oversold = 20   # Era 30
        
        logger.info("✅ Filtros avançados inicializados")
    
    def check_trend_alignment(self, df_daily: pd.DataFrame, signal_direction: str) -> Tuple[bool, str]:
        """
        1. ANÁLISE DE TENDÊNCIA - CRÍTICO!
        
        Verifica se trade está A FAVOR da tendência dominante
        Usa EMA 50 e EMA 200 do timeframe diário
        
        Returns:
            (allowed, reason)
        """
        try:
            if len(df_daily) < 200:
                return True, "Dados insuficientes para análise de tendência"
            
            # Calcular EMAs
            ema_50 = df_daily['close'].ewm(span=50, adjust=False).mean().iloc[-1]
            ema_200 = df_daily['close'].ewm(span=200, adjust=False).mean().iloc[-1]
            current_price = df_daily['close'].iloc[-1]
            
            # Determinar tendência
            if ema_50 > ema_200:
                trend = "bullish"
                trend_strength = (ema_50 - ema_200) / ema_200 * 100
            else:
                trend = "bearish"
                trend_strength = (ema_200 - ema_50) / ema_200 * 100
            
            logger.debug(f"Tendência: {trend} (força: {trend_strength:.2f}%)")
            
            # Verificar alinhamento
            if signal_direction == "long":
                if trend == "bullish":
                    return True, f"✅ A favor da tendência {trend} ({trend_strength:.1f}%)"
                else:
                    return False, f"⛔ Contra tendência {trend} ({trend_strength:.1f}%) - BLOQUEADO"
            
            elif signal_direction == "short":
                if trend == "bearish":
                    return True, f"✅ A favor da tendência {trend} ({trend_strength:.1f}%)"
                else:
                    return False, f"⛔ Contra tendência {trend} ({trend_strength:.1f}%) - BLOQUEADO"
            
            return True, "Direção neutra"
            
        except Exception as e:
            logger.warning(f"Erro na análise de tendência: {e}")
            return True, f"Erro: {e}"
    
    def check_volatility(self, df: pd.DataFrame) -> Tuple[bool, str]:
        """
        2. FILTRO DE VOLATILIDADE EXTREMA
        
        Bloqueia trades em volatilidade anormal (notícias, eventos)
        """
        try:
            if len(df) < 20:
                return True, "Dados insuficientes"
            
            # Calcular ATR atual e médio
            high_low = df['high'] - df['low']
            high_close = abs(df['high'] - df['close'].shift())
            low_close = abs(df['low'] - df['close'].shift())
            
            tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
            atr_current = tr.iloc[-1]
            atr_mean = tr.rolling(14).mean().iloc[-1]
            
            atr_ratio = atr_current / atr_mean if atr_mean > 0 else 1.0
            
            # Verificar spread (bid-ask)
            current = df.iloc[-1]
            spread_pct = (current['high'] - current['low']) / current['close'] * 100
            
            # Verificar volume anormal
            volume_mean = df['volume'].rolling(20).mean().iloc[-1]
            volume_ratio = current['volume'] / volume_mean if volume_mean > 0 else 1.0
            
            logger.debug(f"ATR ratio: {atr_ratio:.2f}, Spread: {spread_pct:.3f}%, Volume: {volume_ratio:.2f}x")
            
            # Filtros
            if atr_ratio > self.max_atr_ratio:
                return False, f"⛔ Volatilidade EXTREMA (ATR {atr_ratio:.1f}x) - possível notícia!"
            
            if spread_pct > self.max_spread_pct:
                return False, f"⛔ Spread muito alto ({spread_pct:.2f}%) - baixa liquidez!"
            
            if volume_ratio < self.min_volume_ratio:
                return False, f"⛔ Volume muito baixo ({volume_ratio:.1f}x) - mercado parado!"
            
            if volume_ratio > self.max_volume_ratio:
                return False, f"⛔ Volume anormal ({volume_ratio:.1f}x) - possível notícia!"
            
            return True, f"✅ Volatilidade normal (ATR {atr_ratio:.1f}x, vol {volume_ratio:.1f}x)"
            
        except Exception as e:
            logger.warning(f"Erro no filtro de volatilidade: {e}")
            return True, f"Erro: {e}"
    
    def check_liquidity_hours(self) -> Tuple[bool, str]:
        """
        3. HORÁRIOS DE LIQUIDEZ (✨ V3.3.1 - DESABILITADO - opera 24/7)
        
        Usuario quer operar sempre, sem limitação de horário
        """
        try:
            now_utc = datetime.utcnow()
            current_time = now_utc.time()
            weekday = now_utc.weekday()  # 0=Monday, 6=Sunday
            
            # ✨ V3.3.1 - REMOVIDO filtro de horário (opera 24/7)
            return True, f"✅ Opera 24/7 ({current_time.strftime('%H:%M')} UTC)"
            
        except Exception as e:
            logger.warning(f"Erro no filtro de horários: {e}")
            return True, f"Erro: {e}"
    
    def check_multi_timeframe_agreement(self, signals: Dict, min_agreement: float = None) -> Tuple[bool, str]:
        """
        4. CONFIRMAÇÃO MULTI-TIMEFRAME RIGOROSA
        
        Exige que MAIORIA dos timeframes concordem
        """
        try:
            if min_agreement is None:
                min_agreement = self.min_tf_agreement
            
            if not signals or 'timeframe_signals' not in signals:
                return True, "Sem dados de timeframes"
            
            tf_signals = signals['timeframe_signals']
            total = len(tf_signals)
            
            if total == 0:
                return True, "Nenhum timeframe"
            
            # Contar concordância
            target_direction = signals.get('signal', '').lower()
            agreements = sum(1 for tf in tf_signals.values() 
                           if tf.get('signal', '').lower() == target_direction)
            
            agreement_pct = agreements / total
            
            logger.debug(f"Multi-TF: {agreements}/{total} concordam ({agreement_pct:.1%})")
            
            # V3.3.3 - Reduzir exigência para 50% (maioria simples)
            required_agreement = max(0.5, min_agreement - 0.25)  # Reduz 25%
            
            if agreement_pct >= required_agreement:
                return True, f"✅ Multi-TF ({agreements}/{total} = {agreement_pct:.0%})"
            else:
                return False, f"⛔ Multi-TF fraco ({agreements}/{total} = {agreement_pct:.0%}) - mínimo {required_agreement:.0%}"
            
        except Exception as e:
            logger.warning(f"Erro no filtro multi-timeframe: {e}")
            return True, f"Erro: {e}"
    
    def check_momentum(self, df: pd.DataFrame, signal_direction: str) -> Tuple[bool, str]:
        """
        5. ANÁLISE DE MOMENTUM RIGOROSA
        
        RSI em zona válida, MACD confirmando, sem divergências
        """
        try:
            if len(df) < 26:
                return True, "Dados insuficientes"
            
            # Calcular RSI
            delta = df['close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            rsi_current = rsi.iloc[-1]
            
            # Calcular MACD
            ema_12 = df['close'].ewm(span=12, adjust=False).mean()
            ema_26 = df['close'].ewm(span=26, adjust=False).mean()
            macd = ema_12 - ema_26
            signal_line = macd.ewm(span=9, adjust=False).mean()
            macd_hist = macd - signal_line
            
            macd_current = macd.iloc[-1]
            signal_current = signal_line.iloc[-1]
            hist_current = macd_hist.iloc[-1]
            
            logger.debug(f"RSI: {rsi_current:.1f}, MACD: {hist_current:.2f}")
            
            # Validações
            issues = []
            
            # RSI em zona extrema = reversão provável
            if signal_direction == "long" and rsi_current > self.rsi_overbought:
                issues.append(f"RSI sobrecomprado ({rsi_current:.0f})")
            
            if signal_direction == "short" and rsi_current < self.rsi_oversold:
                issues.append(f"RSI sobrevendido ({rsi_current:.0f})")
            
            # MACD deve confirmar direção
            if signal_direction == "long" and hist_current < 0:
                issues.append(f"MACD bearish ({hist_current:.2f})")
            
            if signal_direction == "short" and hist_current > 0:
                issues.append(f"MACD bullish ({hist_current:.2f})")
            
            # Se houver problemas, bloquear
            if issues:
                return False, f"⛔ Momentum fraco: {', '.join(issues)}"
            
            return True, f"✅ Momentum forte (RSI {rsi_current:.0f}, MACD {hist_current:+.2f})"
            
        except Exception as e:
            logger.warning(f"Erro na análise de momentum: {e}")
            return True, f"Erro: {e}"
    
    def apply_all_filters(self, 
                         df: pd.DataFrame, 
                         df_daily: pd.DataFrame,
                         signal: Dict) -> Tuple[bool, Dict[str, str]]:
        """
        Aplica TODOS os filtros
        
        Returns:
            (allowed, reasons)
        """
        results = {}
        signal_direction = signal.get('signal', '').lower()
        
        # 1. Tendência
        trend_ok, trend_msg = self.check_trend_alignment(df_daily, signal_direction)
        results['trend'] = trend_msg
        
        # 2. Volatilidade
        vol_ok, vol_msg = self.check_volatility(df)
        results['volatility'] = vol_msg
        
        # 3. Horários
        hours_ok, hours_msg = self.check_liquidity_hours()
        results['hours'] = hours_msg
        
        # 4. Multi-timeframe
        mtf_ok, mtf_msg = self.check_multi_timeframe_agreement(signal)
        results['multi_tf'] = mtf_msg
        
        # 5. Momentum
        momentum_ok, momentum_msg = self.check_momentum(df, signal_direction)
        results['momentum'] = momentum_msg
        
        # Todos devem passar
        all_ok = all([trend_ok, vol_ok, hours_ok, mtf_ok, momentum_ok])
        
        return all_ok, results
