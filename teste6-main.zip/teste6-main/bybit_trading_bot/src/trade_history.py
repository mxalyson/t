"""
Sistema de Histórico e ML Básico para Trading
Aprende com trades passados para melhorar assertividade
"""
import json
import os
from datetime import datetime
from typing import Dict, List
from collections import defaultdict
from .utils import setup_logger

logger = setup_logger("trade_history")


class TradeHistory:
    """Gerencia histórico de trades e aprendizado"""
    
    def __init__(self, history_file: str = "trade_history.json"):
        self.history_file = history_file
        self.trades = self.load_history()
        self.pattern_stats = defaultdict(lambda: {'wins': 0, 'losses': 0, 'total_pnl': 0})
        self.symbol_stats = defaultdict(lambda: {'wins': 0, 'losses': 0, 'total_pnl': 0})
        self._calculate_stats()
    
    def load_history(self) -> List[Dict]:
        """Carrega histórico do arquivo"""
        if not os.path.exists(self.history_file):
            return []
        
        try:
            with open(self.history_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Erro ao carregar histórico: {e}")
            return []
    
    def save_history(self):
        """Salva histórico no arquivo"""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.trades, f, indent=2)
        except Exception as e:
            logger.error(f"Erro ao salvar histórico: {e}")
    
    def _calculate_stats(self):
        """Calcula estatísticas de padrões e símbolos"""
        for trade in self.trades:
            pattern = trade.get('pattern', 'unknown')
            symbol = trade.get('symbol', 'unknown')
            pnl = trade.get('pnl', 0)
            
            # Stats por padrão
            if pnl > 0:
                self.pattern_stats[pattern]['wins'] += 1
            else:
                self.pattern_stats[pattern]['losses'] += 1
            self.pattern_stats[pattern]['total_pnl'] += pnl
            
            # Stats por símbolo
            if pnl > 0:
                self.symbol_stats[symbol]['wins'] += 1
            else:
                self.symbol_stats[symbol]['losses'] += 1
            self.symbol_stats[symbol]['total_pnl'] += pnl
    
    def add_trade(self, trade_data: Dict):
        """Adiciona novo trade ao histórico"""
        trade_data['timestamp'] = datetime.now().isoformat()
        self.trades.append(trade_data)
        self.save_history()
        
        # Atualizar stats
        self._calculate_stats()
        
        logger.info(f"Trade registrado: {trade_data.get('symbol')} {trade_data.get('direction')} PnL: {trade_data.get('pnl', 0):.2f}")
    
    def get_pattern_win_rate(self, pattern: str) -> float:
        """Retorna win rate de um padrão (0-1)"""
        if pattern not in self.pattern_stats:
            return 0.5  # Neutro se não tem dados
        
        stats = self.pattern_stats[pattern]
        total = stats['wins'] + stats['losses']
        
        if total == 0:
            return 0.5
        
        return stats['wins'] / total
    
    def get_symbol_win_rate(self, symbol: str) -> float:
        """Retorna win rate de um símbolo (0-1)"""
        if symbol not in self.symbol_stats:
            return 0.5
        
        stats = self.symbol_stats[symbol]
        total = stats['wins'] + stats['losses']
        
        if total == 0:
            return 0.5
        
        return stats['wins'] / total
    
    def should_trade_pattern(self, pattern: str, min_win_rate: float = 0.40) -> bool:
        """
        Verifica se deve negociar um padrão baseado em histórico
        
        Args:
            pattern: Nome do padrão
            min_win_rate: Win rate mínimo aceitável (padrão 40%)
        
        Returns:
            True se deve negociar, False se padrão tem histórico ruim
        """
        stats = self.pattern_stats.get(pattern)
        
        if not stats:
            return True  # Se não tem dados, permitir
        
        total_trades = stats['wins'] + stats['losses']
        
        # Precisa de pelo menos 5 trades para blacklist
        if total_trades < 5:
            return True
        
        win_rate = stats['wins'] / total_trades
        
        if win_rate < min_win_rate:
            logger.warning(
                f"❌ Padrão '{pattern}' blacklisted: "
                f"WR={win_rate:.1%} ({stats['wins']}W/{stats['losses']}L)"
            )
            return False
        
        return True
    
    def get_adjusted_confidence(self, pattern: str, symbol: str, base_confidence: float) -> float:
        """
        Ajusta confiança baseado em histórico
        
        Args:
            pattern: Nome do padrão
            symbol: Símbolo
            base_confidence: Confiança base (0-1)
        
        Returns:
            Confiança ajustada (0-1)
        """
        pattern_wr = self.get_pattern_win_rate(pattern)
        symbol_wr = self.get_symbol_win_rate(symbol)
        
        # Peso: 50% base, 30% padrão, 20% símbolo
        adjusted = (
            base_confidence * 0.50 +
            pattern_wr * 0.30 +
            symbol_wr * 0.20
        )
        
        # Log se houver ajuste significativo
        if abs(adjusted - base_confidence) > 0.05:
            logger.info(
                f"🎯 Confiança ajustada: {base_confidence:.1%} → {adjusted:.1%} "
                f"(Padrão WR: {pattern_wr:.1%}, Símbolo WR: {symbol_wr:.1%})"
            )
        
        return adjusted
    
    def get_summary(self) -> str:
        """Retorna resumo do histórico"""
        if not self.trades:
            return "📊 Sem histórico de trades ainda"
        
        total_trades = len(self.trades)
        total_wins = sum(1 for t in self.trades if t.get('pnl', 0) > 0)
        total_losses = total_trades - total_wins
        total_pnl = sum(t.get('pnl', 0) for t in self.trades)
        win_rate = total_wins / total_trades if total_trades > 0 else 0
        
        summary = f"""
╔══════════════════════════════════════════════════════════╗
║              📊 HISTÓRICO DE TRADES                      ║
╚══════════════════════════════════════════════════════════╝

Total Trades: {total_trades}
Wins: {total_wins} ({win_rate:.1%})
Losses: {total_losses}
PnL Total: {total_pnl:+.2f} USDT

Top 3 Melhores Padrões:
"""
        
        # Top 3 padrões por win rate (com mínimo de 3 trades)
        patterns_sorted = sorted(
            [(p, s) for p, s in self.pattern_stats.items() if s['wins'] + s['losses'] >= 3],
            key=lambda x: x[1]['wins'] / (x[1]['wins'] + x[1]['losses']),
            reverse=True
        )[:3]
        
        for i, (pattern, stats) in enumerate(patterns_sorted, 1):
            total = stats['wins'] + stats['losses']
            wr = stats['wins'] / total
            summary += f"  {i}. {pattern}: {wr:.1%} ({stats['wins']}W/{stats['losses']}L)\n"
        
        # Piores padrões
        patterns_worst = sorted(
            [(p, s) for p, s in self.pattern_stats.items() if s['wins'] + s['losses'] >= 3],
            key=lambda x: x[1]['wins'] / (x[1]['wins'] + x[1]['losses'])
        )[:3]
        
        summary += "\nTop 3 Piores Padrões (evitar):\n"
        for i, (pattern, stats) in enumerate(patterns_worst, 1):
            total = stats['wins'] + stats['losses']
            wr = stats['wins'] / total
            summary += f"  {i}. {pattern}: {wr:.1%} ({stats['wins']}W/{stats['losses']}L) ❌\n"
        
        summary += "\n╚══════════════════════════════════════════════════════════╝"
        
        return summary
