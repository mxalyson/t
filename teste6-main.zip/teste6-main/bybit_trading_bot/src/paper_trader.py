"""
Paper Trading System - Simula trades e calcula PnL real
"""
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional
import os

logger = logging.getLogger("PaperTrader")


class PaperTrader:
    """Gerencia trades simulados em paper mode com tracking de PnL"""
    
    def __init__(self, initial_balance: float = 10000.0):
        self.initial_balance = initial_balance
        self.balance = initial_balance
        self.positions: Dict[str, dict] = {}  # Posições abertas
        self.closed_trades: List[dict] = []  # Histórico de trades fechados
        self.trade_counter = 0
        
        # Arquivo para persistir trades
        self.trades_file = "paper_trades.json"
        self.load_trades()
        
        logger.info(f"📝 Paper Trader inicializado | Saldo inicial: ${self.balance:.2f}")
    
    def load_trades(self):
        """Carrega trades anteriores do arquivo"""
        if os.path.exists(self.trades_file):
            try:
                with open(self.trades_file, 'r') as f:
                    data = json.load(f)
                    self.balance = data.get('balance', self.initial_balance)
                    self.positions = data.get('positions', {})
                    self.closed_trades = data.get('closed_trades', [])
                    self.trade_counter = data.get('trade_counter', 0)
                    logger.info(f"📂 Carregados {len(self.closed_trades)} trades do histórico")
            except Exception as e:
                logger.error(f"Erro ao carregar trades: {e}")
    
    def save_trades(self):
        """Salva trades no arquivo"""
        try:
            data = {
                'balance': self.balance,
                'initial_balance': self.initial_balance,
                'positions': self.positions,
                'closed_trades': self.closed_trades,
                'trade_counter': self.trade_counter,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.trades_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Erro ao salvar trades: {e}")
    
    def open_position(self, symbol: str, side: str, entry_price: float, 
                     quantity: float, take_profit: float, stop_loss: float,
                     margin: float, pattern: str = "", confidence: float = 0.0) -> dict:
        """Abre uma posição simulada"""
        self.trade_counter += 1
        
        position = {
            'trade_id': self.trade_counter,
            'symbol': symbol,
            'side': side,  # Buy ou Sell
            'entry_price': entry_price,
            'quantity': quantity,
            'take_profit': take_profit,
            'stop_loss': stop_loss,
            'margin': margin,
            'notional': entry_price * quantity,
            'pattern': pattern,
            'confidence': confidence,
            'open_time': datetime.now().isoformat(),
            'unrealized_pnl': 0.0
        }
        
        self.positions[symbol] = position
        self.save_trades()
        
        logger.info(
            f"📝 [PAPER] Posição aberta: {side} {symbol} @ ${entry_price:.2f} | "
            f"TP: ${take_profit:.2f} | SL: ${stop_loss:.2f} | Margem: ${margin:.2f}"
        )
        
        return position
    
    def update_position(self, symbol: str, current_price: float) -> Optional[dict]:
        """Atualiza PnL da posição e verifica TP/SL"""
        if symbol not in self.positions:
            return None
        
        position = self.positions[symbol]
        entry_price = position['entry_price']
        quantity = position['quantity']
        side = position['side']
        
        # Calcular PnL
        if side == 'Buy':
            # Long: lucro quando preço sobe
            pnl = (current_price - entry_price) * quantity
            pnl_pct = ((current_price - entry_price) / entry_price) * 100
        else:
            # Short: lucro quando preço desce
            pnl = (entry_price - current_price) * quantity
            pnl_pct = ((entry_price - current_price) / entry_price) * 100
        
        position['unrealized_pnl'] = pnl
        position['current_price'] = current_price
        position['pnl_pct'] = pnl_pct
        
        # Verificar TP/SL
        tp_hit = False
        sl_hit = False
        
        if side == 'Buy':
            tp_hit = current_price >= position['take_profit']
            sl_hit = current_price <= position['stop_loss']
        else:
            tp_hit = current_price <= position['take_profit']
            sl_hit = current_price >= position['stop_loss']
        
        if tp_hit:
            self.close_position(symbol, position['take_profit'], reason='TP atingido')
            return {'status': 'tp_hit', 'pnl': pnl}
        elif sl_hit:
            self.close_position(symbol, position['stop_loss'], reason='SL atingido')
            return {'status': 'sl_hit', 'pnl': pnl}
        
        return {'status': 'open', 'pnl': pnl}
    
    def close_position(self, symbol: str, exit_price: float, reason: str = "Manual"):
        """Fecha uma posição e calcula PnL final"""
        if symbol not in self.positions:
            return
        
        position = self.positions[symbol]
        entry_price = position['entry_price']
        quantity = position['quantity']
        side = position['side']
        
        # Calcular PnL final
        if side == 'Buy':
            pnl = (exit_price - entry_price) * quantity
            pnl_pct = ((exit_price - entry_price) / entry_price) * 100
        else:
            pnl = (entry_price - exit_price) * quantity
            pnl_pct = ((entry_price - exit_price) / entry_price) * 100
        
        # Calcular ROI (retorno sobre margem investida)
        roi = (pnl / position['margin']) * 100 if position['margin'] > 0 else 0
        
        # Atualizar saldo
        self.balance += pnl
        
        # Criar registro de trade fechado
        closed_trade = {
            **position,
            'exit_price': exit_price,
            'exit_time': datetime.now().isoformat(),
            'realized_pnl': pnl,
            'pnl_pct': pnl_pct,
            'roi': roi,
            'reason': reason,
            'duration_minutes': self._calculate_duration(position['open_time'])
        }
        
        self.closed_trades.append(closed_trade)
        del self.positions[symbol]
        self.save_trades()
        
        # Log colorido baseado em resultado
        emoji = "💰" if pnl > 0 else "🛑"
        logger.warning(
            f"{emoji} [PAPER] Posição fechada: {symbol} | "
            f"Razão: {reason} | "
            f"PnL: ${pnl:+.2f} ({pnl_pct:+.2f}%) | "
            f"ROI: {roi:+.2f}% | "
            f"Novo saldo: ${self.balance:.2f}"
        )
    
    def _calculate_duration(self, open_time_str: str) -> int:
        """Calcula duração do trade em minutos"""
        try:
            open_time = datetime.fromisoformat(open_time_str)
            duration = datetime.now() - open_time
            return int(duration.total_seconds() / 60)
        except:
            return 0
    
    def get_stats(self) -> dict:
        """Retorna estatísticas completas"""
        if not self.closed_trades:
            return {
                'total_trades': 0,
                'wins': 0,
                'losses': 0,
                'win_rate': 0,
                'total_pnl': 0,
                'total_pnl_pct': 0,
                'avg_win': 0,
                'avg_loss': 0,
                'best_trade': 0,
                'worst_trade': 0,
                'current_balance': self.balance,
                'initial_balance': self.initial_balance,
                'open_positions': len(self.positions),
                'unrealized_pnl': sum(p.get('unrealized_pnl', 0) for p in self.positions.values())
            }
        
        wins = [t for t in self.closed_trades if t['realized_pnl'] > 0]
        losses = [t for t in self.closed_trades if t['realized_pnl'] <= 0]
        
        total_pnl = sum(t['realized_pnl'] for t in self.closed_trades)
        total_pnl_pct = ((self.balance - self.initial_balance) / self.initial_balance) * 100
        
        return {
            'total_trades': len(self.closed_trades),
            'wins': len(wins),
            'losses': len(losses),
            'win_rate': (len(wins) / len(self.closed_trades)) * 100 if self.closed_trades else 0,
            'total_pnl': total_pnl,
            'total_pnl_pct': total_pnl_pct,
            'avg_win': sum(t['realized_pnl'] for t in wins) / len(wins) if wins else 0,
            'avg_loss': sum(t['realized_pnl'] for t in losses) / len(losses) if losses else 0,
            'best_trade': max(t['realized_pnl'] for t in self.closed_trades),
            'worst_trade': min(t['realized_pnl'] for t in self.closed_trades),
            'avg_roi': sum(t['roi'] for t in self.closed_trades) / len(self.closed_trades),
            'current_balance': self.balance,
            'initial_balance': self.initial_balance,
            'open_positions': len(self.positions),
            'unrealized_pnl': sum(p.get('unrealized_pnl', 0) for p in self.positions.values())
        }
    
    def print_summary(self):
        """Imprime resumo visual das estatísticas"""
        stats = self.get_stats()
        
        print("\n" + "="*60)
        print("📊 PAPER TRADING - RESUMO DE PERFORMANCE")
        print("="*60)
        print(f"💰 Saldo Inicial:  ${stats['initial_balance']:.2f}")
        print(f"💵 Saldo Atual:    ${stats['current_balance']:.2f}")
        print(f"📈 PnL Total:      ${stats['total_pnl']:+.2f} ({stats['total_pnl_pct']:+.2f}%)")
        print(f"📊 Trades:         {stats['total_trades']} (✅ {stats['wins']} | ❌ {stats['losses']})")
        print(f"🎯 Win Rate:       {stats['win_rate']:.1f}%")
        
        if stats['total_trades'] > 0:
            print(f"💰 Média Win:      ${stats['avg_win']:+.2f}")
            print(f"🛑 Média Loss:     ${stats['avg_loss']:+.2f}")
            print(f"🏆 Melhor Trade:   ${stats['best_trade']:+.2f}")
            print(f"💔 Pior Trade:     ${stats['worst_trade']:+.2f}")
            print(f"📊 ROI Médio:      {stats['avg_roi']:+.2f}%")
        
        if stats['open_positions'] > 0:
            print(f"📂 Posições Abertas: {stats['open_positions']}")
            print(f"💹 PnL Não Realizado: ${stats['unrealized_pnl']:+.2f}")
        
        print("="*60 + "\n")
    
    def get_recent_trades(self, limit: int = 5) -> List[dict]:
        """Retorna últimos N trades fechados"""
        return self.closed_trades[-limit:] if self.closed_trades else []
