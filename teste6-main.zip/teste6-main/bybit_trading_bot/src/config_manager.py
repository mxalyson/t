"""
Gerenciador de Configuração Dinâmica
Permite alterar configurações sem reiniciar o bot
"""
import json
import os
from typing import Dict, Any
from .utils import setup_logger

logger = setup_logger("config_manager")


class ConfigManager:
    """Gerencia configurações dinâmicas do bot"""
    
    def __init__(self, config_path: str = "config.json"):
        self.config_path = config_path
        self.config = self.load_config()
        self.command_file = "bot_commands.json"
    
    def load_config(self) -> Dict:
        """Carrega configuração do arquivo"""
        try:
            with open(self.config_path, 'r') as f:
                config = json.load(f)
            return config
        except Exception as e:
            logger.error(f"Erro ao carregar config: {e}")
            return {}
    
    def save_config(self, config: Dict) -> bool:
        """Salva configuração no arquivo"""
        try:
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2)
            logger.info("✓ Configuração salva com sucesso")
            return True
        except Exception as e:
            logger.error(f"Erro ao salvar config: {e}")
            return False
    
    def reload_config(self) -> Dict:
        """Recarrega configuração do arquivo"""
        self.config = self.load_config()
        logger.info("✓ Configuração recarregada")
        return self.config
    
    def update_setting(self, key: str, value: Any) -> bool:
        """
        Atualiza uma configuração específica
        
        Exemplos:
            update_setting('min_trade_confidence', 0.45)
            update_setting('leverage', 10)
            update_setting('strategy.min_pattern_confidence', 0.65)
        """
        try:
            # Suportar chaves aninhadas (ex: 'strategy.min_pattern_confidence')
            keys = key.split('.')
            config = self.config
            
            # Navegar até o último nível
            for k in keys[:-1]:
                if k not in config:
                    config[k] = {}
                config = config[k]
            
            # Atualizar valor
            old_value = config.get(keys[-1], None)
            config[keys[-1]] = value
            
            # Salvar
            if self.save_config(self.config):
                logger.info(f"✓ {key}: {old_value} → {value}")
                return True
            
            return False
        
        except Exception as e:
            logger.error(f"Erro ao atualizar {key}: {e}")
            return False
    
    def check_commands(self) -> Dict:
        """
        Verifica se há comandos pendentes em bot_commands.json
        
        Formato do arquivo:
        {
          "action": "update_config",
          "changes": {
            "min_trade_confidence": 0.40,
            "leverage": 10,
            "strategy.volume_threshold": 1.5
          }
        }
        """
        if not os.path.exists(self.command_file):
            return {}
        
        try:
            with open(self.command_file, 'r') as f:
                content = f.read().strip()
                
                # Ignorar se arquivo vazio
                if not content:
                    os.remove(self.command_file)
                    return {}
                
                commands = json.loads(content)
            
            # Processar comandos
            if commands.get('action') == 'update_config':
                changes = commands.get('changes', {})
                
                if not changes:
                    logger.warning("Nenhuma mudança especificada no comando")
                    os.remove(self.command_file)
                    return {}
                
                logger.info(f"📝 Processando {len(changes)} mudança(s) de configuração")
                
                for key, value in changes.items():
                    self.update_setting(key, value)
                
                # Remover arquivo de comando após processar
                os.remove(self.command_file)
                logger.info("✓ Comandos processados e arquivo removido")
                
                return {'status': 'success', 'changes': changes}
            
            return commands
        
        except json.JSONDecodeError as e:
            logger.error(f"❌ Erro no JSON de bot_commands.json: {e}")
            logger.error(f"   Linha {e.lineno}, coluna {e.colno}")
            logger.error(f"   Use apenas JSON válido (sem comentários ou vírgulas extras)")
            
            # Renomear arquivo inválido em vez de deletar
            try:
                os.rename(self.command_file, f"{self.command_file}.invalid")
                logger.info(f"   Arquivo inválido renomeado para {self.command_file}.invalid")
            except:
                pass
            
            return {}
        
        except Exception as e:
            logger.error(f"Erro ao processar comandos: {e}")
            return {}
    
    def get_summary(self) -> str:
        """Retorna resumo das configurações principais"""
        summary = f"""
╔══════════════════════════════════════════════════════════╗
║             CONFIGURAÇÕES ATUAIS DO BOT                 ║
╚══════════════════════════════════════════════════════════╝

Trading:
  • Modo: {self.config.get('trading_mode', 'N/A')}
  • Testnet: {self.config.get('testnet', False)}
  • Leverage: {self.config.get('leverage', 5)}x
  • Min Confidence: {self.config.get('min_trade_confidence', 0.5)*100:.0f}%
  • Max Trades: {self.config.get('max_total_open_trades', 3)}

Estratégia:
  • Pattern Confidence: {self.config.get('strategy', {}).get('min_pattern_confidence', 0.6)*100:.0f}%
  • Volume Threshold: {self.config.get('strategy', {}).get('volume_threshold', 1.2):.1f}x
  • Trailing Stop: {self.config.get('strategy', {}).get('use_trailing_stop', False)}

Risk:
  • TP: {self.config.get('default_tp_pct', 2.0):.1f}%
  • SL: {self.config.get('default_sl_pct', 1.0):.1f}%
  • Max Daily Loss: {self.config.get('risk', {}).get('max_daily_loss_pct', 5.0):.1f}%
  • Use ATR for SL: {self.config.get('risk', {}).get('use_atr_for_sl', True)}

Símbolos: {', '.join(self.config.get('symbols', []))}
Timeframes: {', '.join(self.config.get('timeframes', []))}

╚══════════════════════════════════════════════════════════╝
        """
        return summary
