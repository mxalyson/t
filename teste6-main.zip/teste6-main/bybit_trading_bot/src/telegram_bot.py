"""
Módulo de notificações Telegram
Envia alertas sobre trades, erros e eventos importantes
"""
import asyncio
from typing import Dict, Optional
from telegram import Bot
from telegram.error import TelegramError
from .utils import setup_logger

logger = setup_logger("telegram")


class TelegramNotifier:
    """Classe para enviar notificações via Telegram"""
    
    def __init__(self, config: Dict):
        self.token = config.get('token', '')
        self.chat_id = config.get('chat_id', '')
        
        if not self.token or not self.chat_id:
            logger.warning("Token ou chat_id do Telegram não configurados")
            self.enabled = False
            return
        
        self.bot = Bot(token=self.token)
        self.enabled = True
        
        logger.info("TelegramNotifier inicializado")
    
    async def send_message(
        self,
        message: str,
        parse_mode: str = 'HTML',
        disable_notification: bool = False
    ) -> bool:
        """
        Envia mensagem via Telegram
        
        Args:
            message: Texto da mensagem
            parse_mode: 'HTML' ou 'Markdown'
            disable_notification: Se True, não notifica
        
        Returns:
            bool: True se enviado com sucesso
        """
        if not self.enabled:
            return False
        
        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode=parse_mode,
                disable_notification=disable_notification
            )
            
            logger.debug(f"Mensagem enviada: {message[:50]}...")
            return True
        
        except TelegramError as e:
            logger.error(f"Erro ao enviar mensagem Telegram: {e}")
            return False
        
        except Exception as e:
            logger.error(f"Erro inesperado ao enviar mensagem: {e}")
            return False
    
    async def send_trade_alert(
        self,
        symbol: str,
        side: str,
        entry: float,
        tp: float,
        sl: float,
        quantity: float,
        confidence: float
    ):
        """Envia alerta de entrada em trade"""
        message = (
            f"🎯 <b>ENTRADA - {symbol}</b>\n\n"
            f"<b>Lado:</b> {side}\n"
            f"<b>Quantidade:</b> {quantity:.4f}\n"
            f"<b>Entry:</b> {entry:.2f}\n"
            f"<b>Take Profit:</b> {tp:.2f} (+{abs(tp-entry)/entry*100:.2f}%)\n"
            f"<b>Stop Loss:</b> {sl:.2f} (-{abs(entry-sl)/entry*100:.2f}%)\n"
            f"<b>Confiança:</b> {confidence:.1%}\n"
        )
        
        await self.send_message(message)
    
    async def send_close_alert(
        self,
        symbol: str,
        pnl: float,
        pnl_pct: float,
        reason: str,
        entry: float,
        exit: float
    ):
        """Envia alerta de fechamento de posição"""
        emoji = "✅" if pnl > 0 else "❌"
        
        message = (
            f"{emoji} <b>FECHAMENTO - {symbol}</b>\n\n"
            f"<b>Motivo:</b> {reason}\n"
            f"<b>Entry:</b> {entry:.2f}\n"
            f"<b>Exit:</b> {exit:.2f}\n"
            f"<b>PnL:</b> {pnl:.2f} USDT ({pnl_pct:+.2f}%)\n"
        )
        
        await self.send_message(message)
    
    async def send_error_alert(self, error: str):
        """Envia alerta de erro"""
        message = f"⚠️ <b>ERRO</b>\n\n{error}"
        await self.send_message(message)
    
    async def send_daily_summary(
        self,
        trades: int,
        wins: int,
        losses: int,
        total_pnl: float,
        balance: float
    ):
        """Envia resumo diário"""
        winrate = (wins / trades * 100) if trades > 0 else 0
        
        message = (
            f"📊 <b>RESUMO DIÁRIO</b>\n\n"
            f"<b>Trades:</b> {trades}\n"
            f"<b>Ganhos:</b> {wins}\n"
            f"<b>Perdas:</b> {losses}\n"
            f"<b>Win Rate:</b> {winrate:.1f}%\n"
            f"<b>PnL Total:</b> {total_pnl:+.2f} USDT\n"
            f"<b>Saldo:</b> {balance:.2f} USDT\n"
        )
        
        await self.send_message(message)
    
    async def test_connection(self) -> bool:
        """Testa conexão com Telegram"""
        if not self.enabled:
            logger.warning("Telegram não habilitado")
            return False
        
        try:
            await self.bot.get_me()
            logger.info("Conexão com Telegram OK")
            return True
        
        except Exception as e:
            logger.error(f"Falha ao conectar Telegram: {e}")
            return False