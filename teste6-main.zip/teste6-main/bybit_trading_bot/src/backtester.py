"""
Módulo de backtesting
Testa estratégia com dados históricos
"""
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List
import pandas as pd
import numpy as np
from .exchange import BybitExchange
from .strategy import TradingStrategy
from .risk import RiskManager
from .indicators import IndicatorSignals
from .utils import setup_logger, calculate_pnl_pct

logger = setup_logger("backtester")


class Backtester:
    """Classe para backtesting da estratégia"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.strategy = TradingStrategy(config)
        self.risk_manager = RiskManager(config)
        
        # Parâmetros de backtest
        self.initial_balance = 10000.0  # USDT
        self.balance = self.initial_balance
        self.leverage = config.get('leverage', 5)
        
        # Histórico de trades
        self.trades: List[Dict] = []
        self.equity_curve: List[float] = []
        
        logger.info("Backtester inicializado")
    
    async def fetch_historical_data(
        self,
        symbol: str,
        timeframe: str,
        days: int = 30
    ) -> pd.DataFrame:
        """Obtém dados históricos"""
        logger.info(f"Baixando dados históricos: {symbol} {timeframe} ({days} dias)")
        
        exchange = BybitExchange(self.config)
        
        try:
            # Calcular quantos candles precisamos
            tf_minutes = {
                '15m': 15,
                '1h': 60,
                '2h': 120,
                '4h': 240
            }
            
            minutes = tf_minutes.get(timeframe, 60)
            candles_needed = int((days * 24 * 60) / minutes)
            
            # Bybit limita a 200 por request
            all_klines = []
            remaining = candles_needed
            
            while remaining > 0:
                limit = min(200, remaining)
                
                klines = await exchange.get_klines(symbol, timeframe, limit=limit)
                
                if not klines:
                    break
                
                all_klines.extend(klines)
                remaining -= len(klines)
                
                if len(klines) < limit:
                    break
                
                await asyncio.sleep(0.5)  # Rate limit
            
            await exchange.close()
            
            if not all_klines:
                logger.error(f"Nenhum dado obtido para {symbol}")
                return pd.DataFrame()
            
            # Converter para DataFrame
            df = pd.DataFrame(all_klines)
            
            # Remover duplicatas
            df = df.drop_duplicates(subset=['timestamp'], keep='first')
            df = df.sort_values('timestamp').reset_index(drop=True)
            
            # Calcular indicadores
            df = IndicatorSignals.calculate_all_indicators(df)
            
            logger.info(f"Dados obtidos: {len(df)} candles")
            
            return df
        
        except Exception as e:
            logger.error(f"Erro ao obter dados históricos: {e}")
            return pd.DataFrame()
    
    def simulate_trade(
        self,
        symbol: str,
        signal: Dict,
        current_bar: pd.Series,
        next_bars: pd.DataFrame
    ) -> Dict:
        """
        Simula uma trade e retorna resultado
        
        Args:
            symbol: Par negociado
            signal: Sinal de entrada
            current_bar: Barra atual (entrada)
            next_bars: Barras seguintes (para simular saída)
        
        Returns:
            dict: Resultado da trade
        """
        entry_price = signal['entry_price']
        take_profit = signal['take_profit']
        stop_loss = signal['stop_loss']
        direction = signal['signal']
        
        # Calcular position size
        position_size = self.risk_manager.calculate_position_size(
            balance=self.balance,
            entry_price=entry_price,
            stop_loss=stop_loss,
            symbol=symbol
        )
        
        quantity = position_size['quantity']
        margin = position_size['margin']
        
        # Validar
        is_valid, msg = self.risk_manager.validate_trade_params(
            balance=self.balance,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            quantity=quantity
        )
        
        if not is_valid:
            return None
        
        # Simular execução nas próximas barras
        is_long = direction == 'long'
        exit_price = None
        exit_reason = None
        bars_held = 0
        
        for idx, bar in next_bars.iterrows():
            bars_held += 1
            
            # Verificar SL/TP
            if is_long:
                if bar['low'] <= stop_loss:
                    exit_price = stop_loss
                    exit_reason = 'Stop Loss'
                    break
                elif bar['high'] >= take_profit:
                    exit_price = take_profit
                    exit_reason = 'Take Profit'
                    break
            else:  # Short
                if bar['high'] >= stop_loss:
                    exit_price = stop_loss
                    exit_reason = 'Stop Loss'
                    break
                elif bar['low'] <= take_profit:
                    exit_price = take_profit
                    exit_reason = 'Take Profit'
                    break
            
            # Limite máximo de barras (não segurar posição infinitamente)
            if bars_held >= 50:
                exit_price = bar['close']
                exit_reason = 'Tempo máximo'
                break
        
        # Se não fechou, usar última barra
        if exit_price is None:
            exit_price = next_bars.iloc[-1]['close']
            exit_reason = 'Fim do período'
        
        # Calcular PnL
        pnl_pct = calculate_pnl_pct(entry_price, exit_price, is_long)
        pnl_usdt = margin * (pnl_pct / 100) * self.leverage
        
        # Atualizar saldo
        self.balance += pnl_usdt
        self.equity_curve.append(self.balance)
        
        # Registrar trade
        trade = {
            'symbol': symbol,
            'direction': direction,
            'entry_price': entry_price,
            'exit_price': exit_price,
            'exit_reason': exit_reason,
            'quantity': quantity,
            'margin': margin,
            'pnl_pct': pnl_pct,
            'pnl_usdt': pnl_usdt,
            'bars_held': bars_held,
            'entry_time': current_bar['timestamp'],
            'confidence': signal['confidence']
        }
        
        self.trades.append(trade)
        
        logger.debug(
            f"Trade: {direction.upper()} {symbol} @ {entry_price:.2f} -> {exit_price:.2f} "
            f"({exit_reason}) = {pnl_pct:+.2f}% ({pnl_usdt:+.2f} USDT)"
        )
        
        return trade
    
    async def run_backtest(
        self,
        symbol: str,
        timeframe: str,
        days: int = 30
    ) -> Dict:
        """
        Executa backtest completo
        
        Returns:
            dict: Relatório com métricas
        """
        logger.info(f"Iniciando backtest: {symbol} {timeframe} ({days} dias)")
        
        # Reset estado
        self.balance = self.initial_balance
        self.trades = []
        self.equity_curve = [self.initial_balance]
        
        # Obter dados
        df = await self.fetch_historical_data(symbol, timeframe, days)
        
        if df.empty or len(df) < 100:
            logger.error("Dados insuficientes para backtest")
            return {}
        
        # Iterar pelas barras
        logger.info(f"Simulando trades em {len(df)} barras...")
        
        for i in range(100, len(df) - 50):  # Deixar espaço para trades serem fechadas
            # Dados até a barra atual
            historical_data = df.iloc[:i+1].copy()
            
            # Analisar mercado
            signal = self.strategy.analyze_market(symbol, timeframe, historical_data)
            
            # Se sinal válido, simular trade
            if signal['signal'] in ['long', 'short'] and signal['confidence'] > 0.6:
                # Barras futuras para simular saída
                future_bars = df.iloc[i+1:i+51]
                
                trade = self.simulate_trade(
                    symbol, signal, df.iloc[i], future_bars
                )
                
                # Se trade executado, pular barras (não abrir múltiplas trades simultâneas)
                if trade:
                    i += trade['bars_held']
        
        # Gerar relatório
        report = self.generate_report()
        
        logger.info("Backtest concluído")
        self.print_report(report)
        
        return report
    
    def generate_report(self) -> Dict:
        """Gera relatório de métricas"""
        if not self.trades:
            return {
                'total_trades': 0,
                'message': 'Nenhuma trade executada'
            }
        
        df_trades = pd.DataFrame(self.trades)
        
        # Métricas básicas
        total_trades = len(self.trades)
        winning_trades = len(df_trades[df_trades['pnl_usdt'] > 0])
        losing_trades = len(df_trades[df_trades['pnl_usdt'] < 0])
        
        win_rate = (winning_trades / total_trades) * 100 if total_trades > 0 else 0
        
        # PnL
        total_pnl = df_trades['pnl_usdt'].sum()
        total_pnl_pct = ((self.balance - self.initial_balance) / self.initial_balance) * 100
        
        avg_win = df_trades[df_trades['pnl_usdt'] > 0]['pnl_usdt'].mean() if winning_trades > 0 else 0
        avg_loss = df_trades[df_trades['pnl_usdt'] < 0]['pnl_usdt'].mean() if losing_trades > 0 else 0
        
        # Profit factor
        gross_profit = df_trades[df_trades['pnl_usdt'] > 0]['pnl_usdt'].sum()
        gross_loss = abs(df_trades[df_trades['pnl_usdt'] < 0]['pnl_usdt'].sum())
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
        
        # Drawdown
        equity_series = pd.Series(self.equity_curve)
        rolling_max = equity_series.expanding().max()
        drawdown = (equity_series - rolling_max) / rolling_max * 100
        max_drawdown = drawdown.min()
        
        # Sharpe ratio (simplificado)
        returns = df_trades['pnl_pct'].values
        sharpe = (returns.mean() / returns.std()) * np.sqrt(252) if len(returns) > 1 else 0
        
        # Expectancy
        expectancy = (win_rate / 100) * avg_win - ((100 - win_rate) / 100) * abs(avg_loss)
        
        report = {
            'initial_balance': self.initial_balance,
            'final_balance': self.balance,
            'total_pnl': total_pnl,
            'total_pnl_pct': total_pnl_pct,
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe,
            'expectancy': expectancy,
            'trades': self.trades
        }
        
        return report
    
    def print_report(self, report: Dict):
        """Imprime relatório formatado"""
        print("\n" + "="*60)
        print("RELATÓRIO DE BACKTEST")
        print("="*60)
        print(f"Saldo Inicial:    ${report['initial_balance']:.2f}")
        print(f"Saldo Final:      ${report['final_balance']:.2f}")
        print(f"PnL Total:        ${report['total_pnl']:+.2f} ({report['total_pnl_pct']:+.2f}%)")
        print("-"*60)
        print(f"Total de Trades:  {report['total_trades']}")
        print(f"Trades Ganhas:    {report['winning_trades']}")
        print(f"Trades Perdidas:  {report['losing_trades']}")
        print(f"Win Rate:         {report['win_rate']:.2f}%")
        print("-"*60)
        print(f"Ganho Médio:      ${report['avg_win']:.2f}")
        print(f"Perda Média:      ${report['avg_loss']:.2f}")
        print(f"Profit Factor:    {report['profit_factor']:.2f}")
        print(f"Expectancy:       ${report['expectancy']:.2f}")
        print("-"*60)
        print(f"Max Drawdown:     {report['max_drawdown']:.2f}%")
        print(f"Sharpe Ratio:     {report['sharpe_ratio']:.2f}")
        print("="*60 + "\n")
    
    def export_report(self, report: Dict, filename: str = "backtest_report.json"):
        """Exporta relatório para JSON"""
        # Remover trades (muito grande)
        export_data = {k: v for k, v in report.items() if k != 'trades'}
        export_data['num_trades'] = len(report.get('trades', []))
        
        with open(filename, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        logger.info(f"Relatório exportado: {filename}")


# CLI para backtest
async def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Backtester para estratégia de trading')
    parser.add_argument('--symbol', default='BTCUSDT', help='Símbolo (ex: BTCUSDT)')
    parser.add_argument('--timeframe', default='1h', choices=['15m', '1h', '2h', '4