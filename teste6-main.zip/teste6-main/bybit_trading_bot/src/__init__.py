"""
Bybit Trading Bot
Bot de trading automático para contratos futuros
"""

__version__ = "1.0.0"