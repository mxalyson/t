"""
Detector de padrões gráficos
Identifica formações como triângulos, cunhas, ombro-cabeça-ombro, etc.
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Optional
from scipy.signal import argrelextrema
import logging

logger = logging.getLogger("PatternDetector")


class PatternDetector:
    """Detecta padrões gráficos em dados de preço"""
    
    def __init__(self, min_confidence: float = 0.55):
        self.min_confidence = min_confidence  # V3.3.5 - Reduzido de 0.7 para 0.55
        self.lookback_period = 50  # Período para buscar padrões
        self.min_volume_ratio = 1.3  # Volume mínimo (30% acima da média)
    
    def detect_all_patterns(self, df: pd.DataFrame) -> List[Dict]:
        """
        Detecta todos os padrões disponíveis
        
        Args:
            df: DataFrame com colunas ['open', 'high', 'low', 'close']
        
        Returns:
            Lista de padrões detectados, ordenados por confiança
        """
        if len(df) < 20:
            return []
        
        patterns = []
        
        try:
            # Usar apenas os últimos N candles para performance
            recent_df = df.tail(self.lookback_period).copy()
            
            # Log do último candle para debug
            last_close = recent_df['close'].iloc[-1]
            prev_close = recent_df['close'].iloc[-2]
            price_change = ((last_close - prev_close) / prev_close * 100)
            
            logger.debug(f"Detectando padrões: {len(recent_df)} candles, último close: {last_close:.2f} ({price_change:+.2f}%)")
            
            # Detectar diferentes padrões
            patterns.extend(self._detect_double_top_bottom(recent_df))
            patterns.extend(self._detect_head_shoulders(recent_df))
            patterns.extend(self._detect_triangles(recent_df))
            patterns.extend(self._detect_flags_pennants(recent_df))
            patterns.extend(self._detect_engulfing(recent_df))
            patterns.extend(self._detect_hammer_shooting_star(recent_df))
            # NOVOS padrões de rompimento
            patterns.extend(self._detect_breakouts(recent_df))
            patterns.extend(self._detect_support_resistance_break(recent_df))
            patterns.extend(self._detect_consolidation_breakout(recent_df))
            # ✨ V3.2.2 - Padrões de reteste (pullback)
            patterns.extend(self._detect_pullback_retests(recent_df))
            # ✨ V3.3.4 - Padrões de SCALPING (rápidos)
            patterns.extend(self._detect_scalping_patterns(recent_df))
            # ✨ V3.3.4 - Divergências (RSI/MACD vs Preço)
            patterns.extend(self._detect_divergences(recent_df))
            
            # Log dos padrões encontrados
            if patterns:
                logger.debug(f"Padrões detectados antes do filtro: {[p['type'] for p in patterns]}")
            
            # Ordenar por confiança
            patterns.sort(key=lambda x: x['confidence'], reverse=True)
            
            # Filtrar por confiança mínima
            patterns = [p for p in patterns if p['confidence'] >= self.min_confidence]
            
            if patterns:
                logger.debug(f"Padrões após filtro (conf >= {self.min_confidence}): {[(p['type'], p['confidence']) for p in patterns]}")
            
            return patterns
            
        except Exception as e:
            logger.error(f"Erro ao detectar padrões: {e}")
            return []
    
    def _detect_double_top_bottom(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta topos duplos e fundos duplos"""
        patterns = []
        
        try:
            if len(df) < 20:
                return patterns
            
            # Encontrar máximos e mínimos locais
            highs_idx = argrelextrema(df['high'].values, np.greater, order=5)[0]
            lows_idx = argrelextrema(df['low'].values, np.less, order=5)[0]
            
            # Topo duplo
            if len(highs_idx) >= 2:
                last_two_highs = highs_idx[-2:]
                if len(last_two_highs) == 2:
                    high1 = df['high'].iloc[last_two_highs[0]]
                    high2 = df['high'].iloc[last_two_highs[1]]
                    
                    # Verificar se são similares (diferença < 2%)
                    if abs(high1 - high2) / high1 < 0.02:
                        confidence = 1 - (abs(high1 - high2) / high1)
                        patterns.append({
                            'type': 'double_top',
                            'direction': 'short',
                            'confidence': min(confidence, 0.75),  # V3.3.3 - Reduzido de 0.9
                            'target': None,
                            'description': 'Topo duplo detectado'
                        })
            
            # Fundo duplo
            if len(lows_idx) >= 2:
                last_two_lows = lows_idx[-2:]
                if len(last_two_lows) == 2:
                    low1 = df['low'].iloc[last_two_lows[0]]
                    low2 = df['low'].iloc[last_two_lows[1]]
                    
                    if abs(low1 - low2) / low1 < 0.02:
                        confidence = 1 - (abs(low1 - low2) / low1)
                        patterns.append({
                            'type': 'double_bottom',
                            'direction': 'long',
                            'confidence': min(confidence, 0.75),  # V3.3.3 - Reduzido de 0.9
                            'target': None,
                            'description': 'Fundo duplo detectado'
                        })
        
        except Exception as e:
            logger.debug(f"Erro em double_top_bottom: {e}")
        
        return patterns
    
    def _detect_head_shoulders(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta padrão ombro-cabeça-ombro"""
        patterns = []
        
        try:
            if len(df) < 30:
                return patterns
            
            # Encontrar 3 máximos consecutivos
            highs_idx = argrelextrema(df['high'].values, np.greater, order=5)[0]
            
            if len(highs_idx) >= 3:
                last_three = highs_idx[-3:]
                if len(last_three) == 3:
                    left_shoulder = df['high'].iloc[last_three[0]]
                    head = df['high'].iloc[last_three[1]]
                    right_shoulder = df['high'].iloc[last_three[2]]
                    
                    # Verificar se forma OCO (cabeça mais alta, ombros similares)
                    if head > left_shoulder and head > right_shoulder:
                        shoulder_diff = abs(left_shoulder - right_shoulder) / left_shoulder
                        if shoulder_diff < 0.03:  # Ombros similares (3% de tolerância)
                            confidence = 0.8 * (1 - shoulder_diff)
                            patterns.append({
                                'type': 'head_shoulders',
                                'direction': 'short',
                                'confidence': min(confidence, 0.85),
                                'target': None,
                                'description': 'Ombro-cabeça-ombro detectado'
                            })
            
            # OCO invertido
            lows_idx = argrelextrema(df['low'].values, np.less, order=5)[0]
            
            if len(lows_idx) >= 3:
                last_three = lows_idx[-3:]
                if len(last_three) == 3:
                    left_shoulder = df['low'].iloc[last_three[0]]
                    head = df['low'].iloc[last_three[1]]
                    right_shoulder = df['low'].iloc[last_three[2]]
                    
                    if head < left_shoulder and head < right_shoulder:
                        shoulder_diff = abs(left_shoulder - right_shoulder) / left_shoulder
                        if shoulder_diff < 0.03:
                            confidence = 0.8 * (1 - shoulder_diff)
                            patterns.append({
                                'type': 'inverse_head_shoulders',
                                'direction': 'long',
                                'confidence': min(confidence, 0.85),
                                'target': None,
                                'description': 'OCO invertido detectado'
                            })
        
        except Exception as e:
            logger.debug(f"Erro em head_shoulders: {e}")
        
        return patterns
    
    def _detect_triangles(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta triângulos (ascendente, descendente, simétrico)"""
        patterns = []
        
        try:
            if len(df) < 20:
                return patterns
            
            recent = df.tail(20)
            
            # Calcular linha de tendência das máximas e mínimas
            highs = recent['high'].values
            lows = recent['low'].values
            x = np.arange(len(recent))
            
            # Regressão linear
            high_slope = np.polyfit(x, highs, 1)[0]
            low_slope = np.polyfit(x, lows, 1)[0]
            
            # Triângulo ascendente: máximas planas, mínimas subindo
            if abs(high_slope) < 0.0005 and low_slope > 0.001:
                patterns.append({
                    'type': 'ascending_triangle',
                    'direction': 'long',
                    'confidence': 0.75,
                    'target': None,
                    'description': 'Triângulo ascendente'
                })
            
            # Triângulo descendente: mínimas planas, máximas descendo
            elif abs(low_slope) < 0.0005 and high_slope < -0.001:
                patterns.append({
                    'type': 'descending_triangle',
                    'direction': 'short',
                    'confidence': 0.75,
                    'target': None,
                    'description': 'Triângulo descendente'
                })
            
            # Triângulo simétrico: convergindo
            elif high_slope < -0.0005 and low_slope > 0.0005:
                patterns.append({
                    'type': 'symmetrical_triangle',
                    'direction': 'neutral',
                    'confidence': 0.70,
                    'target': None,
                    'description': 'Triângulo simétrico'
                })
        
        except Exception as e:
            logger.debug(f"Erro em triangles: {e}")
        
        return patterns
    
    def _detect_flags_pennants(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta bandeiras e flâmulas"""
        patterns = []
        
        try:
            if len(df) < 15:
                return patterns
            
            recent = df.tail(15)
            
            # Verificar movimento forte anterior (mastro)
            price_change = (recent['close'].iloc[-1] - recent['close'].iloc[0]) / recent['close'].iloc[0]
            
            # Se houve movimento forte (>3%)
            if abs(price_change) > 0.03:
                # Verificar consolidação recente (últimos 5 candles)
                consolidation = recent.tail(5)
                volatility = consolidation['close'].std() / consolidation['close'].mean()
                
                # Baixa volatilidade = consolidação
                if volatility < 0.015:
                    direction = 'long' if price_change > 0 else 'short'
                    patterns.append({
                        'type': 'flag',
                        'direction': direction,
                        'confidence': 0.72,
                        'target': None,
                        'description': f'Bandeira {"de alta" if direction == "long" else "de baixa"}'
                    })
        
        except Exception as e:
            logger.debug(f"Erro em flags_pennants: {e}")
        
        return patterns
    
    def _detect_engulfing(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta padrões de engolfo (bullish/bearish engulfing)"""
        patterns = []
        
        try:
            if len(df) < 2:
                return patterns
            
            last = df.iloc[-1]
            prev = df.iloc[-2]
            
            # Engolfo de alta (bullish engulfing)
            if (prev['close'] < prev['open'] and  # Candle anterior baixista
                last['close'] > last['open'] and  # Candle atual altista
                last['open'] <= prev['close'] and  # Abre abaixo do fechamento anterior
                last['close'] >= prev['open']):    # Fecha acima da abertura anterior
                
                body_ratio = (last['close'] - last['open']) / (prev['open'] - prev['close'])
                confidence = min(0.65 + (body_ratio * 0.1), 0.85)
                
                patterns.append({
                    'type': 'bullish_engulfing',
                    'direction': 'long',
                    'confidence': confidence,
                    'target': None,
                    'description': 'Engolfo de alta'
                })
            
            # Engolfo de baixa (bearish engulfing)
            elif (prev['close'] > prev['open'] and  # Candle anterior altista
                  last['close'] < last['open'] and  # Candle atual baixista
                  last['open'] >= prev['close'] and  # Abre acima do fechamento anterior
                  last['close'] <= prev['open']):    # Fecha abaixo da abertura anterior
                
                body_ratio = (last['open'] - last['close']) / (prev['close'] - prev['open'])
                confidence = min(0.65 + (body_ratio * 0.1), 0.85)
                
                patterns.append({
                    'type': 'bearish_engulfing',
                    'direction': 'short',
                    'confidence': confidence,
                    'target': None,
                    'description': 'Engolfo de baixa'
                })
        
        except Exception as e:
            logger.debug(f"Erro em engulfing: {e}")
        
        return patterns
    
    def _detect_hammer_shooting_star(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta martelos e estrelas cadentes"""
        patterns = []
        
        try:
            if len(df) < 1:
                return patterns
            
            last = df.iloc[-1]
            
            body = abs(last['close'] - last['open'])
            total_range = last['high'] - last['low']
            
            if total_range == 0:
                return patterns
            
            body_ratio = body / total_range
            
            # Martelo (hammer) - pavio inferior longo
            lower_wick = min(last['open'], last['close']) - last['low']
            upper_wick = last['high'] - max(last['open'], last['close'])
            
            if body_ratio < 0.3 and lower_wick > body * 2 and upper_wick < body * 0.5:
                confidence = 0.70 * (1 - body_ratio)
                patterns.append({
                    'type': 'hammer',
                    'direction': 'long',
                    'confidence': min(confidence, 0.80),
                    'target': None,
                    'description': 'Martelo detectado'
                })
            
            # Estrela cadente (shooting star) - pavio superior longo
            elif body_ratio < 0.3 and upper_wick > body * 2 and lower_wick < body * 0.5:
                confidence = 0.70 * (1 - body_ratio)
                patterns.append({
                    'type': 'shooting_star',
                    'direction': 'short',
                    'confidence': min(confidence, 0.80),
                    'target': None,
                    'description': 'Estrela cadente detectada'
                })
        
        except Exception as e:
            logger.debug(f"Erro em hammer_shooting_star: {e}")
        
        return patterns
    
    def _detect_breakouts(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta rompimentos de máximas/mínimas recentes"""
        patterns = []
        
        try:
            if len(df) < 20:
                return patterns
            
            current = df.iloc[-1]
            recent = df.tail(20)
            
            # Calcular máxima e mínima recente (ignorando último candle)
            recent_high = recent['high'].iloc[:-1].max()
            recent_low = recent['low'].iloc[:-1].min()
            
            # Volume atual vs médio
            avg_volume = recent['volume'].mean()
            volume_ratio = current['volume'] / avg_volume if avg_volume > 0 else 1.0
            
            # ✨ V3.2.2 - Breakout de alta ROBUSTO (rompe máxima com volume + confirmação)
            if current['close'] > recent_high and volume_ratio > self.min_volume_ratio:
                # Validações adicionais
                breakout_strength = (current['close'] - recent_high) / recent_high
                candle_bullish = current['close'] > current['open']
                
                # Só aceita se rompe com força (>0.3%) e candle altista
                if breakout_strength > 0.003 and candle_bullish:
                    confidence = 0.70 + (volume_ratio - self.min_volume_ratio) * 0.08
                    confidence += breakout_strength * 10  # Bônus pela força do rompimento
                    confidence = min(confidence, 0.88)
                    
                    patterns.append({
                        'type': 'bullish_breakout',
                        'direction': 'long',
                        'confidence': confidence,
                        'target': current['close'] * 1.02,
                        'description': f'Rompimento robusto (vol: {volume_ratio:.1f}x, força: {breakout_strength*100:.1f}%)'
                    })
            
            # ✨ V3.2.2 - Breakdown ROBUSTO (rompe mínima com volume + confirmação)
            elif current['close'] < recent_low and volume_ratio > self.min_volume_ratio:
                # Validações adicionais
                breakdown_strength = (recent_low - current['close']) / recent_low
                candle_bearish = current['close'] < current['open']
                
                # Só aceita se rompe com força (>0.3%) e candle baixista
                if breakdown_strength > 0.003 and candle_bearish:
                    confidence = 0.70 + (volume_ratio - self.min_volume_ratio) * 0.08
                    confidence += breakdown_strength * 10  # Bônus pela força do rompimento
                    confidence = min(confidence, 0.88)
                    
                    patterns.append({
                        'type': 'bearish_breakdown',
                        'direction': 'short',
                        'confidence': confidence,
                        'target': current['close'] * 0.98,
                        'description': f'Rompimento robusto (vol: {volume_ratio:.1f}x, força: {breakdown_strength*100:.1f}%)'
                    })
        
        except Exception as e:
            logger.debug(f"Erro em breakouts: {e}")
        
        return patterns
    
    def _detect_support_resistance_break(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta rompimento de suporte/resistência com reteste"""
        patterns = []
        
        try:
            if len(df) < 30:
                return patterns
            
            recent = df.tail(30)
            current = recent.iloc[-1]
            prev = recent.iloc[-2]
            
            # Identificar níveis de S/R significativos
            highs = recent['high'].values
            lows = recent['low'].values
            
            # Calcular níveis mais tocados
            price_levels = []
            for i in range(len(recent) - 5):
                if highs[i] == max(highs[i:i+5]):  # Resistência
                    price_levels.append(('resistance', highs[i]))
                if lows[i] == min(lows[i:i+5]):  # Suporte
                    price_levels.append(('support', lows[i]))
            
            if not price_levels:
                return patterns
            
            # Verificar rompimentos recentes
            for level_type, level_price in price_levels:
                price_diff = abs(current['close'] - level_price) / level_price
                
                # Rompimento de resistência
                if level_type == 'resistance' and prev['close'] < level_price and current['close'] > level_price:
                    if price_diff < 0.005:  # Rompeu até 0.5%
                        confidence = 0.75
                        patterns.append({
                            'type': 'resistance_break',
                            'direction': 'long',
                            'confidence': confidence,
                            'target': level_price * 1.02,
                            'description': 'Rompimento de resistência'
                        })
                        break
                
                # Rompimento de suporte
                elif level_type == 'support' and prev['close'] > level_price and current['close'] < level_price:
                    if price_diff < 0.005:
                        confidence = 0.75
                        patterns.append({
                            'type': 'support_break',
                            'direction': 'short',
                            'confidence': confidence,
                            'target': level_price * 0.98,
                            'description': 'Rompimento de suporte'
                        })
                        break
        
        except Exception as e:
            logger.debug(f"Erro em support_resistance_break: {e}")
        
        return patterns
    
    def _detect_consolidation_breakout(self, df: pd.DataFrame) -> List[Dict]:
        """Detecta rompimento de consolidação (range)"""
        patterns = []
        
        try:
            if len(df) < 15:
                return patterns
            
            recent = df.tail(15)
            
            # Calcular volatilidade (desvio padrão dos fechamentos)
            volatility = recent['close'].std() / recent['close'].mean()
            
            # Consolidação = baixa volatilidade
            if volatility < 0.015:  # 1.5% de volatilidade
                current = recent.iloc[-1]
                prev = recent.iloc[-2]
                
                # Range da consolidação
                high_range = recent['high'].max()
                low_range = recent['low'].min()
                mid_range = (high_range + low_range) / 2
                
                # Volume atual vs médio
                avg_volume = recent['volume'].mean()
                volume_ratio = current['volume'] / avg_volume if avg_volume > 0 else 1.0
                
                # Rompimento da consolidação para cima
                if current['close'] > high_range and volume_ratio > 1.2:
                    confidence = min(0.65 + (volume_ratio - 1.2) * 0.1, 0.80)
                    patterns.append({
                        'type': 'consolidation_breakout_up',
                        'direction': 'long',
                        'confidence': confidence,
                        'target': high_range + (high_range - low_range),  # Projeção do range
                        'description': f'Rompimento de consolidação (alta, vol: {volume_ratio:.1f}x)'
                    })
                
                # Rompimento da consolidação para baixo
                elif current['close'] < low_range and volume_ratio > 1.2:
                    confidence = min(0.65 + (volume_ratio - 1.2) * 0.1, 0.80)
                    patterns.append({
                        'type': 'consolidation_breakout_down',
                        'direction': 'short',
                        'confidence': confidence,
                        'target': low_range - (high_range - low_range),
                        'description': f'Rompimento de consolidação (baixa, vol: {volume_ratio:.1f}x)'
                    })
        
        except Exception as e:
            logger.debug(f"Erro em consolidation_breakout: {e}")
        
        return patterns
    
    def _detect_pullback_retests(self, df: pd.DataFrame) -> List[Dict]:
        """
        ✨ V3.2.2 - Detecta retestes (pullbacks) após rompimentos
        
        Um reteste válido ocorre quando:
        1. Houve um rompimento recente (alta ou baixa)
        2. O preço volta para testar o nível rompido
        3. O nível segura (atua como suporte/resistência)
        4. Há confirmação de continuação
        """
        patterns = []
        
        try:
            if len(df) < 20:
                return patterns
            
            recent = df.tail(20)
            
            # Identificar máximas e mínimas locais
            highs_idx = argrelextrema(recent['high'].values, np.greater, order=3)[0]
            lows_idx = argrelextrema(recent['low'].values, np.less, order=3)[0]
            
            if len(highs_idx) == 0 or len(lows_idx) == 0:
                return patterns
            
            current = recent.iloc[-1]
            prev = recent.iloc[-2]
            
            # RETESTE DE RESISTÊNCIA ROMPIDA (agora suporte)
            if len(highs_idx) >= 1:
                # Pegar a resistência mais recente
                resistance_idx = highs_idx[-1]
                resistance_level = recent['high'].iloc[resistance_idx]
                
                # Verificar se houve rompimento (preço foi acima da resistência)
                broke_resistance = any(recent['close'].iloc[resistance_idx+1:] > resistance_level * 1.005)
                
                if broke_resistance:
                    # Verificar se está retestando (voltou próximo do nível)
                    near_level = abs(current['close'] - resistance_level) / resistance_level < 0.01  # 1%
                    
                    # Verificar se segurou (não quebrou para baixo)
                    held_support = current['low'] >= resistance_level * 0.995  # Tolerância 0.5%
                    
                    # Verificar confirmação de continuação (candle altista)
                    bullish_candle = current['close'] > current['open']
                    
                    # Volume confirmation
                    avg_volume = recent['volume'].mean()
                    volume_ratio = current['volume'] / avg_volume if avg_volume > 0 else 1.0
                    
                    if near_level and held_support and bullish_candle:
                        confidence = 0.70
                        if volume_ratio > 1.2:
                            confidence += 0.10
                        if current['close'] > prev['close']:  # Força adicional
                            confidence += 0.05
                        
                        patterns.append({
                            'type': 'pullback_retest_support',
                            'direction': 'long',
                            'confidence': min(confidence, 0.88),
                            'target': None,
                            'description': f'Reteste de suporte (ex-resistência) - Vol: {volume_ratio:.1f}x'
                        })
            
            # RETESTE DE SUPORTE ROMPIDO (agora resistência)
            if len(lows_idx) >= 1:
                # Pegar o suporte mais recente
                support_idx = lows_idx[-1]
                support_level = recent['low'].iloc[support_idx]
                
                # Verificar se houve rompimento (preço foi abaixo do suporte)
                broke_support = any(recent['close'].iloc[support_idx+1:] < support_level * 0.995)
                
                if broke_support:
                    # Verificar se está retestando (voltou próximo do nível)
                    near_level = abs(current['close'] - support_level) / support_level < 0.01
                    
                    # Verificar se segurou (não quebrou para cima)
                    held_resistance = current['high'] <= support_level * 1.005
                    
                    # Verificar confirmação de continuação (candle baixista)
                    bearish_candle = current['close'] < current['open']
                    
                    # Volume confirmation
                    avg_volume = recent['volume'].mean()
                    volume_ratio = current['volume'] / avg_volume if avg_volume > 0 else 1.0
                    
                    if near_level and held_resistance and bearish_candle:
                        confidence = 0.70
                        if volume_ratio > 1.2:
                            confidence += 0.10
                        if current['close'] < prev['close']:  # Força adicional
                            confidence += 0.05
                        
                        patterns.append({
                            'type': 'pullback_retest_resistance',
                            'direction': 'short',
                            'confidence': min(confidence, 0.88),
                            'target': None,
                            'description': f'Reteste de resistência (ex-suporte) - Vol: {volume_ratio:.1f}x'
                        })
        
        except Exception as e:
            logger.debug(f"Erro em pullback_retests: {e}")
        
        return patterns
    
    def _detect_scalping_patterns(self, df: pd.DataFrame) -> List[Dict]:
        """
        ✨ V3.3.4 - Detecta padrões de SCALPING (trades rápidos 1-5min)
        
        Padrões:
        - Strong momentum candle (candle forte com volume)
        - Pin bar (pavio longo, corpo pequeno)
        - Inside bar breakout (rompimento de inside bar)
        - Micro double top/bottom (2-3 candles)
        """
        patterns = []
        
        try:
            if len(df) < 10:
                return patterns
            
            current = df.iloc[-1]
            prev = df.iloc[-2]
            prev2 = df.iloc[-3]
            
            # Calcular ATR para normalizar
            high_low = df['high'] - df['low']
            atr = high_low.rolling(14).mean().iloc[-1] if len(df) >= 14 else high_low.mean()
            
            # Volume médio
            avg_volume = df['volume'].rolling(20).mean().iloc[-1] if len(df) >= 20 else df['volume'].mean()
            volume_ratio = current['volume'] / avg_volume if avg_volume > 0 else 1.0
            
            # 1. STRONG MOMENTUM CANDLE (Scalping)
            body_size = abs(current['close'] - current['open'])
            candle_range = current['high'] - current['low']
            body_pct = body_size / candle_range if candle_range > 0 else 0
            
            # Candle forte: corpo > 70% do range + volume alto
            if body_pct > 0.70 and volume_ratio > 1.5:
                is_bullish = current['close'] > current['open']
                
                # Verificar momentum (3 candles)
                if is_bullish:
                    momentum_confirm = (current['close'] > prev['close'] > prev2['close'])
                else:
                    momentum_confirm = (current['close'] < prev['close'] < prev2['close'])
                
                if momentum_confirm:
                    confidence = min(0.60 + (body_pct * 0.1) + (volume_ratio * 0.05), 0.78)
                    
                    patterns.append({
                        'type': 'scalping_momentum',
                        'direction': 'long' if is_bullish else 'short',
                        'confidence': confidence,
                        'target': None,
                        'description': f'Momentum candle (Vol: {volume_ratio:.1f}x, Body: {body_pct:.0%})'
                    })
            
            # 2. PIN BAR (Reversão)
            upper_wick = current['high'] - max(current['open'], current['close'])
            lower_wick = min(current['open'], current['close']) - current['low']
            
            # Pin bar bullish: pavio inferior > 2x corpo
            if lower_wick > body_size * 2 and lower_wick > upper_wick * 2:
                # Verificar se está em área de suporte
                recent_low = df['low'].tail(10).min()
                near_support = abs(current['low'] - recent_low) / recent_low < 0.01
                
                if near_support and volume_ratio > 1.2:
                    confidence = min(0.65 + (lower_wick / candle_range * 0.15), 0.75)
                    
                    patterns.append({
                        'type': 'pin_bar_bullish',
                        'direction': 'long',
                        'confidence': confidence,
                        'target': None,
                        'description': f'Pin bar bullish (Wick: {lower_wick/candle_range:.0%})'
                    })
            
            # Pin bar bearish: pavio superior > 2x corpo
            elif upper_wick > body_size * 2 and upper_wick > lower_wick * 2:
                recent_high = df['high'].tail(10).max()
                near_resistance = abs(current['high'] - recent_high) / recent_high < 0.01
                
                if near_resistance and volume_ratio > 1.2:
                    confidence = min(0.65 + (upper_wick / candle_range * 0.15), 0.75)
                    
                    patterns.append({
                        'type': 'pin_bar_bearish',
                        'direction': 'short',
                        'confidence': confidence,
                        'target': None,
                        'description': f'Pin bar bearish (Wick: {upper_wick/candle_range:.0%})'
                    })
            
            # 3. INSIDE BAR BREAKOUT (Scalping)
            # Inside bar: high/low dentro do candle anterior
            is_inside = (current['high'] <= prev['high'] and 
                        current['low'] >= prev['low'])
            
            if is_inside and len(df) >= 4:
                prev3 = df.iloc[-4]
                
                # Breakout do inside bar
                if current['close'] > prev['high']:  # Breakout bullish
                    # Verificar se prev tinha range decente
                    prev_range = prev['high'] - prev['low']
                    if prev_range > atr * 0.5 and volume_ratio > 1.3:
                        confidence = min(0.68 + (volume_ratio * 0.05), 0.76)
                        
                        patterns.append({
                            'type': 'inside_bar_breakout_bull',
                            'direction': 'long',
                            'confidence': confidence,
                            'target': None,
                            'description': f'Inside bar breakout bullish (Vol: {volume_ratio:.1f}x)'
                        })
                
                elif current['close'] < prev['low']:  # Breakout bearish
                    prev_range = prev['high'] - prev['low']
                    if prev_range > atr * 0.5 and volume_ratio > 1.3:
                        confidence = min(0.68 + (volume_ratio * 0.05), 0.76)
                        
                        patterns.append({
                            'type': 'inside_bar_breakout_bear',
                            'direction': 'short',
                            'confidence': confidence,
                            'target': None,
                            'description': f'Inside bar breakout bearish (Vol: {volume_ratio:.1f}x)'
                        })
            
            # 4. MICRO DOUBLE TOP/BOTTOM (Scalping - 3-5 candles)
            if len(df) >= 5:
                last_5 = df.tail(5)
                highs = last_5['high'].values
                lows = last_5['low'].values
                
                # Micro double top (2 topos próximos em 5 candles)
                max_idx = np.argsort(highs)[-2:]  # 2 maiores highs
                if len(max_idx) == 2 and abs(highs[max_idx[0]] - highs[max_idx[1]]) / highs[max_idx[0]] < 0.005:
                    # Topos muito próximos (< 0.5%)
                    if volume_ratio > 1.2:
                        confidence = min(0.62 + (volume_ratio * 0.04), 0.72)
                        
                        patterns.append({
                            'type': 'micro_double_top',
                            'direction': 'short',
                            'confidence': confidence,
                            'target': None,
                            'description': f'Micro double top (Scalping)'
                        })
                
                # Micro double bottom
                min_idx = np.argsort(lows)[:2]  # 2 menores lows
                if len(min_idx) == 2 and abs(lows[min_idx[0]] - lows[min_idx[1]]) / lows[min_idx[0]] < 0.005:
                    if volume_ratio > 1.2:
                        confidence = min(0.62 + (volume_ratio * 0.04), 0.72)
                        
                        patterns.append({
                            'type': 'micro_double_bottom',
                            'direction': 'long',
                            'confidence': confidence,
                            'target': None,
                            'description': f'Micro double bottom (Scalping)'
                        })
        
        except Exception as e:
            logger.debug(f"Erro em scalping_patterns: {e}")
        
        return patterns
    
    def _detect_divergences(self, df: pd.DataFrame) -> List[Dict]:
        """
        ✨ V3.3.4 - Detecta DIVERGÊNCIAS entre preço e indicadores
        
        Divergências:
        - Bullish: Preço faz baixa menor, RSI faz baixa maior (reversão para cima)
        - Bearish: Preço faz alta maior, RSI faz alta menor (reversão para baixo)
        """
        patterns = []
        
        try:
            if len(df) < 30:
                return patterns
            
            # Calcular RSI
            delta = df['close'].diff()
            gain = delta.where(delta > 0, 0).rolling(14).mean()
            loss = -delta.where(delta < 0, 0).rolling(14).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            
            if len(rsi) < 20:
                return patterns
            
            # Últimos 15 candles para análise
            recent_price = df['close'].tail(15).values
            recent_rsi = rsi.tail(15).values
            
            # Encontrar extremos locais (últimos 10 candles)
            from scipy.signal import argrelextrema
            
            price_highs_idx = argrelextrema(recent_price[-10:], np.greater, order=2)[0]
            price_lows_idx = argrelextrema(recent_price[-10:], np.less, order=2)[0]
            rsi_highs_idx = argrelextrema(recent_rsi[-10:], np.greater, order=2)[0]
            rsi_lows_idx = argrelextrema(recent_rsi[-10:], np.less, order=2)[0]
            
            # DIVERGÊNCIA BEARISH
            # Preço: alta maior, RSI: alta menor
            if len(price_highs_idx) >= 2 and len(rsi_highs_idx) >= 2:
                # Pegar os 2 últimos topos
                last_2_price_highs = price_highs_idx[-2:]
                last_2_rsi_highs = rsi_highs_idx[-2:]
                
                if len(last_2_price_highs) == 2 and len(last_2_rsi_highs) == 2:
                    price1_idx = last_2_price_highs[0]
                    price2_idx = last_2_price_highs[1]
                    rsi1_idx = last_2_rsi_highs[0]
                    rsi2_idx = last_2_rsi_highs[1]
                    
                    price1 = recent_price[price1_idx]
                    price2 = recent_price[price2_idx]
                    rsi1 = recent_rsi[rsi1_idx]
                    rsi2 = recent_rsi[rsi2_idx]
                    
                    # Divergência: preço subindo, RSI descendo
                    if price2 > price1 and rsi2 < rsi1:
                        divergence_strength = abs(rsi2 - rsi1) / rsi1  # Quanto mais forte, melhor
                        confidence = min(0.70 + (divergence_strength * 0.5), 0.82)
                        
                        patterns.append({
                            'type': 'bearish_divergence',
                            'direction': 'short',
                            'confidence': confidence,
                            'target': None,
                            'description': f'Divergência bearish RSI (força: {divergence_strength:.2f})'
                        })
            
            # DIVERGÊNCIA BULLISH
            # Preço: baixa menor, RSI: baixa maior
            if len(price_lows_idx) >= 2 and len(rsi_lows_idx) >= 2:
                last_2_price_lows = price_lows_idx[-2:]
                last_2_rsi_lows = rsi_lows_idx[-2:]
                
                if len(last_2_price_lows) == 2 and len(last_2_rsi_lows) == 2:
                    price1_idx = last_2_price_lows[0]
                    price2_idx = last_2_price_lows[1]
                    rsi1_idx = last_2_rsi_lows[0]
                    rsi2_idx = last_2_rsi_lows[1]
                    
                    price1 = recent_price[price1_idx]
                    price2 = recent_price[price2_idx]
                    rsi1 = recent_rsi[rsi1_idx]
                    rsi2 = recent_rsi[rsi2_idx]
                    
                    # Divergência: preço descendo, RSI subindo
                    if price2 < price1 and rsi2 > rsi1:
                        divergence_strength = abs(rsi2 - rsi1) / rsi1
                        confidence = min(0.70 + (divergence_strength * 0.5), 0.82)
                        
                        patterns.append({
                            'type': 'bullish_divergence',
                            'direction': 'long',
                            'confidence': confidence,
                            'target': None,
                            'description': f'Divergência bullish RSI (força: {divergence_strength:.2f})'
                        })
        
        except Exception as e:
            logger.debug(f"Erro em divergences: {e}")
        
        return patterns