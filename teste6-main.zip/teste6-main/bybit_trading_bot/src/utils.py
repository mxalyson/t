"""
Utilidades gerais do bot
"""
import logging
import os
from datetime import datetime
import colorlog


def setup_logger(name: str = "trading_bot") -> logging.Logger:
    """Configura logger com cores e arquivo"""
    
    # Criar diretório de logs
    os.makedirs("logs", exist_ok=True)
    
    # Logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # Remover handlers existentes
    logger.handlers.clear()
    
    # Handler para console (com cores) - apenas WARNING+ para logs limpos
    console_handler = colorlog.StreamHandler()
    console_handler.setLevel(logging.WARNING)  # ✨ V3.2 - Só avisos/erros no console
    console_format = colorlog.ColoredFormatter(
        '%(log_color)s%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S',
        log_colors={
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red,bg_white',
        }
    )
    console_handler.setFormatter(console_format)
    
    # Handler para arquivo
    log_file = f"logs/trading_{datetime.now().strftime('%Y%m%d')}.log"
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_format = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(file_format)
    
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger


def format_number(value: float, decimals: int = 2) -> str:
    """Formata número com decimais"""
    return f"{value:.{decimals}f}"


def calculate_pnl_pct(entry_price: float, exit_price: float, is_long: bool) -> float:
    """Calcula PnL percentual"""
    if is_long:
        return ((exit_price - entry_price) / entry_price) * 100
    else:
        return ((entry_price - exit_price) / entry_price) * 100