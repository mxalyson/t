"""
Módulo de indicadores técnicos
Implementa EMA, RSI, MACD, ATR, Volume, VWAP
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from .utils import setup_logger

logger = setup_logger("indicators")


class TechnicalIndicators:
    """Classe para cálculo de indicadores técnicos"""
    
    @staticmethod
    def calculate_ema(data: pd.Series, period: int) -> pd.Series:
        """Calcula Exponential Moving Average"""
        return data.ewm(span=period, adjust=False).mean()
    
    @staticmethod
    def calculate_sma(data: pd.Series, period: int) -> pd.Series:
        """Calcula Simple Moving Average"""
        return data.rolling(window=period).mean()
    
    @staticmethod
    def calculate_rsi(data: pd.Series, period: int = 14) -> pd.Series:
        """
        Calcula Relative Strength Index (MELHORADO - sem 0.0)
        Valores: 0-100
        > 70: Sobrecomprado
        < 30: Sobrevendido
        """
        # Usar método Wilder para RSI mais estável
        delta = data.diff()
        
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        # Usar EWM ao invés de rolling para suavização
        avg_gain = gain.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
        avg_loss = loss.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
        
        # Evitar divisão por zero com valor mínimo seguro
        avg_loss = avg_loss.replace(0, 1e-10)
        
        # Calcular RS e RSI
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        # Substituir NaN, infinitos e zeros por 50 (neutro)
        rsi = rsi.fillna(50)
        rsi = rsi.replace([float('inf'), float('-inf'), 0.0], 50)
        
        # Garantir range 0.1-99.9 (nunca exatamente 0 ou 100)
        rsi = rsi.clip(0.1, 99.9)
        
        return rsi
    
    @staticmethod
    def calculate_macd(
        data: pd.Series,
        fast: int = 12,
        slow: int = 26,
        signal: int = 9
    ) -> Dict[str, pd.Series]:
        """
        Calcula MACD (Moving Average Convergence Divergence)
        
        Returns:
            dict: {'macd': Series, 'signal': Series, 'histogram': Series}
        """
        ema_fast = data.ewm(span=fast, adjust=False).mean()
        ema_slow = data.ewm(span=slow, adjust=False).mean()
        
        macd = ema_fast - ema_slow
        signal_line = macd.ewm(span=signal, adjust=False).mean()
        histogram = macd - signal_line
        
        return {
            'macd': macd,
            'signal': signal_line,
            'histogram': histogram
        }
    
    @staticmethod
    def calculate_atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
        """
        Calcula Average True Range (volatilidade)
        Útil para definir stop loss dinâmico
        """
        high_low = high - low
        high_close = np.abs(high - close.shift())
        low_close = np.abs(low - close.shift())
        
        ranges = pd.concat([high_low, high_close, low_close], axis=1)
        true_range = ranges.max(axis=1)
        
        atr = true_range.rolling(window=period).mean()
        
        return atr
    
    @staticmethod
    def calculate_bollinger_bands(
        data: pd.Series,
        period: int = 20,
        std_dev: int = 2
    ) -> Dict[str, pd.Series]:
        """
        Calcula Bandas de Bollinger
        
        Returns:
            dict: {'upper': Series, 'middle': Series, 'lower': Series}
        """
        middle = data.rolling(window=period).mean()
        std = data.rolling(window=period).std()
        
        upper = middle + (std * std_dev)
        lower = middle - (std * std_dev)
        
        return {
            'upper': upper,
            'middle': middle,
            'lower': lower
        }
    
    @staticmethod
    def calculate_vwap(high: pd.Series, low: pd.Series, close: pd.Series, volume: pd.Series) -> pd.Series:
        """
        Calcula Volume Weighted Average Price
        Útil para confirmar tendências com volume
        """
        typical_price = (high + low + close) / 3
        vwap = (typical_price * volume).cumsum() / volume.cumsum()
        
        return vwap
    
    @staticmethod
    def calculate_obv(close: pd.Series, volume: pd.Series) -> pd.Series:
        """
        Calcula On-Balance Volume
        Mede pressão de compra/venda baseado em volume
        """
        obv = (np.sign(close.diff()) * volume).fillna(0).cumsum()
        return obv
    
    @staticmethod
    def identify_support_resistance(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        window: int = 20
    ) -> Dict[str, List[float]]:
        """
        Identifica níveis de suporte e resistência
        
        Returns:
            dict: {'support': [levels], 'resistance': [levels]}
        """
        # Encontrar pivots (swing highs/lows)
        support_levels = []
        resistance_levels = []
        
        for i in range(window, len(close) - window):
            # Swing high (resistência)
            if high[i] == high[i-window:i+window+1].max():
                resistance_levels.append(high[i])
            
            # Swing low (suporte)
            if low[i] == low[i-window:i+window+1].min():
                support_levels.append(low[i])
        
        # Agrupar níveis próximos
        def cluster_levels(levels, tolerance=0.002):
            if not levels:
                return []
            
            levels = sorted(levels)
            clusters = []
            current_cluster = [levels[0]]
            
            for level in levels[1:]:
                if (level - current_cluster[-1]) / current_cluster[-1] < tolerance:
                    current_cluster.append(level)
                else:
                    clusters.append(np.mean(current_cluster))
                    current_cluster = [level]
            
            clusters.append(np.mean(current_cluster))
            return clusters
        
        return {
            'support': cluster_levels(support_levels),
            'resistance': cluster_levels(resistance_levels)
        }
    
    @staticmethod
    def analyze_volume(volume: pd.Series, period: int = 20) -> Dict[str, any]:
        """
        Analisa padrões de volume
        
        Returns:
            dict: {'avg_volume': float, 'current_ratio': float, 'trend': str}
        """
        avg_volume = volume.rolling(window=period).mean().iloc[-1]
        current_volume = volume.iloc[-1]
        
        ratio = current_volume / avg_volume if avg_volume > 0 else 1.0
        
        # Tendência de volume
        recent_avg = volume.tail(5).mean()
        previous_avg = volume.tail(10).head(5).mean()
        
        if recent_avg > previous_avg * 1.2:
            trend = "increasing"
        elif recent_avg < previous_avg * 0.8:
            trend = "decreasing"
        else:
            trend = "stable"
        
        return {
            'avg_volume': avg_volume,
            'current_volume': current_volume,
            'ratio': ratio,
            'trend': trend
        }


class IndicatorSignals:
    """Classe para gerar sinais de trading baseados em indicadores"""
    
    @staticmethod
    def get_ema_signal(df: pd.DataFrame) -> str:
        """
        Sinal baseado em cruzamento de EMAs
        
        Returns:
            'bullish', 'bearish', ou 'neutral'
        """
        ema9 = df['ema_9'].iloc[-1]
        ema21 = df['ema_21'].iloc[-1]
        ema50 = df['ema_50'].iloc[-1]
        
        prev_ema9 = df['ema_9'].iloc[-2]
        prev_ema21 = df['ema_21'].iloc[-2]
        
        # Cruzamento de alta
        if prev_ema9 < prev_ema21 and ema9 > ema21 and ema21 > ema50:
            return 'bullish'
        
        # Cruzamento de baixa
        if prev_ema9 > prev_ema21 and ema9 < ema21 and ema21 < ema50:
            return 'bearish'
        
        # Tendência clara
        if ema9 > ema21 > ema50:
            return 'bullish'
        elif ema9 < ema21 < ema50:
            return 'bearish'
        
        return 'neutral'
    
    @staticmethod
    def get_rsi_signal(rsi: float) -> str:
        """
        Sinal baseado em RSI
        
        Returns:
            'oversold', 'overbought', 'neutral'
        """
        # Validar RSI
        if pd.isna(rsi) or rsi == float('inf') or rsi == float('-inf'):
            return 'neutral'
        
        if rsi < 30:
            return 'oversold'  # Possível compra
        elif rsi > 70:
            return 'overbought'  # Possível venda
        else:
            return 'neutral'
    
    @staticmethod
    def get_macd_signal(df: pd.DataFrame) -> str:
        """
        Sinal baseado em MACD
        
        Returns:
            'bullish', 'bearish', 'neutral'
        """
        macd = df['macd'].iloc[-1]
        signal = df['macd_signal'].iloc[-1]
        histogram = df['macd_histogram'].iloc[-1]
        
        prev_histogram = df['macd_histogram'].iloc[-2]
        
        # Cruzamento de alta
        if prev_histogram < 0 and histogram > 0:
            return 'bullish'
        
        # Cruzamento de baixa
        if prev_histogram > 0 and histogram < 0:
            return 'bearish'
        
        # Tendência
        if macd > signal and histogram > 0:
            return 'bullish'
        elif macd < signal and histogram < 0:
            return 'bearish'
        
        return 'neutral'
    
    @staticmethod
    def calculate_all_indicators(df: pd.DataFrame) -> pd.DataFrame:
        """
        Calcula todos os indicadores em um DataFrame
        
        Args:
            df: DataFrame com colunas: open, high, low, close, volume
        
        Returns:
            DataFrame com indicadores adicionados
        """
        ti = TechnicalIndicators()
        
        # EMAs
        df['ema_9'] = ti.calculate_ema(df['close'], 9)
        df['ema_21'] = ti.calculate_ema(df['close'], 21)
        df['ema_50'] = ti.calculate_ema(df['close'], 50)
        
        # RSI
        df['rsi'] = ti.calculate_rsi(df['close'], 14)
        
        # MACD
        macd_data = ti.calculate_macd(df['close'])
        df['macd'] = macd_data['macd']
        df['macd_signal'] = macd_data['signal']
        df['macd_histogram'] = macd_data['histogram']
        
        # ATR
        df['atr'] = ti.calculate_atr(df['high'], df['low'], df['close'], 14)
        
        # Bollinger Bands
        bb = ti.calculate_bollinger_bands(df['close'])
        df['bb_upper'] = bb['upper']
        df['bb_middle'] = bb['middle']
        df['bb_lower'] = bb['lower']
        
        # VWAP
        df['vwap'] = ti.calculate_vwap(df['high'], df['low'], df['close'], df['volume'])
        
        # OBV
        df['obv'] = ti.calculate_obv(df['close'], df['volume'])
        
        logger.debug(f"Indicadores calculados para {len(df)} candles")
        
        return df
    
    @staticmethod
    def get_combined_signal(df: pd.DataFrame) -> Dict[str, any]:
        """
        Combina múltiplos indicadores para gerar sinal final (MELHORADO)
        
        Returns:
            dict: {
                'signal': 'long'/'short'/'neutral',
                'confidence': 0-1,
                'indicators': {...}
            }
        """
        signals = IndicatorSignals()
        
        ema_signal = signals.get_ema_signal(df)
        rsi_value = df['rsi'].iloc[-1]
        
        # Validar RSI antes de usar
        if pd.isna(rsi_value) or rsi_value == float('inf') or rsi_value == float('-inf'):
            rsi_value = 50.0  # Neutro se inválido
        
        rsi_signal = signals.get_rsi_signal(rsi_value)
        macd_signal = signals.get_macd_signal(df)
        
        # NOVOS indicadores
        bb_signal = signals.get_bollinger_signal(df)
        vwap_signal = signals.get_vwap_signal(df)
        obv_signal = signals.get_obv_signal(df)
        
        # Volume
        volume_info = TechnicalIndicators.analyze_volume(df['volume'])
        volume_confirmation = volume_info['ratio'] > 1.2
        
        # Contar sinais (ponderado)
        bullish_score = 0.0
        bearish_score = 0.0
        
        # EMAs (peso 2x - mais importante)
        if ema_signal == 'bullish':
            bullish_score += 2.0
        elif ema_signal == 'bearish':
            bearish_score += 2.0
        
        # RSI (peso 1x)
        if rsi_signal == 'oversold':
            bullish_score += 1.0
        elif rsi_signal == 'overbought':
            bearish_score += 1.0
        
        # MACD (peso 1.5x)
        if macd_signal == 'bullish':
            bullish_score += 1.5
        elif macd_signal == 'bearish':
            bearish_score += 1.5
        
        # Bollinger Bands (peso 1x)
        if bb_signal == 'bullish':
            bullish_score += 1.0
        elif bb_signal == 'bearish':
            bearish_score += 1.0
        
        # VWAP (peso 1x)
        if vwap_signal == 'bullish':
            bullish_score += 1.0
        elif vwap_signal == 'bearish':
            bearish_score += 1.0
        
        # OBV (peso 0.5x - confirmação)
        if obv_signal == 'bullish':
            bullish_score += 0.5
        elif obv_signal == 'bearish':
            bearish_score += 0.5
        
        # Volume confirmation (boost de 10%)
        if volume_confirmation:
            bullish_score *= 1.1
            bearish_score *= 1.1
        
        # Decisão final (score máximo = 7.5 pontos)
        total_score = bullish_score + bearish_score
        
        if bullish_score > bearish_score and bullish_score >= 2.0:
            signal = 'long'
            confidence = min(bullish_score / 7.5, 1.0)
        elif bearish_score > bullish_score and bearish_score >= 2.0:
            signal = 'short'
            confidence = min(bearish_score / 7.5, 1.0)
        else:
            signal = 'neutral'
            confidence = 0.0
        
        return {
            'signal': signal,
            'confidence': confidence,
            'indicators': {
                'ema': ema_signal,
                'rsi': rsi_signal,
                'rsi_value': rsi_value,
                'macd': macd_signal,
                'bollinger': bb_signal,
                'vwap': vwap_signal,
                'obv': obv_signal,
                'volume_ratio': volume_info['ratio'],
                'volume_confirmed': volume_confirmation,
                'bullish_score': bullish_score,
                'bearish_score': bearish_score
            }
        }
    
    @staticmethod
    def get_bollinger_signal(df: pd.DataFrame) -> str:
        """
        Sinal baseado em Bollinger Bands
        
        Returns:
            'bullish', 'bearish', 'neutral'
        """
        try:
            close = df['close'].iloc[-1]
            bb_upper = df['bb_upper'].iloc[-1]
            bb_lower = df['bb_lower'].iloc[-1]
            bb_middle = df['bb_middle'].iloc[-1]
            
            # Squeeze (bandas estreitas = preparação para movimento)
            bb_width = (bb_upper - bb_lower) / bb_middle
            
            # Preço próximo da banda inferior = possível alta
            if close < bb_lower * 1.005:  # 0.5% abaixo
                return 'bullish'
            # Preço próximo da banda superior = possível baixa
            elif close > bb_upper * 0.995:  # 0.5% acima
                return 'bearish'
            # Squeeze + preço acima da média = preparação alta
            elif bb_width < 0.04 and close > bb_middle:
                return 'bullish'
            # Squeeze + preço abaixo da média = preparação baixa
            elif bb_width < 0.04 and close < bb_middle:
                return 'bearish'
            
            return 'neutral'
        except:
            return 'neutral'
    
    @staticmethod
    def get_vwap_signal(df: pd.DataFrame) -> str:
        """
        Sinal baseado em VWAP
        
        Returns:
            'bullish', 'bearish', 'neutral'
        """
        try:
            close = df['close'].iloc[-1]
            vwap = df['vwap'].iloc[-1]
            prev_close = df['close'].iloc[-2]
            prev_vwap = df['vwap'].iloc[-2]
            
            # Cruzamento de alta
            if prev_close < prev_vwap and close > vwap:
                return 'bullish'
            # Cruzamento de baixa
            elif prev_close > prev_vwap and close < vwap:
                return 'bearish'
            # Tendência confirmada
            elif close > vwap * 1.002:  # 0.2% acima
                return 'bullish'
            elif close < vwap * 0.998:  # 0.2% abaixo
                return 'bearish'
            
            return 'neutral'
        except:
            return 'neutral'
    
    @staticmethod
    def get_obv_signal(df: pd.DataFrame) -> str:
        """
        Sinal baseado em OBV (On-Balance Volume)
        
        Returns:
            'bullish', 'bearish', 'neutral'
        """
        try:
            obv = df['obv'].tail(10)
            
            # Calcular tendência do OBV
            obv_sma = obv.rolling(window=5).mean()
            
            current_obv = obv.iloc[-1]
            current_sma = obv_sma.iloc[-1]
            prev_sma = obv_sma.iloc[-2]
            
            # OBV subindo = pressão compradora
            if current_obv > current_sma and current_sma > prev_sma:
                return 'bullish'
            # OBV descendo = pressão vendedora
            elif current_obv < current_sma and current_sma < prev_sma:
                return 'bearish'
            
            return 'neutral'
        except:
            return 'neutral'
