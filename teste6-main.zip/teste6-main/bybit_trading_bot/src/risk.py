"""
Módulo de gestão de risco
Calcula position size, TP/SL, trailing stop, limites de perda
"""
import pandas as pd
from typing import Dict, Optional, Tuple
from .utils import setup_logger

logger = setup_logger("risk")


class RiskManager:
    """Classe para gestão de risco de trading"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.position_size_pct = config.get('position_size_pct', 1.0)
        self.default_tp_pct = config.get('default_tp_pct', 8.0)  # TP padrão 8%
        self.default_sl_pct = config.get('default_sl_pct', 5.0)  # SL padrão 5%
        self.leverage = config.get('leverage', 5)
        self.max_open_trades_per_symbol = config.get('max_open_trades_per_symbol', 1)
        self.max_total_open_trades = config.get('max_total_open_trades', 3)
        
        # Cooldown entre trades do mesmo símbolo (minutos)
        self.trade_cooldown_minutes = config.get('trade_cooldown_minutes', 5)
        self.last_trade_time = {}  # Rastrear último trade por símbolo
        
        # Configurações avançadas
        risk_config = config.get('risk', {})
        self.max_daily_loss_pct = risk_config.get('max_daily_loss_pct', 5.0)
        self.max_position_loss_pct = risk_config.get('max_position_loss_pct', 3.0)
        self.use_atr_for_sl = risk_config.get('use_atr_for_sl', True)
        self.atr_multiplier = risk_config.get('atr_multiplier', 2.0)
        
        # Tracking de perdas
        self.daily_pnl = 0.0
        self.daily_trades = 0
        self.open_positions_count = 0
        
        logger.info(f"RiskManager inicializado: {self.position_size_pct}% por trade, leverage {self.leverage}x")
    
    def can_open_trade(self, symbol: str, positions: Dict) -> tuple[bool, str]:
        """
        Verifica se pode abrir nova trade para o símbolo
        
        Returns:
            (bool, str): (pode_abrir, motivo_se_nao)
        """
        from datetime import datetime, timedelta
        
        # 1. Verificar se já tem posição aberta no símbolo
        if symbol in positions:
            return False, f"Máximo de {self.max_open_trades_per_symbol} posições em {symbol}"
        
        # 2. Verificar total de posições abertas
        if len(positions) >= self.max_total_open_trades:
            return False, f"Máximo de {self.max_total_open_trades} posições abertas"
        
        # 3. Verificar cooldown (evitar trades muito frequentes)
        if symbol in self.last_trade_time:
            last_trade = self.last_trade_time[symbol]
            cooldown = timedelta(minutes=self.trade_cooldown_minutes)
            time_since_last = datetime.now() - last_trade
            
            if time_since_last < cooldown:
                remaining = (cooldown - time_since_last).seconds // 60
                return False, f"Cooldown ativo: aguarde {remaining}min para {symbol}"
        
        return True, "OK"
    
    def record_trade(self, symbol: str):
        """Registra que um trade foi executado"""
        from datetime import datetime
        self.last_trade_time[symbol] = datetime.now()
        logger.debug(f"Trade registrado para {symbol} às {datetime.now().strftime('%H:%M:%S')}")
    
    def should_take_partial_profit(self, entry_price: float, current_price: float, 
                                   side: str) -> tuple[bool, float]:
        """
        ✨ V3.1 - Verifica se deve realizar lucro parcial
        
        Realiza 50% da posição quando atinge +2%
        
        Args:
            entry_price: Preço de entrada
            current_price: Preço atual
            side: 'Buy' (long) ou 'Sell' (short)
        
        Returns:
            (bool, float): (should_close, percentage_to_close)
        """
        # Calcular PnL %
        if side == "Buy":
            pnl_pct = (current_price - entry_price) / entry_price * 100
        else:
            pnl_pct = (entry_price - current_price) / entry_price * 100
        
        # Partial TP em +2%
        partial_tp_threshold = 2.0
        
        if pnl_pct >= partial_tp_threshold:
            return True, 0.5  # Fechar 50%
        
        return False, 0.0
    
    def should_move_to_breakeven(self, entry_price: float, current_price: float, 
                                 current_sl: float, side: str) -> tuple[bool, float]:
        """
        ✨ V3.1 - Verifica se deve mover SL para break-even
        
        Move SL para entry quando atinge +1.5%
        
        Args:
            entry_price: Preço de entrada
            current_price: Preço atual
            current_sl: Stop loss atual
            side: 'Buy' (long) ou 'Sell' (short)
        
        Returns:
            (bool, float): (should_move, new_sl_price)
        """
        # Calcular PnL %
        if side == "Buy":
            pnl_pct = (current_price - entry_price) / entry_price * 100
        else:
            pnl_pct = (entry_price - current_price) / entry_price * 100
        
        # Break-even threshold
        breakeven_threshold = 1.5  # +1.5%
        
        # Verificar se já está em break-even
        is_breakeven = abs(current_sl - entry_price) / entry_price * 100 < 0.1  # < 0.1%
        
        if pnl_pct >= breakeven_threshold and not is_breakeven:
            return True, entry_price
        
        return False, current_sl
    
    def calculate_position_size(
        self,
        balance: float,
        entry_price: float,
        stop_loss: float,
        symbol: str = "BTCUSDT"
    ) -> Dict[str, float]:
        """
        Calcula tamanho da posição baseado em % do capital como margem
        
        MÉTODO SIMPLIFICADO:
        - Usa 2% do capital como margem direta
        - Com leverage 5x, posição será de 10% do capital
        - Simples, seguro e funcional
        
        Args:
            balance: Saldo disponível em USDT
            entry_price: Preço de entrada
            stop_loss: Preço de stop loss
            symbol: Símbolo do par
        
        Returns:
            dict: {
                'quantity': quantidade de contratos,
                'notional': valor nocional,
                'margin': margem requerida,
                'risk_amount': valor em risco
            }
        """
        # MÉTODO SIMPLIFICADO: Usar 3% do capital como margem (aumentado de 2%)
        margin_pct = 3.0  # 3% do capital como margem
        margin = balance * (margin_pct / 100)
        
        # Valor nocional com leverage
        notional = margin * self.leverage
        
        # Calcular quantidade em moeda (BTC/ETH/SOL) diretamente
        # NÃO usar contratos, usar quantidade real!
        contract_size = self._get_contract_size(symbol)
        
        # Quantidade real em moeda
        quantity_real = notional / entry_price
        
        # Limites mínimos da Bybit e arredondamento
        if 'BTC' in symbol:
            min_qty = 0.001  # Mínimo 0.001 BTC
            quantity_real = max(quantity_real, min_qty)
            quantity_real = round(quantity_real, 3)  # 3 casas decimais
        elif 'ETH' in symbol:
            min_qty = 0.01  # Mínimo 0.01 ETH
            quantity_real = max(quantity_real, min_qty)
            quantity_real = round(quantity_real, 2)  # 2 casas decimais
        elif 'SOL' in symbol:
            min_qty = 0.1  # Mínimo 0.1 SOL
            quantity_real = max(quantity_real, min_qty)
            quantity_real = round(quantity_real, 1)  # 1 casa decimal
        else:
            quantity_real = round(quantity_real, 3)
        
        # Recalcular valores finais para garantir precisão
        notional = quantity_real * entry_price
        margin = notional / self.leverage
        
        # Calcular risco real baseado no SL
        sl_distance_pct = abs(entry_price - stop_loss) / entry_price * 100
        risk_amount = notional * (sl_distance_pct / 100)
        
        logger.info(
            f"Position Size: margin={margin:.2f} ({margin_pct}%), "
            f"notional={notional:.2f}, qty={quantity_real}, "
            f"risk={risk_amount:.2f} ({risk_amount/balance*100:.2f}%)"
        )
        
        return {
            'quantity': quantity_real,  # Quantidade em moeda (BTC/ETH/SOL)
            'notional': notional,
            'margin': margin,
            'risk_amount': risk_amount,
            'sl_distance_pct': sl_distance_pct
        }
    
    def _get_contract_size(self, symbol: str) -> float:
        """Retorna tamanho do contrato para cada símbolo (V3.3.2 - 9 moedas)"""
        if 'BTC' in symbol:
            return 0.001
        elif 'ETH' in symbol:
            return 0.01
        elif 'SOL' in symbol:
            return 0.1
        elif 'BNB' in symbol:
            return 0.01
        elif 'ADA' in symbol or 'XRP' in symbol or 'DOGE' in symbol:
            return 1.0
        elif 'LINK' in symbol or 'DOT' in symbol:
            return 0.1
        else:
            return 1.0
    
    def calculate_tp_sl(
        self,
        entry_price: float,
        direction: str,
        atr: float = None,
        pattern_target: float = None,
        confidence: float = 0.70,
        **kwargs
    ) -> Dict[str, float]:
        """
        Calcula níveis de Take Profit e Stop Loss
        
        Args:
            entry_price: Preço de entrada
            direction: 'long' ou 'short'
            atr: Average True Range (para SL dinâmico)
            pattern_target: Target baseado no padrão gráfico
            confidence: Confiança do sinal (0.0-1.0)
            **kwargs: Parâmetros adicionais
        
        Returns:
            dict: {'take_profit': price, 'stop_loss': price, 'risk_reward': float}
        """
        is_long = direction.lower() == 'long'
        
        # ✨ V3.3.4 - TP/SL DINÂMICO baseado em tipo de padrão
        # Scalping (<65%) = TP/SL ultra-rápidos (1%, 5-15min)
        # Quick (65-85%) = TP/SL rápidos (2%, 45min)
        # Strong (>85%) = TP/SL amplos (5%, 4h)
        
        # Detectar tipo de padrão
        pattern_type = kwargs.get('pattern_type', '')
        is_scalping = any(x in pattern_type for x in ['scalping', 'momentum', 'pin_bar', 'inside_bar', 'micro_'])
        is_divergence = 'divergence' in pattern_type
        
        strong_threshold = 0.85
        scalping_threshold = 0.65
        
        if is_scalping:
            # SCALPING - ultra-rápido (1-15 minutos)
            tp_pct = 1.0 / 100  # 1%
            sl_pct = 0.5 / 100  # 0.5%
            logger.info(f"⚡ SCALPING ({confidence:.1%}) - TP/SL ultra-rápido (5-15min)")
        elif is_divergence:
            # DIVERGÊNCIA - médio prazo (60-120 minutos)
            tp_pct = 3.0 / 100  # 3%
            sl_pct = 1.5 / 100  # 1.5%
            logger.info(f"🔄 DIVERGÊNCIA ({confidence:.1%}) - TP/SL médio (60-120min)")
        elif confidence >= strong_threshold:
            # PADRÃO MUITO FORTE - pode esperar mais
            tp_pct = self.config.get('strong_pattern_tp_pct', 5.0) / 100  # 5%
            sl_pct = self.config.get('strong_pattern_sl_pct', 2.5) / 100  # 2.5%
            logger.info(f"✨ Padrão FORTE ({confidence:.1%}) - TP/SL amplo (2-6h)")
        else:
            # PADRÃO NORMAL - quick trade (entrada/saída rápida)
            tp_pct = self.config.get('quick_trade_tp_pct', 2.0) / 100  # 2%
            sl_pct = self.config.get('quick_trade_sl_pct', 1.0) / 100  # 1%
            logger.info(f"⚡ Quick trade ({confidence:.1%}) - TP/SL rápido (30-60min)")
        
        # Calcular TP e SL
        if is_long:
            take_profit = entry_price * (1 + tp_pct)
            stop_loss = entry_price * (1 - sl_pct)
        else:
            take_profit = entry_price * (1 - tp_pct)
            stop_loss = entry_price * (1 + sl_pct)
        
        # Garantir risk/reward mínimo de 1.5:1
        distance_to_sl = abs(entry_price - stop_loss)
        distance_to_tp = abs(take_profit - entry_price)
        
        risk_reward = distance_to_tp / distance_to_sl if distance_to_sl > 0 else 0
        
        # ✨ V3.3.1 - RR mínimo ajustado para trades mais rápidos
        min_rr = 1.5 if confidence < strong_threshold else 2.0
        if risk_reward < min_rr:
            if is_long:
                take_profit = entry_price + (distance_to_sl * min_rr)
            else:
                take_profit = entry_price - (distance_to_sl * min_rr)
            risk_reward = min_rr
        
        logger.debug(
            f"TP/SL calculado: Entry={entry_price:.2f}, "
            f"TP={take_profit:.2f}, SL={stop_loss:.2f}, RR={risk_reward:.2f}"
        )
        
        return {
            'take_profit': take_profit,
            'stop_loss': stop_loss,
            'risk_reward': risk_reward
        }
    
    def calculate_trailing_stop(
        self,
        entry_price: float,
        current_price: float,
        direction: str,
        initial_stop: float,
        trailing_pct: float = None
    ) -> float:
        """
        Calcula trailing stop loss
        
        Args:
            entry_price: Preço de entrada
            current_price: Preço atual
            direction: 'long' ou 'short'
            initial_stop: Stop loss inicial
            trailing_pct: Percentual de trailing (padrão: config)
        
        Returns:
            float: Novo stop loss
        """
        if trailing_pct is None:
            trailing_pct = self.config.get('strategy', {}).get('trailing_stop_pct', 1.0)
        
        is_long = direction.lower() == 'long'
        trail_distance = current_price * (trailing_pct / 100)
        
        if is_long:
            # Para long: SL sobe com o preço
            new_stop = current_price - trail_distance
            # SL nunca desce
            return max(new_stop, initial_stop)
        else:
            # Para short: SL desce com o preço
            new_stop = current_price + trail_distance
            # SL nunca sobe
            return min(new_stop, initial_stop)
    
    def check_daily_loss_limit(self) -> bool:
        """
        Verifica se o limite de perda diária foi atingido
        
        Returns:
            bool: True se pode continuar trading, False se deve parar
        """
        if abs(self.daily_pnl) >= self.max_daily_loss_pct:
            logger.warning(
                f"Limite de perda diária atingido: {self.daily_pnl:.2f}% "
                f"(máx: {self.max_daily_loss_pct}%)"
            )
            return False
        return True
    
    def can_open_trade(self, symbol: str, current_positions: Dict) -> Tuple[bool, str]:
        """
        Verifica se pode abrir nova posição
        
        Args:
            symbol: Símbolo a negociar
            current_positions: Dicionário de posições abertas
        
        Returns:
            tuple: (can_trade: bool, reason: str)
        """
        # Verificar limite de perda diária
        if not self.check_daily_loss_limit():
            return False, "Limite de perda diária atingido"
        
        # Verificar número total de posições
        total_positions = len(current_positions)
        if total_positions >= self.max_total_open_trades:
            return False, f"Máximo de {self.max_total_open_trades} posições abertas"
        
        # Verificar posições no mesmo símbolo
        symbol_positions = sum(1 for pos in current_positions.values() 
                              if pos.get('symbol') == symbol)
        if symbol_positions >= self.max_open_trades_per_symbol:
            return False, f"Máximo de {self.max_open_trades_per_symbol} posições em {symbol}"
        
        return True, "OK"
    
    def update_daily_pnl(self, pnl: float):
        """
        Atualiza PnL diário
        
        Args:
            pnl: Profit/Loss em percentual
        """
        self.daily_pnl += pnl
        self.daily_trades += 1
        
        logger.info(f"PnL diário atualizado: {self.daily_pnl:.2f}% ({self.daily_trades} trades)")
    
    def reset_daily_stats(self):
        """Reseta estatísticas diárias (chamar no início de cada dia)"""
        self.daily_pnl = 0.0
        self.daily_trades = 0
        logger.info("Estatísticas diárias resetadas")
    
    def validate_trade_params(
        self,
        balance: float,
        entry_price: float,
        stop_loss: float,
        take_profit: float,
        quantity: float,
        symbol: str = "BTCUSDT"
    ) -> Tuple[bool, str]:
        """
        Valida parâmetros de uma trade antes de executar
        
        Returns:
            tuple: (is_valid: bool, message: str)
        """
        # Validar preços
        if entry_price <= 0 or stop_loss <= 0 or take_profit <= 0:
            return False, "Preços inválidos"
        
        # Validar quantidade
        if quantity <= 0:
            return False, "Quantidade inválida"
        
        # Validar SL e TP fazem sentido
        sl_distance = abs(entry_price - stop_loss) / entry_price * 100
        tp_distance = abs(take_profit - entry_price) / entry_price * 100
        
        if sl_distance < 0.1:
            return False, "Stop loss muito próximo (< 0.1%)"
        
        if sl_distance > 15:  # Aumentado de 10% para 15% para acomodar volatilidade
            return False, f"Stop loss muito distante ({sl_distance:.1f}% > 15%)"
        
        if tp_distance < 0.3:  # Reduzido de 0.5% para 0.3%
            return False, f"Take profit muito próximo ({tp_distance:.1f}% < 0.3%)"
        
        # Validar risk/reward
        risk_reward = tp_distance / sl_distance
        if risk_reward < 1.0:
            return False, f"Risk/Reward muito baixo ({risk_reward:.2f})"
        
        # Calcular notional (quantity já é em moeda, não em contratos)
        notional = quantity * entry_price
        margin_required = notional / self.leverage
        
        max_margin_allowed = balance * 0.05  # 5% do saldo
        
        logger.info(
            f"Validação: qty={quantity}, "
            f"notional={notional:.2f}, margin={margin_required:.2f}, "
            f"max_allowed={max_margin_allowed:.2f}"
        )
        
        if margin_required > max_margin_allowed:
            return False, f"Margem insuficiente ({margin_required:.2f} > {max_margin_allowed:.2f} USDT, 5% do saldo)"
        
        return True, "Validação OK"
    
    def calculate_liquidation_price(
        self,
        entry_price: float,
        leverage: int,
        direction: str
    ) -> float:
        """
        Calcula preço de liquidação aproximado
        
        Args:
            entry_price: Preço de entrada
            leverage: Alavancagem utilizada
            direction: 'long' ou 'short'
        
        Returns:
            float: Preço de liquidação
        """
        is_long = direction.lower() == 'long'
        
        # Fórmula simplificada (Bybit cobra taxas de manutenção)
        # Liquidação quando perda = 100% da margem inicial
        maintenance_margin = 0.005  # 0.5% aproximado
        
        if is_long:
            # Long: liquidação abaixo do entry
            liq_price = entry_price * (1 - (1 / leverage) + maintenance_margin)
        else:
            # Short: liquidação acima do entry
            liq_price = entry_price * (1 + (1 / leverage) - maintenance_margin)
        
        return liq_price
    
    def assess_market_volatility(self, df: pd.DataFrame) -> Dict[str, any]:
        """
        Avalia volatilidade do mercado para ajustar risco
        
        Args:
            df: DataFrame com dados OHLCV
        
        Returns:
            dict: {
                'volatility': 'low'/'medium'/'high',
                'atr_pct': float,
                'risk_adjustment': float (multiplicador de risco)
            }
        """
        if 'atr' not in df.columns or len(df) < 14:
            return {
                'volatility': 'unknown',
                'atr_pct': 0,
                'risk_adjustment': 1.0
            }
        
        atr = df['atr'].iloc[-1]
        current_price = df['close'].iloc[-1]
        atr_pct = (atr / current_price) * 100
        
        # Classificar volatilidade
        if atr_pct < 1.0:
            volatility = 'low'
            risk_adjustment = 1.2  # Pode aumentar risco em baixa volatilidade
        elif atr_pct < 2.5:
            volatility = 'medium'
            risk_adjustment = 1.0
        else:
            volatility = 'high'
            risk_adjustment = 0.7  # Reduzir risco em alta volatilidade
        
        logger.debug(f"Volatilidade: {volatility} (ATR: {atr_pct:.2f}%)")
        
        return {
            'volatility': volatility,
            'atr_pct': atr_pct,
            'risk_adjustment': risk_adjustment
        }
    
    def get_position_summary(self, positions: list) -> Dict:
        """
        Gera resumo das posições abertas
        
        Args:
            positions: Lista de posições
        
        Returns:
            dict: Resumo com métricas
        """
        if not positions:
            return {
                'total_positions': 0,
                'total_unrealized_pnl': 0,
                'total_margin_used': 0,
                'avg_leverage': 0
            }
        
        total_pnl = sum(pos.get('unrealized_pnl', 0) for pos in positions)
        total_margin = sum(pos.get('size', 0) * pos.get('entry_price', 0) / 
                          pos.get('leverage', 1) for pos in positions)
        avg_leverage = sum(pos.get('leverage', 0) for pos in positions) / len(positions)
        
        return {
            'total_positions': len(positions),
            'total_unrealized_pnl': total_pnl,
            'total_margin_used': total_margin,
            'avg_leverage': avg_leverage,
            'positions_by_symbol': {pos['symbol']: pos.get('side') for pos in positions}
        }
    
    def emergency_close_check(
        self,
        position: Dict,
        current_price: float
    ) -> Tuple[bool, str]:
        """
        Verifica se posição deve ser fechada emergencialmente
        
        Args:
            position: Dados da posição
            current_price: Preço atual
        
        Returns:
            tuple: (should_close: bool, reason: str)
        """
        entry_price = position.get('entry_price', 0)
        side = position.get('side', '')
        unrealized_pnl_pct = position.get('unrealized_pnl', 0)
        
        # Validar entry_price para evitar divisão por zero
        if entry_price <= 0 or current_price <= 0:
            logger.warning(f"Preços inválidos para emergency check: entry={entry_price}, current={current_price}")
            return False, "Preços inválidos"
        
        # Calcular perda atual
        if side == 'Buy':
            loss_pct = ((current_price - entry_price) / entry_price) * 100
        else:
            loss_pct = ((entry_price - current_price) / entry_price) * 100
        
        # Fechar se perda exceder limite máximo
        if loss_pct < -self.max_position_loss_pct:
            return True, f"Perda máxima excedida: {loss_pct:.2f}%"
        
        return False, "OK"