import aiohttp
import time
import hmac
import hashlib
import json
import logging
import asyncio


class BybitExchange:
    def __init__(self, config):
        """
        Inicializa a exchange usando o dicionário de configuração do runner.py.
        Espera as chaves:
            config["api_key"]
            config["api_secret"]
            config["testnet"]
        """
        self.api_key = config.get("api_key")
        self.api_secret = config.get("api_secret")
        self.base_url = "https://api-testnet.bybit.com" if config.get("testnet", True) else "https://api.bybit.com"
        self.testnet = config.get("testnet", True)
        self.session = None
        self.time_offset = 0

        # Configura logger
        self.logger = logging.getLogger("BybitExchange")
        self.logger.setLevel(logging.INFO)
        
        # Log de inicialização
        mode = "TESTNET" if self.testnet else "MAINNET"
        self.logger.info(f"BybitExchange inicializado em modo {mode}")
        self.logger.info(f"URL base: {self.base_url}")

    # ----------------------------------------
    # Inicialização da sessão HTTP
    # ----------------------------------------
    async def initialize(self):
        """Cria a sessão HTTP e sincroniza o horário com o servidor."""
        if self.session is None:
            self.session = aiohttp.ClientSession()
        await self.sync_server_time()

    async def close(self):
        """Fecha a sessão HTTP aberta."""
        if self.session:
            await self.session.close()
            self.logger.info("Sessão HTTP fechada")

    # ----------------------------------------
    # Sincronização de tempo
    # ----------------------------------------
    async def sync_server_time(self, retries=5):
        """Sincroniza o tempo local com o servidor Bybit (melhorado)"""
        url = f"{self.base_url}/v5/market/time"
        
        for i in range(retries):
            try:
                # Usar sessão temporária se a principal não existir
                if self.session is None:
                    async with aiohttp.ClientSession() as temp_session:
                        async with temp_session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                if "result" in data and "timeSecond" in data["result"]:
                                    server_ts = int(data["result"]["timeSecond"]) * 1000
                                    local_ts = int(time.time() * 1000)
                                    self.time_offset = server_ts - local_ts
                                    
                                    # Log detalhado para debug
                                    self.logger.info(f"Timestamp sincronizado: offset={self.time_offset}ms (local: {local_ts}, server: {server_ts})")
                                    return
                else:
                    async with self.session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            if "result" in data and "timeSecond" in data["result"]:
                                server_ts = int(data["result"]["timeSecond"]) * 1000
                                local_ts = int(time.time() * 1000)
                                self.time_offset = server_ts - local_ts
                                
                                self.logger.info(f"Timestamp sincronizado: offset={self.time_offset}ms")
                                return
            except Exception as e:
                self.logger.warning(f"Tentativa {i+1}/{retries} de sincronização falhou: {e}")
                await asyncio.sleep(1)  # Aumentado de 0.5s para 1s
        
        # Se falhar, tentar usar offset conservador de +1s
        self.time_offset = 1000
        self.logger.warning(f"Sincronização falhou, usando offset conservador: +{self.time_offset}ms")

    def _timestamp(self):
        """Retorna timestamp atual com offset"""
        return int(time.time() * 1000 + self.time_offset)

    # ----------------------------------------
    # Requisição genérica à API da Bybit
    # ----------------------------------------
    async def _make_request(self, method, endpoint, params=None, auth=True):
        """Faz uma requisição assíncrona à API Bybit."""
        if self.session is None:
            self.session = aiohttp.ClientSession()

        url = f"{self.base_url}{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
        
        if params is None:
            params = {}

        if auth:
            timestamp = self._timestamp()
            recv_window = 20000  # Aumentado de 5000 para 20000ms para maior tolerância
            
            # Preparar string de parâmetros baseado no método
            if method == "GET":
                # Para GET, usar query string ordenada
                param_str = "&".join([f"{k}={v}" for k, v in sorted(params.items())])
            else:
                # Para POST, usar JSON
                param_str = json.dumps(params) if params else ""
            
            # Criar string para assinatura
            sign_str = f"{timestamp}{self.api_key}{recv_window}{param_str}"
            
            # Gerar assinatura
            signature = hmac.new(
                self.api_secret.encode("utf-8"),
                sign_str.encode("utf-8"),
                hashlib.sha256
            ).hexdigest()
            
            # Adicionar headers de autenticação
            headers["X-BAPI-API-KEY"] = self.api_key
            headers["X-BAPI-TIMESTAMP"] = str(timestamp)
            headers["X-BAPI-SIGN"] = signature
            headers["X-BAPI-RECV-WINDOW"] = str(recv_window)

        try:
            async with self.session.request(
                method,
                url,
                json=params if method == "POST" else None,
                params=params if method == "GET" else None,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                text = await resp.text()
                try:
                    data = json.loads(text)
                except json.JSONDecodeError:
                    self.logger.error(f"Erro ao decodificar resposta: {text}")
                    return None

                if "retCode" in data and data["retCode"] != 0:
                    # Não logar erro 110043 (leverage not modified)
                    if data.get("retCode") != 110043:
                        self.logger.error(f"Erro da API Bybit ({endpoint}): {data}")
                return data
        except Exception as e:
            self.logger.error(f"Erro na requisição {method} {endpoint}: {e}")
            return None

    # ----------------------------------------
    # Definir alavancagem
    # ----------------------------------------
    async def set_leverage(self, symbol: str, leverage: int = 5):
        """Define a alavancagem para um símbolo específico."""
        try:
            params = {
                "category": "linear",
                "symbol": symbol,
                "buyLeverage": str(leverage),
                "sellLeverage": str(leverage)
            }
            response = await self._make_request("POST", "/v5/position/set-leverage", params)
            if not response:
                self.logger.error(f"Erro ao definir alavancagem para {symbol}: resposta vazia")
                return False

            if response.get("retCode") == 0:
                self.logger.info(f"Alavancagem {leverage}x definida para {symbol}")
                return True
            elif response.get("retCode") == 110043:
                # Alavancagem já está no valor solicitado (não é erro)
                return True
            else:
                self.logger.warning(f"Não foi possível alterar alavancagem para {symbol}")
                return False

        except Exception as e:
            self.logger.error(f"Erro ao definir alavancagem de {symbol}: {e}")
            return False

    # ----------------------------------------
    # Obter saldo da conta
    # ----------------------------------------
    async def get_balance(self):
        """Obtém o saldo disponível em USDT na conta Bybit."""
        try:
            params = {"accountType": "UNIFIED"}
            response = await self._make_request("GET", "/v5/account/wallet-balance", params)
            if not response:
                self.logger.error("Erro: resposta vazia ao consultar saldo.")
                return 0.0

            if response.get("retCode") == 0:
                balances = response["result"]["list"][0]["coin"]
                for coin in balances:
                    if coin["coin"] == "USDT":
                        # Usar walletBalance se availableToWithdraw estiver vazio
                        available_str = coin.get("availableToWithdraw", "") or coin.get("walletBalance", "0")
                        try:
                            available = float(available_str)
                            self.logger.info(f"Saldo disponível: {available:.2f} USDT")
                            return available
                        except (ValueError, TypeError):
                            self.logger.warning(f"Erro ao converter saldo: {available_str}")
                            return 0.0
                self.logger.warning("USDT não encontrado no saldo.")
                return 0.0
            else:
                self.logger.error(f"Erro ao obter saldo: {response}")
                return 0.0

        except Exception as e:
            self.logger.error(f"Erro ao consultar saldo: {e}")
            return 0.0

    async def get_positions(self, symbol: str):
        """Obtém posições abertas para o símbolo informado."""
        try:
            params = {"category": "linear", "symbol": symbol}
            response = await self._make_request("GET", "/v5/position/list", params)
            if response and response.get("retCode") == 0:
                positions = response["result"]["list"]
                # Filtrar posições com size > 0
                active_positions = [p for p in positions if float(p.get('size', 0)) > 0]
                return active_positions
            else:
                self.logger.error(f"Erro ao obter posições: {response}")
                return []
        except Exception as e:
            self.logger.error(f"Erro ao consultar posições: {e}")
            return []

    async def get_klines(self, symbol: str, interval: str, limit: int = 200):
        """
        Obtém candles históricos da Bybit - COM CACHE BUSTING
        
        IMPORTANTE: A API Bybit retorna dados em ordem DECRESCENTE (mais recente primeiro)
        """
        import time
        from datetime import datetime
        
        # CRÍTICO: Forçar dados frescos com múltiplas técnicas anti-cache
        current_time = int(time.time() * 1000)
        
        params = {
            "category": "linear",
            "symbol": symbol,
            "interval": interval,
            "limit": limit,
            "end": current_time  # FORÇA dados até agora (quebra cache)
        }
        
        # Extra: adicionar parâmetro único para quebrar cache de proxy/CDN
        import random
        cache_buster = f"{current_time}{random.randint(1000, 9999)}"
        params["_cb"] = cache_buster  # Cache buster adicional
        
        self.logger.debug(f"📡 Obtendo klines: {symbol} {interval} (end={current_time})")
        
        response = await self._make_request("GET", "/v5/market/kline", params, auth=False)
        if response and response.get("retCode") == 0:
            klines = response["result"]["list"]
            
            if klines and len(klines) > 0:
                # Log do primeiro e último candle (em ordem decrescente)
                first_ts = int(klines[0][0])  # Mais recente
                last_ts = int(klines[-1][0])  # Mais antigo
                last_close = float(klines[0][4])  # Close mais recente
                
                first_time = datetime.fromtimestamp(first_ts / 1000)
                last_time = datetime.fromtimestamp(last_ts / 1000)
                current_datetime = datetime.fromtimestamp(current_time / 1000)
                
                # Calcular idade da última vela
                age_minutes = (current_time - first_ts) / 1000 / 60
                
                self.logger.info(
                    f"📊 {symbol} {interval}: {len(klines)} candles | "
                    f"Última: {first_time.strftime('%H:%M:%S')} ({age_minutes:.1f}min atrás) | "
                    f"Close: {last_close:.2f}"
                )
                
                # ALERTA se dados muito antigos (sinal de cache) - APENAS DEBUG
                max_age = {
                    '15m': 16,
                    '1h': 65,
                    '2h': 125,
                    '4h': 245
                }.get(interval, 30)
                
                if age_minutes > max_age:
                    # Apenas debug para não poluir logs
                    self.logger.debug(
                        f"⏰ {symbol} {interval}: vela {age_minutes:.0f}min atrás (máx: {max_age}min)"
                    )
            
            return klines
        else:
            self.logger.warning(f"Falha ao obter klines para {symbol} {interval}")
            return []

    async def get_ticker(self, symbol: str):
        """Obtém ticker (preço atual) do símbolo"""
        try:
            params = {
                "category": "linear",
                "symbol": symbol
            }
            response = await self._make_request("GET", "/v5/market/tickers", params, auth=False)
            if response and response.get("retCode") == 0:
                tickers = response["result"]["list"]
                if tickers:
                    ticker = tickers[0]
                    return {
                        'symbol': ticker['symbol'],
                        'last_price': float(ticker['lastPrice']),
                        'bid': float(ticker['bid1Price']),
                        'ask': float(ticker['ask1Price']),
                        'volume': float(ticker['volume24h'])
                    }
            return None
        except Exception as e:
            self.logger.error(f"Erro ao obter ticker {symbol}: {e}")
            return None

    async def place_order(self, symbol: str, side: str, qty: float, order_type: str = "Market", 
                         take_profit: float = None, stop_loss: float = None):
        """Coloca uma ordem na Bybit com TP/SL"""
        try:
            params = {
                "category": "linear",
                "symbol": symbol,
                "side": side,
                "orderType": order_type,
                "qty": str(qty),
                "timeInForce": "GTC"
            }
            
            # Adicionar TP/SL se fornecidos
            if take_profit and take_profit > 0:
                params["takeProfit"] = str(round(take_profit, 2))
                self.logger.info(f"TP definido: {take_profit:.2f}")
            if stop_loss and stop_loss > 0:
                params["stopLoss"] = str(round(stop_loss, 2))
                self.logger.info(f"SL definido: {stop_loss:.2f}")
            
            self.logger.info(f"Enviando ordem: {side} {qty} {symbol} @ Market")
            response = await self._make_request("POST", "/v5/order/create", params)
            
            if response and response.get("retCode") == 0:
                result = response["result"]
                self.logger.info(f"✓ Ordem executada: {result['orderId']}")
                return {
                    'order_id': result['orderId'],
                    'symbol': symbol,
                    'side': side,
                    'qty': qty,
                    'take_profit': take_profit,
                    'stop_loss': stop_loss
                }
            else:
                error_msg = response.get('retMsg', 'Unknown error') if response else 'No response'
                self.logger.error(f"Erro ao criar ordem: {error_msg}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro ao colocar ordem: {e}", exc_info=True)
            return None

    async def close_position(self, symbol: str):
        """Fecha uma posição aberta"""
        try:
            # Primeiro, obter a posição atual
            positions = await self.get_positions(symbol)
            if not positions:
                self.logger.warning(f"Nenhuma posição encontrada para {symbol}")
                return False
            
            position = positions[0]
            side = position.get('side', '')
            size = float(position.get('size', 0))
            
            if size == 0:
                self.logger.warning(f"Posição {symbol} já está fechada")
                return True
            
            # Determinar lado da ordem de fechamento
            close_side = "Sell" if side == "Buy" else "Buy"
            
            self.logger.info(f"Fechando posição {symbol}: {side} {size}")
            
            # Criar ordem de mercado para fechar
            params = {
                "category": "linear",
                "symbol": symbol,
                "side": close_side,
                "orderType": "Market",
                "qty": str(size),
                "reduceOnly": True,
                "timeInForce": "GTC"
            }
            
            response = await self._make_request("POST", "/v5/order/create", params)
            
            if response and response.get("retCode") == 0:
                self.logger.info(f"✓ Posição {symbol} fechada com sucesso")
                return True
            else:
                error_msg = response.get('retMsg', 'Unknown error') if response else 'No response'
                self.logger.error(f"Erro ao fechar posição: {error_msg}")
                return False
                
        except Exception as e:
            self.logger.error(f"Erro ao fechar posição {symbol}: {e}", exc_info=True)
            return False
    
    async def set_trading_stop(self, symbol: str, take_profit: float = None, stop_loss: float = None):
        """
        Atualiza TP/SL de uma posição existente
        
        Args:
            symbol: Símbolo da posição
            take_profit: Novo preço de take profit
            stop_loss: Novo preço de stop loss
        
        Returns:
            bool: True se atualizado com sucesso
        """
        try:
            params = {
                "category": "linear",
                "symbol": symbol,
                "positionIdx": 0  # 0 para modo one-way
            }
            
            if take_profit and take_profit > 0:
                params["takeProfit"] = str(round(take_profit, 2))
            
            if stop_loss and stop_loss > 0:
                params["stopLoss"] = str(round(stop_loss, 2))
            
            if not take_profit and not stop_loss:
                self.logger.warning("set_trading_stop chamado sem TP ou SL")
                return False
            
            self.logger.info(f"Atualizando TP/SL para {symbol}")
            response = await self._make_request("POST", "/v5/position/trading-stop", params)
            
            if response and response.get("retCode") == 0:
                self.logger.info(f"✓ TP/SL atualizado para {symbol}")
                return True
            elif response and response.get("retCode") == 34040:
                # Erro "not modified" - valores já estão corretos
                self.logger.debug(f"TP/SL já está no valor solicitado para {symbol}")
                return True  # Considerar sucesso, pois já está correto
            else:
                error_msg = response.get('retMsg', 'Unknown error') if response else 'No response'
                self.logger.error(f"Erro ao atualizar TP/SL: {error_msg}")
                return False
        
        except Exception as e:
            self.logger.error(f"Erro ao atualizar TP/SL: {e}", exc_info=True)
            return False