"""
Módulo de estratégia de trading
Combina padrões gráficos e indicadores para gerar sinais
"""
import pandas as pd
from typing import Tuple, List, Dict, Optional
from .pattern_detector import PatternDetector
from .indicators import IndicatorSignals, TechnicalIndicators
from .risk import RiskManager
from .utils import setup_logger

logger = setup_logger("strategy")


class TradingStrategy:
    """Estratégia de trading combinando padrões e indicadores"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.pattern_detector = PatternDetector(
            min_confidence=config.get('strategy', {}).get('min_pattern_confidence', 0.6)  # Reduzido de 0.7 para 0.6
        )
        self.risk_manager = RiskManager(config)
        self.min_indicators_confirmation = config.get('strategy', {}).get(
            'min_indicators_confirmation', 1  # Reduzido de 2 para 1
        )
        self.volume_threshold = config.get('strategy', {}).get('volume_threshold', 1.2)  # Reduzido de 1.5 para 1.2
        
        logger.info("TradingStrategy inicializada com parâmetros otimizados")
    
    def analyze_market(
        self,
        symbol: str,
        timeframe: str,
        df: pd.DataFrame
    ) -> Dict:
        """
        Analisa mercado e gera sinal de trading
        
        Args:
            symbol: Par de negociação
            timeframe: Timeframe analisado
            df: DataFrame com dados OHLCV e indicadores
        
        Returns:
            dict: {
                'symbol': str,
                'timeframe': str,
                'signal': 'long'/'short'/'neutral',
                'confidence': 0-1,
                'patterns': [...],
                'indicators': {...},
                'entry_price': float,
                'take_profit': float,
                'stop_loss': float,
                'reason': str
            }
        """
        if len(df) < 50:
            return self._neutral_signal(symbol, timeframe, "Dados insuficientes")
        
        # Log do preço atual para verificar se está mudando
        current_price = df['close'].iloc[-1]
        prev_price = df['close'].iloc[-2]
        price_change_pct = ((current_price - prev_price) / prev_price * 100)
        logger.debug(f"{symbol} {timeframe}: Price={current_price:.2f} ({price_change_pct:+.3f}%)")
        
        try:
            # Calcular indicadores se não existirem
            if 'ema_9' not in df.columns:
                df = IndicatorSignals.calculate_all_indicators(df)
            
            # Detectar padrões gráficos
            patterns = self.pattern_detector.detect_all_patterns(df)
            
            # Obter sinais de indicadores
            indicator_signal = IndicatorSignals.get_combined_signal(df)
            
            # Analisar volume
            volume_info = TechnicalIndicators.analyze_volume(df['volume'])
            volume_confirmed = volume_info['ratio'] >= self.volume_threshold
            
            # Preço atual
            current_price = df['close'].iloc[-1]
            atr = df['atr'].iloc[-1] if 'atr' in df.columns else None
            
            # Decisão de trading
            decision = self._make_trading_decision(
                patterns=patterns,
                indicator_signal=indicator_signal,
                volume_confirmed=volume_confirmed,
                current_price=current_price,
                atr=atr,
                df=df
            )
            
            decision['symbol'] = symbol
            decision['timeframe'] = timeframe
            
            return decision
        
        except Exception as e:
            logger.error(f"Erro ao analisar {symbol} {timeframe}: {e}")
            return self._neutral_signal(symbol, timeframe, f"Erro: {e}")
    
    def _make_trading_decision(
        self,
        patterns: List[Dict],
        indicator_signal: Dict,
        volume_confirmed: bool,
        current_price: float,
        atr: float,
        df: pd.DataFrame
    ) -> Dict:
        """Toma decisão de trading baseada em todos os sinais"""
        
        # Verificar se há padrão forte
        best_pattern = patterns[0] if patterns else None
        
        # Sinais dos indicadores
        ind_signal = indicator_signal['signal']
        ind_confidence = indicator_signal['confidence']
        ind_details = indicator_signal.get('indicators', {})
        
        # Contar confirmações e calcular scores
        confirmations = 0
        reasons = []
        long_score = 0.0
        short_score = 0.0
        
        # Padrão gráfico (reduzido threshold de 0.7 para 0.6)
        if best_pattern and best_pattern['confidence'] >= 0.6:
            pattern_direction = best_pattern['direction']
            if pattern_direction == 'long':
                long_score += best_pattern['confidence']
                confirmations += 1
                reasons.append(f"Padrão {best_pattern['type']} (conf: {best_pattern['confidence']:.2f})")
            elif pattern_direction == 'short':
                short_score += best_pattern['confidence']
                confirmations += 1
                reasons.append(f"Padrão {best_pattern['type']} (conf: {best_pattern['confidence']:.2f})")
        
        # Indicadores
        if ind_signal == 'long':
            long_score += ind_confidence
            confirmations += 1
            reasons.append(f"Indicadores LONG (EMA: {ind_details.get('ema', 'N/A')}, RSI: {ind_details.get('rsi_value', 0):.1f}, MACD: {ind_details.get('macd', 'N/A')})")
        elif ind_signal == 'short':
            short_score += ind_confidence
            confirmations += 1
            reasons.append(f"Indicadores SHORT (EMA: {ind_details.get('ema', 'N/A')}, RSI: {ind_details.get('rsi_value', 0):.1f}, MACD: {ind_details.get('macd', 'N/A')})")
        else:
            # Log de indicadores neutros para debug
            logger.debug(f"Indicadores neutros - EMA: {ind_details.get('ema', 'N/A')}, RSI: {ind_details.get('rsi_value', 0):.1f}, MACD: {ind_details.get('macd', 'N/A')}")
        
        # Volume (adiciona peso ao sinal existente)
        if volume_confirmed:
            vol_ratio = ind_details.get('volume_ratio', 1.0)
            if long_score > 0:
                long_score += 0.1  # Boost para volume
            if short_score > 0:
                short_score += 0.1  # Boost para volume
            reasons.append(f"Volume confirmado (ratio: {vol_ratio:.2f})")
        
        # Decisão final (relaxado para permitir 1 confirmação se score for alto)
        if confirmations == 0:
            return {
                'signal': 'neutral',
                'confidence': 0.0,
                'patterns': patterns,
                'indicators': indicator_signal,
                'entry_price': None,
                'take_profit': None,
                'stop_loss': None,
                'reason': f"Nenhuma confirmação (ind: {ind_signal}, patterns: {len(patterns)})",
                'details': f"RSI: {ind_details.get('rsi_value', 0):.1f}, EMA: {ind_details.get('ema', 'N/A')}, MACD: {ind_details.get('macd', 'N/A')}"
            }
        
        # V3.3.6 - Penalizar sinais conflitantes (MÍNIMA - 5%)
        score_diff = abs(long_score - short_score)
        conflict_penalty = 1.0
        if long_score > 0 and short_score > 0:
            # Se ambos os scores são altos, há conflito (penalidade MÍNIMA: 5%)
            conflict_penalty = max(0.95, 1.0 - (min(long_score, short_score) * 0.05))
            logger.debug(f"Sinais conflitantes detectados! Long: {long_score:.2f}, Short: {short_score:.2f}, Penalidade: {conflict_penalty:.2f}")
        
        # Determinar direção pelo score
        if long_score > short_score and long_score > 0:
            final_signal = 'long'
            # V3.3.7 - Fórmula OTIMIZADA para confiança >= 60% (divisor 1.1)
            confidence = min((long_score / 1.1) * conflict_penalty, 0.95)  # Max 95%
        elif short_score > long_score and short_score > 0:
            final_signal = 'short'
            # V3.3.7 - Fórmula OTIMIZADA para confiança >= 60% (divisor 1.1)
            confidence = min((short_score / 1.1) * conflict_penalty, 0.95)  # Max 95%
        else:
            return {
                'signal': 'neutral',
                'confidence': 0.0,
                'patterns': patterns,
                'indicators': indicator_signal,
                'entry_price': None,
                'take_profit': None,
                'stop_loss': None,
                'reason': f"Sinais equilibrados (long: {long_score:.2f}, short: {short_score:.2f})",
                'details': f"Confirmações: {confirmations}, Padrões: {len(patterns)}"
            }
        
        # Calcular TP/SL
        pattern_target = best_pattern.get('target') if best_pattern else None
        pattern_type = best_pattern.get('type', '') if best_pattern else ''
        tp_sl = self.risk_manager.calculate_tp_sl(
            entry_price=current_price,
            direction=final_signal,
            atr=atr,
            pattern_target=pattern_target,
            confidence=confidence,
            pattern_type=pattern_type  # ✨ V3.3.4 - Para detectar scalping/divergências
        )
        
        logger.info(
            f"✓ Sinal gerado: {final_signal.upper()} "
            f"(confiança: {confidence:.2%}, confirmações: {confirmations}) | {' | '.join(reasons)}"
        )
        
        return {
            'signal': final_signal,
            'confidence': confidence,
            'patterns': patterns,
            'indicators': indicator_signal,
            'entry_price': current_price,
            'take_profit': tp_sl['take_profit'],
            'stop_loss': tp_sl['stop_loss'],
            'risk_reward': tp_sl['risk_reward'],
            'reason': ' | '.join(reasons),
            'confirmations': confirmations
        }
    
    def _neutral_signal(self, symbol: str, timeframe: str, reason: str) -> Dict:
        """Retorna sinal neutro"""
        return {
            'symbol': symbol,
            'timeframe': timeframe,
            'signal': 'neutral',
            'confidence': 0.0,
            'patterns': [],
            'indicators': {},
            'entry_price': None,
            'take_profit': None,
            'stop_loss': None,
            'reason': reason
        }
    
    def analyze_multiple_timeframes(
        self,
        symbol: str,
        timeframes_data: Dict[str, pd.DataFrame]
    ) -> Dict:
        """
        Analisa múltiplos timeframes e gera consenso
        
        Args:
            symbol: Par de negociação
            timeframes_data: Dict {timeframe: DataFrame}
        
        Returns:
            dict: Sinal consolidado de todos os timeframes
        """
        signals = {}
        
        # Analisar cada timeframe
        for timeframe, df in timeframes_data.items():
            signal = self.analyze_market(symbol, timeframe, df)
            signals[timeframe] = signal
        
        # Criar consenso
        consensus = self._build_consensus(signals)
        
        # Emoji baseado no sinal
        from datetime import datetime
        now = datetime.now().strftime('%H:%M:%S')
        
        signal_emoji = {
            'long': '📈',
            'short': '📉',
            'neutral': '➖'
        }
        emoji = signal_emoji.get(consensus['signal'], '❓')
        
        # Status do sinal
        signal_status = "✅ ENTRADA VÁLIDA" if consensus['signal'] in ['long', 'short'] else "⏸️  SEM ENTRADA"
        
        # Log detalhado do consenso
        signal_counts = consensus.get('signal_count', {'long': 0, 'short': 0, 'neutral': 0})
        logger.info(
            f"\n{'='*70}\n"
            f"{emoji} [{now}] {symbol} - Consenso: {consensus['signal'].upper()} "
            f"(score: {consensus['consensus_score']:.2%})\n"
            f"├─ Long Score: {consensus.get('long_score', 0):.2%} | Short Score: {consensus.get('short_score', 0):.2%}\n"
            f"├─ Sinais: {signal_counts['long']}L / {signal_counts['short']}S / {signal_counts['neutral']}N\n"
            f"├─ Razão: {consensus.get('reason', 'N/A')}\n"
            f"├─ Timeframe base: {consensus.get('base_timeframe', 'N/A')}\n"
            f"└─ Status: {signal_status}\n"
            f"{'='*70}"
        )
        
        # Log individual de cada timeframe (TODOS, não só os não-neutros)
        for tf in ['15m', '1h', '2h', '4h']:
            if tf in signals:
                sig = signals[tf]
                if sig['signal'] != 'neutral':
                    sig_emoji = signal_emoji.get(sig['signal'], '❓')
                    logger.info(
                        f"  {sig_emoji} [{tf:>3}] {sig['signal'].upper():>6} (conf: {sig.get('confidence', 0):>5.1%}) - {sig.get('reason', 'N/A')}"
                    )
        
        return consensus
    
    def _build_consensus(self, signals: Dict[str, Dict]) -> Dict:
        """
        Cria consenso entre múltiplos timeframes com análise de tendência
        
        LÓGICA MELHORADA:
        1. Identifica tendência dominante (maior número de timeframes)
        2. Verifica força do sinal (confiança média)
        3. Aceita sinais fortes mesmo de timeframes menores
        4. Prioriza alinhamento entre timeframes maiores
        """
        timeframe_weights = {
            '15m': 1.0,   # Entrada rápida
            '1h': 2.0,    # Tendência de curto prazo
            '2h': 2.5,    # Tendência intermediária
            '4h': 3.0     # Tendência principal
        }
        
        long_score = 0.0
        short_score = 0.0
        neutral_count = 0
        total_weight = 0.0
        
        # Contar sinais por direção
        long_signals = []
        short_signals = []
        
        for tf, signal in signals.items():
            weight = timeframe_weights.get(tf, 1.0)
            confidence = signal.get('confidence', 0)
            
            if signal['signal'] == 'long':
                long_score += confidence * weight
                long_signals.append((tf, confidence, weight))
            elif signal['signal'] == 'short':
                short_score += confidence * weight
                short_signals.append((tf, confidence, weight))
            else:
                neutral_count += 1
            
            total_weight += weight
        
        # Normalizar scores
        if total_weight > 0:
            long_score_normalized = long_score / total_weight
            short_score_normalized = short_score / total_weight
        else:
            long_score_normalized = 0.0
            short_score_normalized = 0.0
        
        # LÓGICA DE DECISÃO MELHORADA (conservadora para 15m)
        final_signal = 'neutral'
        consensus_score = 0.0
        reason = ""
        
        # Verificar se há sinais válidos
        if len(long_signals) > 0 or len(short_signals) > 0:
            # Caso 1: Múltiplos timeframes concordam (score normalizado > 20%)
            if long_score_normalized > short_score_normalized:
                if long_score_normalized >= 0.20:  # Reduzido de 0.30 para 0.20
                    final_signal = 'long'
                    consensus_score = long_score_normalized
                    reason = f"{len(long_signals)} timeframe(s) LONG"
                # Caso 2: Sinal forte APENAS em timeframes importantes (1h, 2h, 4h) com conf > 55%
                elif any(tf in ['1h', '2h', '4h'] and conf >= 0.55 for tf, conf, _ in long_signals):
                    final_signal = 'long'
                    # Usar o sinal com maior confiança dos TFs importantes
                    important_signals = [(tf, conf, w) for tf, conf, w in long_signals if tf in ['1h', '2h', '4h']]
                    best_signal = max(important_signals, key=lambda x: x[1])  # maior confiança
                    consensus_score = best_signal[1]  # usar confiança original
                    reason = f"Sinal FORTE em {best_signal[0]} ({best_signal[1]:.1%})"
                # Caso 3: Múltiplos sinais fracos podem formar consenso (2+ timeframes)
                elif len(long_signals) >= 2:
                    # Calcular média de confiança dos sinais
                    avg_confidence = sum(conf for _, conf, _ in long_signals) / len(long_signals)
                    if avg_confidence >= 0.45:  # Média de 45%+
                        final_signal = 'long'
                        consensus_score = avg_confidence
                        reason = f"{len(long_signals)} timeframes LONG (média: {avg_confidence:.1%})"
            
            elif short_score_normalized > long_score_normalized:
                if short_score_normalized >= 0.20:
                    final_signal = 'short'
                    consensus_score = short_score_normalized
                    reason = f"{len(short_signals)} timeframe(s) SHORT"
                elif any(tf in ['1h', '2h', '4h'] and conf >= 0.55 for tf, conf, _ in short_signals):
                    final_signal = 'short'
                    important_signals = [(tf, conf, w) for tf, conf, w in short_signals if tf in ['1h', '2h', '4h']]
                    best_signal = max(important_signals, key=lambda x: x[1])
                    consensus_score = best_signal[1]
                    reason = f"Sinal FORTE em {best_signal[0]} ({best_signal[1]:.1%})"
                elif len(short_signals) >= 2:
                    avg_confidence = sum(conf for _, conf, _ in short_signals) / len(short_signals)
                    if avg_confidence >= 0.45:
                        final_signal = 'short'
                        consensus_score = avg_confidence
                        reason = f"{len(short_signals)} timeframes SHORT (média: {avg_confidence:.1%})"
        
        # Se ainda neutro, verificar razão
        if final_signal == 'neutral':
            if neutral_count == len(signals):
                reason = "Todos os timeframes neutros"
            elif len(long_signals) > 0 and len(short_signals) > 0:
                reason = f"Sinais conflitantes (L:{len(long_signals)} vs S:{len(short_signals)})"
            else:
                reason = f"Confiança insuficiente (L:{long_score_normalized:.1%}, S:{short_score_normalized:.1%})"
        
        # Escolher timeframe base para TP/SL
        if final_signal == 'long' and long_signals:
            # Usar o timeframe com maior peso que tem sinal
            base_tf = max(long_signals, key=lambda x: x[2])[0]
        elif final_signal == 'short' and short_signals:
            base_tf = max(short_signals, key=lambda x: x[2])[0]
        else:
            # Usar timeframe mais alto disponível
            base_tf = max(signals.keys(), key=lambda x: timeframe_weights.get(x, 0))
        
        base_signal = signals[base_tf]
        
        # Identificar padrão dominante para ML
        dominant_pattern = 'unknown'
        if base_signal and base_signal.get('patterns'):
            patterns = base_signal['patterns']
            if patterns:
                # Usar padrão com maior confiança
                dominant_pattern = max(patterns, key=lambda x: x.get('confidence', 0)).get('type', 'unknown')
        
        return {
            'signal': final_signal,
            'consensus_score': consensus_score,
            'timeframe_signals': signals,
            'entry_price': base_signal.get('entry_price'),
            'take_profit': base_signal.get('take_profit'),
            'stop_loss': base_signal.get('stop_loss'),
            'long_score': long_score_normalized,
            'short_score': short_score_normalized,
            'base_timeframe': base_tf,
            'reason': reason,
            'signal_count': {'long': len(long_signals), 'short': len(short_signals), 'neutral': neutral_count},
            'dominant_pattern': dominant_pattern  # Para ML
        }
    
    def should_close_position(
        self,
        position: Dict,
        current_price: float,
        df: pd.DataFrame
    ) -> Tuple[bool, str]:
        """
        Verifica se deve fechar uma posição existente
        
        Args:
            position: Dados da posição
            current_price: Preço atual
            df: DataFrame com dados atualizados
        
        Returns:
            tuple: (should_close: bool, reason: str)
        """
        entry_price = position.get('entry_price', 0)
        side = position.get('side', '')
        tp = position.get('tp', 0)
        sl = position.get('sl', 0)
        
        # Verificar TP/SL
        if side == 'Buy':  # Long
            if tp and current_price >= tp:
                return True, f"Take Profit atingido ({tp})"
            if sl and current_price <= sl:
                return True, f"Stop Loss atingido ({sl})"
        else:  # Short
            if tp and current_price <= tp:
                return True, f"Take Profit atingido ({tp})"
            if sl and current_price >= sl:
                return True, f"Stop Loss atingido ({sl})"
        
        # Verificar fechamento emergencial
        should_close, reason = self.risk_manager.emergency_close_check(
            position, current_price
        )
        if should_close:
            return True, f"Fechamento emergencial: {reason}"
        
        # Verificar sinais contrários fortes
        if 'ema_9' not in df.columns:
            df = IndicatorSignals.calculate_all_indicators(df)
        
        indicator_signal = IndicatorSignals.get_combined_signal(df)
        
        if side == 'Buy' and indicator_signal['signal'] == 'short':
            if indicator_signal['confidence'] > 0.7:
                return True, "Sinal contrário forte detectado"
        elif side == 'Sell' and indicator_signal['signal'] == 'long':
            if indicator_signal['confidence'] > 0.7:
                return True, "Sinal contrário forte detectado"
        
        return False, "Manter posição"
    
    def update_trailing_stop(
        self,
        position: Dict,
        current_price: float
    ) -> Optional[float]:
        """
        Atualiza trailing stop se habilitado
        
        Returns:
            float ou None: Novo stop loss ou None se não atualizar
        """
        if not self.config.get('strategy', {}).get('use_trailing_stop', False):
            return None
        
        entry_price = position.get('entry_price', 0)
        current_sl = position.get('sl', 0)
        side = position.get('side', '')
        
        direction = 'long' if side == 'Buy' else 'short'
        
        new_sl = self.risk_manager.calculate_trailing_stop(
            entry_price=entry_price,
            current_price=current_price,
            direction=direction,
            initial_stop=current_sl
        )
        
        # Retornar apenas se o SL melhorou
        if direction == 'long' and new_sl > current_sl:
            logger.info(f"Trailing stop atualizado: {current_sl:.2f} -> {new_sl:.2f}")
            return new_sl
        elif direction == 'short' and new_sl < current_sl:
            logger.info(f"Trailing stop atualizado: {current_sl:.2f} -> {new_sl:.2f}")
            return new_sl
        
        return None
    
    def analyze_trend_strength(self, df: pd.DataFrame) -> Dict[str, any]:
        """
        Analisa a força da tendência usando múltiplos indicadores
        
        Returns:
            dict: {
                'trend': 'strong_bullish'/'bullish'/'neutral'/'bearish'/'strong_bearish',
                'strength': 0-1,
                'signals': {...}
            }
        """
        if len(df) < 50:
            return {'trend': 'neutral', 'strength': 0.0, 'signals': {}}
        
        signals = {}
        bullish_count = 0
        bearish_count = 0
        
        # 1. Análise de EMAs (alinhamento)
        ema_9 = df['ema_9'].iloc[-1]
        ema_21 = df['ema_21'].iloc[-1]
        ema_50 = df['ema_50'].iloc[-1]
        
        if ema_9 > ema_21 > ema_50:
            bullish_count += 2
            signals['ema_alignment'] = 'bullish'
        elif ema_9 < ema_21 < ema_50:
            bearish_count += 2
            signals['ema_alignment'] = 'bearish'
        else:
            signals['ema_alignment'] = 'mixed'
        
        # 2. RSI (sobrecomprado/sobrevendido)
        rsi = df['rsi'].iloc[-1]
        if 40 < rsi < 60:
            signals['rsi'] = 'neutral'
        elif rsi >= 60:
            bullish_count += 1
            signals['rsi'] = 'bullish'
        elif rsi <= 40:
            bearish_count += 1
            signals['rsi'] = 'bearish'
        
        # 3. MACD (momentum)
        macd = df['macd'].iloc[-1]
        macd_signal = df['macd_signal'].iloc[-1]
        
        if macd > macd_signal and macd > 0:
            bullish_count += 1
            signals['macd'] = 'bullish'
        elif macd < macd_signal and macd < 0:
            bearish_count += 1
            signals['macd'] = 'bearish'
        else:
            signals['macd'] = 'neutral'
        
        # 4. Preço vs VWAP
        close = df['close'].iloc[-1]
        vwap = df['vwap'].iloc[-1]
        
        if close > vwap * 1.002:  # 0.2% acima
            bullish_count += 1
            signals['price_vs_vwap'] = 'above'
        elif close < vwap * 0.998:  # 0.2% abaixo
            bearish_count += 1
            signals['price_vs_vwap'] = 'below'
        else:
            signals['price_vs_vwap'] = 'neutral'
        
        # Determinar tendência e força
        total_signals = bullish_count + bearish_count
        if total_signals == 0:
            trend = 'neutral'
            strength = 0.0
        elif bullish_count > bearish_count:
            strength = bullish_count / 5.0  # Máximo de 5 sinais bullish
            if strength >= 0.6:
                trend = 'strong_bullish'
            else:
                trend = 'bullish'
        else:
            strength = bearish_count / 5.0
            if strength >= 0.6:
                trend = 'strong_bearish'
            else:
                trend = 'bearish'
        
        return {
            'trend': trend,
            'strength': strength,
            'signals': signals,
            'bullish_count': bullish_count,
            'bearish_count': bearish_count
        }