"""
✨ V3.4 - Fibonacci Retracement & Extension Calculator
Calcula níveis de Fibonacci para TP/SL dinâmicos
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple
import logging

logger = logging.getLogger(__name__)


class FibonacciCalculator:
    """Calcula níveis de Fibonacci para análise técnica"""
    
    # Níveis padrão de retração
    RETRACEMENT_LEVELS = [0.236, 0.382, 0.5, 0.618, 0.786]
    
    # Níveis de extensão
    EXTENSION_LEVELS = [1.272, 1.414, 1.618, 2.0, 2.618]
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def calculate_retracement(self, high: float, low: float, direction: str = 'up') -> Dict[str, float]:
        """
        Calcula níveis de retração de Fibonacci
        
        Args:
            high: Topo do movimento
            low: Fundo do movimento
            direction: 'up' (uptrend) ou 'down' (downtrend)
        
        Returns:
            Dict com níveis de Fibonacci
        """
        diff = high - low
        levels = {}
        
        if direction == 'up':
            # Uptrend: retração a partir do topo
            for level in self.RETRACEMENT_LEVELS:
                levels[f'fib_{level}'] = high - (diff * level)
        else:
            # Downtrend: retração a partir do fundo
            for level in self.RETRACEMENT_LEVELS:
                levels[f'fib_{level}'] = low + (diff * level)
        
        return levels
    
    def calculate_extension(self, high: float, low: float, direction: str = 'up') -> Dict[str, float]:
        """
        Calcula níveis de extensão de Fibonacci
        
        Args:
            high: Topo do movimento
            low: Fundo do movimento
            direction: 'up' (uptrend) ou 'down' (downtrend)
        
        Returns:
            Dict com níveis de extensão
        """
        diff = high - low
        levels = {}
        
        if direction == 'up':
            # Uptrend: extensão acima do topo
            for level in self.EXTENSION_LEVELS:
                levels[f'ext_{level}'] = high + (diff * (level - 1))
        else:
            # Downtrend: extensão abaixo do fundo
            for level in self.EXTENSION_LEVELS:
                levels[f'ext_{level}'] = low - (diff * (level - 1))
        
        return levels
    
    def find_swing_points(self, df: pd.DataFrame, lookback: int = 20) -> Tuple[float, float]:
        """
        Identifica swing high e swing low recentes
        
        Args:
            df: DataFrame com dados OHLCV
            lookback: Número de candles para olhar atrás
        
        Returns:
            (swing_high, swing_low)
        """
        recent = df.tail(lookback)
        
        swing_high = recent['high'].max()
        swing_low = recent['low'].min()
        
        return swing_high, swing_low
    
    def get_nearest_fib_levels(
        self,
        current_price: float,
        df: pd.DataFrame,
        direction: str = 'up',
        lookback: int = 50
    ) -> Dict[str, List[float]]:
        """
        Retorna níveis de Fibonacci mais próximos do preço atual
        
        Args:
            current_price: Preço atual
            df: DataFrame com dados OHLCV
            direction: 'up' ou 'down'
            lookback: Período para análise
        
        Returns:
            Dict com {'support': [levels], 'resistance': [levels]}
        """
        swing_high, swing_low = self.find_swing_points(df, lookback)
        
        # Calcular retrações
        retracements = self.calculate_retracement(swing_high, swing_low, direction)
        
        # Calcular extensões
        extensions = self.calculate_extension(swing_high, swing_low, direction)
        
        # Combinar todos os níveis
        all_levels = list(retracements.values()) + list(extensions.values())
        
        # Separar em suporte e resistência
        support_levels = [level for level in all_levels if level < current_price]
        resistance_levels = [level for level in all_levels if level > current_price]
        
        # Ordenar e pegar os 3 mais próximos
        support_levels = sorted(support_levels, reverse=True)[:3]
        resistance_levels = sorted(resistance_levels)[:3]
        
        logger.debug(
            f"Fibonacci levels found: "
            f"Support: {[f'${s:.2f}' for s in support_levels]}, "
            f"Resistance: {[f'${r:.2f}' for r in resistance_levels]}"
        )
        
        return {
            'support': support_levels,
            'resistance': resistance_levels,
            'swing_high': swing_high,
            'swing_low': swing_low
        }
    
    def suggest_tp_sl(
        self,
        entry_price: float,
        side: str,
        df: pd.DataFrame,
        lookback: int = 50
    ) -> Dict[str, float]:
        """
        Sugere TP e SL baseado em Fibonacci
        
        Args:
            entry_price: Preço de entrada
            side: 'Buy' (long) ou 'Sell' (short)
            df: DataFrame com dados OHLCV
            lookback: Período para análise
        
        Returns:
            Dict com {'take_profit': float, 'stop_loss': float}
        """
        direction = 'up' if side == 'Buy' else 'down'
        fib_levels = self.get_nearest_fib_levels(entry_price, df, direction, lookback)
        
        if side == 'Buy':
            # LONG: TP = próxima resistência Fib, SL = próximo suporte Fib
            tp = fib_levels['resistance'][0] if fib_levels['resistance'] else entry_price * 1.03
            sl = fib_levels['support'][0] if fib_levels['support'] else entry_price * 0.985
        else:
            # SHORT: TP = próximo suporte Fib, SL = próxima resistência Fib
            tp = fib_levels['support'][0] if fib_levels['support'] else entry_price * 0.97
            sl = fib_levels['resistance'][0] if fib_levels['resistance'] else entry_price * 1.015
        
        return {
            'take_profit': tp,
            'stop_loss': sl,
            'fib_levels': fib_levels
        }


# Singleton
_fib_calculator = None

def get_fibonacci_calculator() -> FibonacciCalculator:
    """Retorna instância única do calculador de Fibonacci"""
    global _fib_calculator
    if _fib_calculator is None:
        _fib_calculator = FibonacciCalculator()
    return _fib_calculator
