"""
Módulo principal - Loop de trading
Executa a estratégia continuamente
"""
import asyncio
import json
import os
import signal
import sys
import time
import requests
from datetime import datetime, timedelta
from typing import Dict, List
import pandas as pd
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import logging

from .exchange import BybitExchange
from .strategy import TradingStrategy
from .risk import RiskManager
from .telegram_bot import TelegramNotifier
from .utils import setup_logger
from .config_manager import ConfigManager
from .trade_history import TradeHistory
from .paper_trader import PaperTrader
from .filters import TradingFilters

logger = setup_logger("runner")


class Colors:
    """Cores ANSI para terminal"""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def print_banner():
    """Imprime banner inicial"""
    banner = f"""
{Colors.CYAN}{'='*60}
{Colors.BOLD}
    ╔═══════════════════════════════════════════════════════╗
    ║           🚀 BYBIT TRADING BOT V2.0 🚀              ║
    ║              Automated Trading System                 ║
    ╚═══════════════════════════════════════════════════════╝
{Colors.END}{Colors.CYAN}{'='*60}{Colors.END}
"""
    print(banner)


def print_status(message, status="info"):
    """Imprime mensagem formatada"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    if status == "success":
        icon = "✅"
        color = Colors.GREEN
    elif status == "error":
        icon = "❌"
        color = Colors.RED
    elif status == "warning":
        icon = "⚠️"
        color = Colors.YELLOW
    elif status == "info":
        icon = "ℹ️"
        color = Colors.BLUE
    elif status == "trading":
        icon = "📊"
        color = Colors.CYAN
    else:
        icon = "•"
        color = Colors.END
    
    print(f"{color}[{timestamp}] {icon} {message}{Colors.END}")


class TradingBot:
    """Bot principal de trading"""
    
    def __init__(self, config_path: str = "config.json"):
        # Carregar configuração com gerenciador
        self.config_manager = ConfigManager(config_path)
        self.config = self.config_manager.config
        
        # Inicializar componentes
        self.exchange = BybitExchange(self.config)
        self.strategy = TradingStrategy(self.config)
        self.risk_manager = RiskManager(self.config)
        self.trade_history = TradeHistory()  # Sistema de ML
        
        # ✨ V3.2.1 - Paper Trader para tracking de PnL
        from .paper_trader import PaperTrader
        self.paper_trader = PaperTrader(initial_balance=10000.0)
        
        # ✨ V3.3 - Filtros Avançados
        self.filters = TradingFilters(self.config)
        
        # Telegram (opcional)
        if self.config.get('telegram', {}).get('enabled', False):
            self.telegram = TelegramNotifier(self.config['telegram'])
        else:
            self.telegram = None
        
        # Estado
        self.symbols = self.config.get('symbols', ['BTCUSDT'])
        self.timeframes = self.config.get('timeframes', ['15m', '1h'])
        self.trading_mode = self.config.get('trading_mode', 'paper')
        
        # Cache busting: rastrear últimos dados
        self.last_prices = {}  # {symbol: {tf: last_close}}
        self.stagnant_count = {}  # Contador de dados repetidos
        self.kline_failures = {}  # ✨ V3.2.1 - Contador de falhas de klines
        self.running = False
        self.positions: Dict[str, Dict] = {}
        self.balance = 0.0
        self.analysis_count = 0
        
        # Scheduler para tarefas periódicas
        self.scheduler = AsyncIOScheduler()
        
        # Kill switch
        self.stop_file = "STOP"
    
    async def initialize(self):
        """Inicializa conexões e dados"""
        print_status("Inicializando bot...", "info")
        
        try:
            # Inicializar exchange
            await self.exchange.initialize()
            print_status("Conexão com Bybit estabelecida", "success")
            
            # ✨ V3.2.1 - Pular configuração de alavancagem em paper mode
            if self.trading_mode != 'paper':
                # Configurar alavancagem para cada símbolo
                leverage = self.config.get('leverage', 5)
                print_status(f"Configurando alavancagem {leverage}x...", "info")
                
                for symbol in self.symbols:
                    success = await self.exchange.set_leverage(symbol, leverage)
                    if success:
                        print_status(f"  ✓ {symbol}: {leverage}x", "success")
            
            # ✨ V3.2.1 - Usar saldo paper ou real dependendo do modo
            if self.trading_mode == 'paper':
                self.balance = self.paper_trader.balance
                print_status(f"📝 Saldo Paper: {Colors.BOLD}{self.balance:.2f} USDT{Colors.END}", "success")
            else:
                print_status("Consultando saldo da conta...", "info")
                self.balance = await self.exchange.get_balance()
                print_status(f"Saldo disponível: {Colors.BOLD}{self.balance:.2f} USDT{Colors.END}", "success")
            
            # Obter posições existentes
            await self.update_positions()
            print_status(f"Posições abertas: {len(self.positions)}", "info")
            
            if self.positions:
                print(f"\n{Colors.YELLOW}Posições Ativas:{Colors.END}")
                for symbol, pos in self.positions.items():
                    side = pos.get('side', 'N/A')
                    size = pos.get('size', 0)
                    avg_price = pos.get('avgPrice', '0')
                    
                    # Converter avgPrice para float com segurança
                    try:
                        entry = float(avg_price) if avg_price else 0.0
                    except (ValueError, TypeError):
                        entry = 0.0
                    
                    pnl_str = pos.get('unrealisedPnl', '0')
                    try:
                        pnl = float(pnl_str) if pnl_str else 0.0
                    except (ValueError, TypeError):
                        pnl = 0.0
                    
                    pnl_color = Colors.GREEN if pnl > 0 else Colors.RED
                    print(f"  • {symbol}: {side} | Size: {size} | Entry: {entry} | PnL: {pnl_color}{pnl}{Colors.END}")
            
            # Notificar inicialização
            if self.telegram:
                await self.telegram.send_message(
                    f"🤖 Bot iniciado\n"
                    f"Modo: {self.trading_mode}\n"
                    f"Símbolos: {', '.join(self.symbols)}\n"
                    f"Saldo: {self.balance:.2f} USDT"
                )
            
            print()  # Linha em branco
        
        except Exception as e:
            print_status(f"Erro na inicialização: {e}", "error")
            raise
    
    async def update_positions(self):
        """Atualiza lista de posições abertas - PRESERVA POSIÇÕES MANUAIS"""
        try:
            # ✨ V3.2 - Detectar posições fechadas pela exchange
            old_positions = set(self.positions.keys())
            
            # Guardar posições abertas manualmente (que podem não estar na API ainda)
            manual_positions = {k: v for k, v in self.positions.items() 
                              if v.get('manual', False)}
            
            all_positions = []
            for symbol in self.symbols:
                positions = await self.exchange.get_positions(symbol)
                # Filtrar apenas posições com tamanho > 0
                for pos in positions:
                    size = float(pos.get('size', 0))
                    if size > 0:
                        # Garantir que avgPrice seja convertível para float
                        avg_price = pos.get('avgPrice', '0')
                        if avg_price == '' or avg_price is None:
                            pos['avgPrice'] = '0'
                        all_positions.append(pos)
            
            # Atualizar posições da API
            new_positions_dict = {pos['symbol']: pos for pos in all_positions}
            
            # ✨ V3.2 - Detectar e logar posições fechadas
            closed_positions = old_positions - set(new_positions_dict.keys()) - set(manual_positions.keys())
            for symbol in closed_positions:
                old_pos = self.positions.get(symbol, {})
                pnl = float(old_pos.get('unrealisedPnl', 0))
                entry = float(old_pos.get('avgPrice', 0))
                
                if pnl > 0:
                    logger.warning(
                        f"💰 {symbol}: Posição fechada pela BYBIT (TP atingido!) | "
                        f"Lucro: +${abs(pnl):.2f} ✅"
                    )
                else:
                    logger.warning(
                        f"🛑 {symbol}: Posição fechada pela BYBIT (SL atingido!) | "
                        f"Perda: -${abs(pnl):.2f} | Entry: ${entry:.2f} ❌"
                    )
            
            self.positions = new_positions_dict
            
            # Reintegrar posições manuais (que ainda não apareceram na API)
            for symbol, pos in manual_positions.items():
                if symbol not in self.positions:  # Só adiciona se não veio da API
                    self.positions[symbol] = pos
                    logger.debug(f"🔄 Preservando posição manual {symbol} (aguardando API)")
                    
        except Exception as e:
            logger.error(f"Erro ao atualizar posições: {e}")
    
    async def fetch_market_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        """Obtém dados de mercado e calcula indicadores"""
        try:
            # Mapear timeframe para formato Bybit
            tf_map = {
                '15m': '15',
                '1h': '60',
                '2h': '120',
                '4h': '240'
            }
            
            bybit_tf = tf_map.get(timeframe, '60')
            
            # Obter klines
            klines = await self.exchange.get_klines(symbol, bybit_tf, limit=200)
            
            if not klines:
                logger.warning(f"Nenhum kline retornado para {symbol} {timeframe}")
                return pd.DataFrame()
            
            # Converter para DataFrame
            # Bybit retorna: [timestamp, open, high, low, close, volume, turnover]
            df = pd.DataFrame(klines, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'turnover'])
            
            # Converter tipos
            df['timestamp'] = pd.to_numeric(df['timestamp'])
            df['open'] = pd.to_numeric(df['open'])
            df['high'] = pd.to_numeric(df['high'])
            df['low'] = pd.to_numeric(df['low'])
            df['close'] = pd.to_numeric(df['close'])
            df['volume'] = pd.to_numeric(df['volume'])
            
            # IMPORTANTE: API Bybit retorna dados em ordem DECRESCENTE (mais recente primeiro)
            # Ordenar por timestamp CRESCENTE (do mais antigo para o mais recente)
            df = df.sort_values('timestamp', ascending=True).reset_index(drop=True)
            
            # VERIFICAR DADOS ESTAGNADOS
            if len(df) > 0:
                from datetime import datetime
                last_ts = int(df['timestamp'].iloc[-1])
                last_time = datetime.fromtimestamp(last_ts / 1000)
                last_close = float(df['close'].iloc[-1])
                
                # Criar chave para rastreamento
                cache_key = f"{symbol}_{timeframe}"
                
                # Verificar se preço mudou
                if cache_key in self.last_prices:
                    prev_close = self.last_prices[cache_key]
                    
                    if abs(last_close - prev_close) < 0.01:
                        # Dados IDÊNTICOS detectados!
                        self.stagnant_count[cache_key] = self.stagnant_count.get(cache_key, 0) + 1
                        
                        # Mostrar aviso compacto apenas na 1ª e 3ª repetição
                        if self.stagnant_count[cache_key] == 1:
                            logger.warning(
                                f"⚠️  {symbol} {timeframe}: Dados não atualizaram"
                            )
                        elif self.stagnant_count[cache_key] == 3:
                            logger.error(
                                f"🚨 {symbol} {timeframe}: CONGELADO há 3 análises!"
                            )
                    else:
                        # Dados mudaram - reset contador
                        if cache_key in self.stagnant_count:
                            logger.info(f"✅ Dados atualizaram: {symbol} {timeframe} {prev_close:.2f} → {last_close:.2f}")
                        self.stagnant_count[cache_key] = 0
                
                # Salvar último preço
                self.last_prices[cache_key] = last_close
                
                logger.debug(
                    f"{symbol} {timeframe}: {len(df)} candles | "
                    f"Último: {last_time.strftime('%Y-%m-%d %H:%M')} | "
                    f"Close: {last_close:.2f}"
                )
            
            # Calcular indicadores
            from .indicators import IndicatorSignals
            df = IndicatorSignals.calculate_all_indicators(df)
            
            return df
        
        except Exception as e:
            logger.error(f"Erro ao obter dados {symbol} {timeframe}: {e}", exc_info=True)
            return pd.DataFrame()
    
    async def analyze_and_trade(self):
        """Analisa mercado e executa trades"""
        self.analysis_count += 1
        
        # Verificar comandos pendentes
        commands = self.config_manager.check_commands()
        if commands:
            # Recarregar config e reinicializar componentes se necessário
            self.config = self.config_manager.reload_config()
            print_status("⚙️  Configuração atualizada dinamicamente!", "success")
        
        print(f"\n{Colors.CYAN}{'='*60}{Colors.END}")
        print_status(f"Análise #{self.analysis_count} iniciada", "trading")
        print(f"{Colors.CYAN}{'='*60}{Colors.END}\n")
        
        try:
            # Atualizar saldo e posições (✨ V3.2 - logs limpos)
            if self.trading_mode == 'paper':
                self.balance = self.paper_trader.balance
            else:
                self.balance = await self.exchange.get_balance()
            
            await self.update_positions()
            
            # ✨ V3.2.1 - Mostrar posições paper também
            paper_positions = len(self.paper_trader.positions) if self.trading_mode == 'paper' else 0
            total_positions = len(self.positions) + paper_positions
            
            print_status(f"Saldo: {self.balance:.2f} USDT | Posições: {total_positions}", "success")
            
            # Analisar cada símbolo
            print()
            for i, symbol in enumerate(self.symbols, 1):
                print_status(f"[{i}/{len(self.symbols)}] Analisando {Colors.BOLD}{symbol}{Colors.END}...", "trading")
                await self.process_symbol(symbol)
                await asyncio.sleep(0.5)  # Pequeno delay entre símbolos
            
            # Gerenciar posições existentes (✨ V3.2 - logs limpos)
            if self.positions:
                print()
                await self.manage_existing_positions()
            
            # ✨ V3.2.1 - Atualizar posições paper e mostrar resumo
            if self.trading_mode == 'paper':
                await self.update_paper_positions()
                
                # ✨ V3.3.6 - Mostrar posições abertas em TEMPO REAL (a cada análise!)
                if self.paper_trader.positions:
                    print()
                    self.show_open_positions_realtime()
                
                # Mostrar resumo completo a cada 5 análises
                if self.analysis_count % 5 == 0:
                    self.paper_trader.print_summary()  # Resumo sem posições (já mostrou acima)
            
            print(f"\n{Colors.GREEN}✓ Análise #{self.analysis_count} concluída{Colors.END}")
            print(f"{Colors.CYAN}{'='*60}{Colors.END}\n")
        
        except Exception as e:
            print_status(f"Erro no ciclo de trading: {e}", "error")
            if self.telegram:
                await self.telegram.send_message(f"❌ Erro: {e}")
    
    async def process_symbol(self, symbol: str):
        """Processa um símbolo específico"""
        try:
            # Verificar se pode abrir nova posição
            can_trade, reason = self.risk_manager.can_open_trade(symbol, self.positions)
            
            if not can_trade:
                print_status(f"  ⚠️  {symbol}: {reason}", "warning")
                return
            
            # Obter dados de todos os timeframes (✨ V3.2 - logs limpos)
            timeframes_data = {}
            for tf in self.timeframes:
                df = await self.fetch_market_data(symbol, tf)
                if not df.empty:
                    timeframes_data[tf] = df
            
            if not timeframes_data:
                print_status(f"  ⚠️  {symbol}: Sem dados disponíveis", "warning")
                return
            
            # Analisar com consenso de múltiplos timeframes (✨ V3.2 - logs limpos)
            
            # Suprimir logs de DEBUG e ERROR do PatternDetector temporariamente
            pattern_logger = logging.getLogger("PatternDetector")
            strategy_logger = logging.getLogger("TradingStrategy")
            
            old_pattern_level = pattern_logger.level
            old_strategy_level = strategy_logger.level
            
            pattern_logger.setLevel(logging.CRITICAL)
            strategy_logger.setLevel(logging.INFO)
            
            try:
                consensus = self.strategy.analyze_multiple_timeframes(symbol, timeframes_data)
            finally:
                pattern_logger.setLevel(old_pattern_level)
                strategy_logger.setLevel(old_strategy_level)
            
            # Log para debug (mostrar sempre, não apenas quando há sinal)
            if consensus['signal'] == 'neutral':
                logger.debug(f"  {symbol}: Sinal neutro (confiança muito baixa)")
            
            # Executar trade se sinal válido
            if consensus['signal'] in ['long', 'short']:
                # ✅ V3.2.2 - VERIFICAÇÃO ANTI-DUPLICATAS (incluindo paper mode)
                has_position = False
                if self.trading_mode == 'paper':
                    has_position = symbol in self.paper_trader.positions
                else:
                    has_position = symbol in self.positions
                
                if has_position:
                    print_status(
                        f"  ⛔ {symbol}: Posição JÁ ABERTA ({self.trading_mode}) - bloqueando nova entrada",
                        "warning"
                    )
                    return
                
                base_confidence = consensus['consensus_score']
                signal_color = Colors.GREEN if consensus['signal'] == 'long' else Colors.RED
                
                # ML: Verificar padrão com histórico
                pattern = consensus.get('dominant_pattern', 'unknown')
                
                # Verificar se padrão está na blacklist
                if not self.trade_history.should_trade_pattern(pattern):
                    print_status(
                        f"  🚫 Padrão '{pattern}' bloqueado por baixo win rate histórico",
                        "warning"
                    )
                    return
                
                # ML: Ajustar confiança baseado em histórico
                confidence = self.trade_history.get_adjusted_confidence(
                    pattern, symbol, base_confidence
                )
                
                # Threshold configurável (padrão: 50%)
                min_confidence = self.config.get('min_trade_confidence', 0.50)
                
                print_status(
                    f"  {signal_color}SINAL DETECTADO{Colors.END}: {consensus['signal'].upper()} | "
                    f"Confiança: {confidence:.1%} | "
                    f"Razão: {consensus.get('reason', 'N/A')}",
                    "success"
                )
                
                if confidence >= min_confidence:
                    print_status(
                        f"  ✅ Confiança suficiente ({confidence:.1%} >= {min_confidence:.1%})",
                        "success"
                    )
                    
                    # ✨ V3.3 - APLICAR FILTROS AVANÇADOS
                    print_status("  🔍 Aplicando filtros avançados...", "info")
                    
                    # Buscar dados diários para análise de tendência
                    df_daily = await self.exchange.get_klines(symbol, '1d', limit=250)
                    
                    # Aplicar todos os filtros
                    filters_ok, filter_results = self.filters.apply_all_filters(
                        df=timeframes_data[self.timeframes[0]],  # Use primeiro timeframe
                        df_daily=df_daily,
                        signal=consensus
                    )
                    
                    # Mostrar resultados dos filtros
                    for filter_name, result_msg in filter_results.items():
                        if "⛔" in result_msg:
                            print_status(f"     {result_msg}", "warning")
                        else:
                            print_status(f"     {result_msg}", "success")
                    
                    if filters_ok:
                        print_status("  ✅ TODOS os filtros passaram - Executando trade!", "success")
                        # Registrar trade ANTES de executar (para evitar duplicatas)
                        self.risk_manager.record_trade(symbol)
                        await self.execute_trade(symbol, consensus)
                    else:
                        print_status("  ⛔ Trade BLOQUEADO por filtros avançados", "warning")
                else:
                    print_status(
                        f"  ⚠️  Confiança insuficiente ({confidence:.1%} < {min_confidence:.1%}) - Aguardando sinal mais forte",
                        "warning"
                    )
            # Não precisa printar nada aqui, já foi mostrado no log detalhado do consenso
        
        except Exception as e:
            print_status(f"❌ Erro ao processar {symbol}: {e}", "error")
    
    async def execute_trade(self, symbol: str, signal: Dict):
        """Executa uma trade"""
        try:
            entry_price = signal['entry_price']
            direction = signal['signal']
            confidence = signal.get('consensus_score', 0.70)
            
            # ✨ V3.3.4 - Recalcular TP/SL dinamicamente (inclui tipo de padrão)
            pattern_type = signal.get('dominant_pattern', '')
            tp_sl = self.risk_manager.calculate_tp_sl(
                entry_price=entry_price,
                direction=direction,
                atr=None,
                pattern_target=None,
                confidence=confidence,
                pattern_type=pattern_type  # V3.3.4 - Para detectar scalping
            )
            
            take_profit = tp_sl['take_profit']
            stop_loss = tp_sl['stop_loss']
            
            # ✨ V3.2.1 - Obter saldo paper ou real
            if self.trading_mode == 'paper':
                usdt_balance = self.paper_trader.balance
            else:
                usdt_balance = self.balance
            
            if usdt_balance < 10:
                print_status(f"Saldo insuficiente: {usdt_balance:.2f} USDT", "error")
                return
            
            # Calcular tamanho da posição
            position_size = self.risk_manager.calculate_position_size(
                balance=usdt_balance,
                entry_price=entry_price,
                stop_loss=stop_loss,
                symbol=symbol
            )
            
            quantity = position_size['quantity']  # Quantidade em moeda (BTC/ETH/SOL)
            
            # Validar parâmetros (incluir symbol para contract_size)
            is_valid, msg = self.risk_manager.validate_trade_params(
                balance=usdt_balance,
                entry_price=entry_price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                quantity=quantity,
                symbol=symbol
            )
            
            if not is_valid:
                print_status(f"Validação falhou: {msg}", "error")
                return
            
            # ✨ V3.3.4 - Calcular tipo de trade (inclui scalping)
            tp_pct = abs(take_profit - entry_price) / entry_price * 100
            sl_pct = abs(entry_price - stop_loss) / entry_price * 100
            
            # Detectar tipo
            is_scalping = any(x in pattern_type for x in ['scalping', 'momentum', 'pin_bar', 'inside_bar', 'micro_'])
            is_divergence = 'divergence' in pattern_type
            
            if is_scalping:
                trade_type = "⚡ SCALPING"
            elif is_divergence:
                trade_type = "🔄 DIVERGÊNCIA"
            elif confidence >= 0.85:
                trade_type = "✨ FORTE"
            else:
                trade_type = "⚡ RÁPIDO"
            
            # Log da trade
            side = "Buy" if direction == 'long' else "Sell"
            side_color = Colors.GREEN if direction == 'long' else Colors.RED
            
            print(f"\n{Colors.YELLOW}{'='*60}")
            print(f"{Colors.BOLD}🎯 SINAL DE ENTRADA {trade_type}{Colors.END}")
            print(f"{'='*60}{Colors.END}")
            print(f"{Colors.BOLD}Símbolo:{Colors.END}      {symbol}")
            print(f"{Colors.BOLD}Direção:{Colors.END}      {side_color}{direction.upper()}{Colors.END}")
            print(f"{Colors.BOLD}Confiança:{Colors.END}    {signal['consensus_score']:.2%}")
            print(f"{Colors.BOLD}Entry:{Colors.END}        {entry_price:.2f}")
            print(f"{Colors.BOLD}Take Profit:{Colors.END}  {take_profit:.2f} (+{tp_pct:.2f}%)")
            print(f"{Colors.BOLD}Stop Loss:{Colors.END}    {stop_loss:.2f} (-{sl_pct:.2f}%)")
            print(f"{Colors.BOLD}Quantidade:{Colors.END}   {quantity}")
            print(f"{Colors.BOLD}Notional:{Colors.END}     {position_size['notional']:.2f} USDT")
            print(f"{Colors.BOLD}Margem:{Colors.END}       {position_size['margin']:.2f} USDT ({position_size['margin']/usdt_balance*100:.1f}%)")
            print(f"{Colors.BOLD}Tipo:{Colors.END}         {trade_type}")
            print(f"{Colors.BOLD}Razão:{Colors.END}        {signal.get('reason', 'N/A')}")
            print(f"{Colors.YELLOW}{'='*60}{Colors.END}\n")
            
            # Modo paper trading - apenas simula
            if self.trading_mode == 'paper':
                # ✨ V3.2.1 - Usar Paper Trader para tracking
                paper_position = self.paper_trader.open_position(
                    symbol=symbol,
                    side="Buy" if direction == "long" else "Sell",
                    entry_price=entry_price,
                    quantity=quantity,
                    take_profit=take_profit,
                    stop_loss=stop_loss,
                    margin=position_size['margin'],
                    pattern=signal.get('dominant_pattern', 'unknown'),
                    confidence=signal['consensus_score']
                )
                
                print_status(
                    f"📝 [PAPER] Trade #{paper_position['trade_id']} simulado | "
                    f"Saldo: ${self.paper_trader.balance:.2f}", 
                    "warning"
                )
                
                if self.telegram:
                    await self.telegram.send_message(
                        f"📝 PAPER TRADE #{paper_position['trade_id']}\n"
                        f"Symbol: {symbol}\n"
                        f"Side: {side}\n"
                        f"Entry: {entry_price:.2f}\n"
                        f"TP: {take_profit:.2f}\n"
                        f"SL: {stop_loss:.2f}\n"
                        f"Confidence: {signal['consensus_score']:.2%}"
                    )
                return
            
            # Modo testnet/live - executar ordem real
            print_status(f"💰 Executando ordem no {self.trading_mode}...", "info")
            
            order = await self.exchange.place_order(
                symbol=symbol,
                side=side,
                qty=quantity,
                order_type="Market",
                take_profit=take_profit,
                stop_loss=stop_loss
            )
            
            if order:
                print_status(f"Ordem executada com sucesso: {order['order_id']}", "success")
                
                # ✨ V3.1 - LOG DETALHADO DE TRADE
                tp_pct = abs(take_profit - entry_price) / entry_price * 100
                sl_pct = abs(entry_price - stop_loss) / entry_price * 100
                rr_ratio = tp_pct / sl_pct if sl_pct > 0 else 0
                
                logger.info(
                    f"\n{'='*60}\n"
                    f"💰 TRADE #{len(self.positions) + 1} EXECUTADO\n"
                    f"{'='*60}\n"
                    f"  📊 Símbolo: {symbol}\n"
                    f"  {'📈' if side == 'Buy' else '📉'} Direção: {side}\n"
                    f"  💵 Entry: ${entry_price:.2f}\n"
                    f"  🎯 TP: ${take_profit:.2f} (+{tp_pct:.2f}%)\n"
                    f"  🛡️ SL: ${stop_loss:.2f} (-{sl_pct:.2f}%)\n"
                    f"  ⚖️ R:R: 1:{rr_ratio:.2f}\n"
                    f"  📦 Quantidade: {quantity}\n"
                    f"  💰 Margem: ${position_size['margin']:.2f}\n"
                    f"  🎨 Padrão: {signal.get('dominant_pattern', 'unknown')}\n"
                    f"  🎯 Confiança: {signal['consensus_score']:.2f}%\n"
                    f"{'='*60}"
                )
                
                # Salvar posição no rastreamento (IMPORTANTE para evitar duplicatas)
                self.positions[symbol] = {
                    'orderId': order['order_id'],
                    'symbol': symbol,
                    'side': side,
                    'size': str(quantity),
                    'avgPrice': str(entry_price),
                    'takeProfit': str(take_profit),
                    'stopLoss': str(stop_loss),
                    'unrealisedPnl': '0',
                    'pattern': signal.get('dominant_pattern', 'unknown'),  # Para ML
                    'confidence': signal['consensus_score'],
                    'manual': True,  # ✅ Marca como manual para preservar anti-duplicata
                    'partial_taken': False  # ✨ V3.1 - Flag para partial TP
                }
                
                logger.info(f"✅ Posição {symbol} rastreada (anti-duplicata + partial TP ativo)")
                
                if self.telegram:
                    await self.telegram.send_message(
                        f"✅ TRADE ABERTO\n"
                        f"Symbol: {symbol}\n"
                        f"Side: {side}\n"
                        f"Quantity: {quantity}\n"
                        f"Entry: {entry_price:.2f}\n"
                        f"TP: {take_profit:.2f}\n"
                        f"SL: {stop_loss:.2f}\n"
                        f"Order ID: {order['order_id']}"
                    )
            else:
                print_status("Falha ao executar ordem", "error")
                
                if self.telegram:
                    await self.telegram.send_message(f"❌ Falha ao abrir trade em {symbol}")
        
        except Exception as e:
            print_status(f"Erro ao executar trade {symbol}: {e}", "error")
            if self.telegram:
                await self.telegram.send_message(f"❌ Erro ao executar trade: {e}")
    
    async def manage_existing_positions(self):
        """Gerencia posições abertas (trailing stop, fechamento)"""
        if not self.positions:
            return
        
        try:
            for symbol, position in list(self.positions.items()):
                # ✅ V3.1.1 - VERIFICAR SE POSIÇÃO AINDA EXISTE NA EXCHANGE
                # Evita erro "can not set tp/sl/ts for zero position"
                position_size = float(position.get('size', 0))
                if position_size <= 0:
                    logger.debug(f"Posição {symbol} com size 0, removendo do rastreamento")
                    del self.positions[symbol]
                    continue
                
                # Obter preço atual
                ticker = await self.exchange.get_ticker(symbol)
                if not ticker:
                    continue
                
                current_price = ticker.get('last_price', 0)
                if current_price <= 0:
                    logger.warning(f"Preço inválido para {symbol}: {current_price}")
                    continue
                
                # Obter dados atualizados
                df = await self.fetch_market_data(symbol, '1h')
                if df.empty:
                    continue
                
                # Preparar dados da posição com valores seguros
                position_data = {
                    'symbol': symbol,
                    'side': position.get('side', ''),
                    'size': float(position.get('size', 0)),
                    'entry_price': float(position.get('avgPrice', 0)) if position.get('avgPrice') else 0,
                    'tp': float(position.get('takeProfit', 0)) if position.get('takeProfit') else 0,
                    'sl': float(position.get('stopLoss', 0)) if position.get('stopLoss') else 0,
                    'unrealized_pnl': float(position.get('unrealisedPnl', 0)) if position.get('unrealisedPnl') else 0
                }
                
                # Validar entry_price para evitar divisão por zero
                if position_data['entry_price'] <= 0:
                    logger.warning(f"Entry price inválido para {symbol}: {position_data['entry_price']}")
                    del self.positions[symbol]
                    continue
                
                # ✨ V3.1 - PARTIAL TAKE PROFIT
                should_partial, pct_to_close = self.risk_manager.should_take_partial_profit(
                    entry_price=position_data['entry_price'],
                    current_price=current_price,
                    side=position_data['side']
                )
                
                if should_partial and position_data.get('partial_taken', False) is False:
                    logger.info(f"💰 Realizando lucro parcial de {symbol} ({pct_to_close*100}%)")
                    
                    # Calcular nova quantidade (50% da posição)
                    original_size = position_data['size']
                    partial_size = original_size * pct_to_close
                    
                    # Fechar parcialmente (implementar depois na exchange.py)
                    # Por enquanto, apenas marcar
                    self.positions[symbol]['partial_taken'] = True
                    self.positions[symbol]['size'] = str(original_size - partial_size)
                    
                    print_status(
                        f"💰 {symbol}: Lucro parcial realizado! 50% fechado",
                        "success"
                    )
                
                # ✨ V3.1 - BREAK-EVEN AUTOMÁTICO
                should_be, new_sl = self.risk_manager.should_move_to_breakeven(
                    entry_price=position_data['entry_price'],
                    current_price=current_price,
                    current_sl=position_data['sl'],
                    side=position_data['side']
                )
                
                if should_be:
                    logger.info(f"🛡️ Movendo {symbol} para break-even: SL → {new_sl:.2f}")
                    
                    try:
                        success = await self.exchange.set_trading_stop(
                            symbol=symbol,
                            stop_loss=new_sl,
                            take_profit=position_data.get('tp')
                        )
                        
                        if success:
                            self.positions[symbol]['stopLoss'] = str(new_sl)
                            print_status(
                                f"🛡️ {symbol}: Break-even ativado! (SL = Entry)",
                                "success"
                            )
                    except Exception as e:
                        # ✅ V3.1.1 - Posição foi fechada, remover do rastreamento
                        if 'zero position' in str(e).lower():
                            logger.info(f"Posição {symbol} foi fechada, removendo do rastreamento")
                            del self.positions[symbol]
                            continue
                        else:
                            logger.error(f"Erro ao mover {symbol} para break-even: {e}")
                
                # Verificar se a estratégia tem o método should_close_position
                if hasattr(self.strategy, 'should_close_position'):
                    should_close, reason = self.strategy.should_close_position(
                        position_data, current_price, df
                    )
                    
                    if should_close:
                        print_status(f"Fechando posição {symbol}: {reason}", "warning")
                        await self.close_position(symbol, reason)
                        continue
                
                # Verificar se a estratégia tem trailing stop
                if hasattr(self.strategy, 'update_trailing_stop'):
                    new_sl = self.strategy.update_trailing_stop(position_data, current_price)
                    if new_sl and self.trading_mode != 'paper':
                        # Verificar se realmente mudou (evitar erro "not modified")
                        old_sl = position_data.get('sl', 0)
                        if abs(new_sl - old_sl) > 0.01:  # Mudou mais de 0.01
                            logger.info(f"Atualizando trailing stop para {symbol}: {old_sl:.2f} -> {new_sl:.2f}")
                            
                            try:
                                success = await self.exchange.set_trading_stop(
                                    symbol=symbol,
                                    stop_loss=new_sl,
                                    take_profit=position_data.get('tp')
                                )
                                if success:
                                    position_data['sl'] = new_sl
                                    self.positions[symbol]['stopLoss'] = str(new_sl)
                                    print_status(f"✓ Trailing stop atualizado para {symbol}: {new_sl:.2f}", "success")
                            except Exception as e:
                                # ✅ V3.1.1 - Posição foi fechada, remover do rastreamento
                                if 'zero position' in str(e).lower():
                                    logger.info(f"Posição {symbol} foi fechada, removendo do rastreamento")
                                    if symbol in self.positions:
                                        del self.positions[symbol]
                                else:
                                    logger.error(f"Erro ao atualizar trailing stop de {symbol}: {e}")
                        else:
                            logger.debug(f"Trailing stop não mudou significativamente para {symbol}: {old_sl:.2f}")
        
        except Exception as e:
            logger.error(f"Erro ao gerenciar posições: {e}", exc_info=True)
            print_status(f"Erro ao gerenciar posições: {e}", "error")
    
    def show_open_positions_realtime(self):
        """✨ V3.3.6 - Mostra posições abertas em TEMPO REAL durante o loop"""
        if not self.paper_trader.positions:
            return
        
        # ✨ V3.3.7 - Pegar alavancagem para calcular impacto real no PnL
        leverage = self.config.get('leverage', 5)
        
        print(f"{Colors.CYAN}{'─'*60}{Colors.END}")
        print(f"{Colors.CYAN}📈 POSIÇÕES ABERTAS EM TEMPO REAL ({len(self.paper_trader.positions)}){Colors.END}")
        print(f"{Colors.CYAN}{'─'*60}{Colors.END}")
        
        for symbol, pos in self.paper_trader.positions.items():
            side_emoji = "🟢" if pos['side'] == 'Buy' else "🔴"
            side_color = Colors.GREEN if pos['side'] == 'Buy' else Colors.RED
            
            entry = pos['entry_price']
            current = pos.get('current_price', entry)
            pnl = pos.get('unrealized_pnl', 0)
            pnl_pct = pos.get('pnl_pct', 0)
            
            # Formatar PnL com cores
            if pnl >= 0:
                pnl_str = f"{Colors.GREEN}+${pnl:.2f} (+{pnl_pct:.2f}%){Colors.END}"
            else:
                pnl_str = f"{Colors.RED}${pnl:.2f} ({pnl_pct:.2f}%){Colors.END}"
            
            # ✨ V3.3.7 - Distâncias TP/SL com IMPACTO REAL (alavancagem)
            # Distância do preço
            tp_price_dist = abs(pos['take_profit'] - current) / current * 100
            sl_price_dist = abs(pos['stop_loss'] - current) / current * 100
            
            # IMPACTO NO PnL (preço × alavancagem)
            tp_pnl_impact = tp_price_dist * leverage
            sl_pnl_impact = sl_price_dist * leverage
            
            # Determinar se TP/SL está a favor ou contra (para LONG/SHORT)
            is_long = pos['side'] == 'Buy'
            tp_will_profit = (is_long and pos['take_profit'] > current) or (not is_long and pos['take_profit'] < current)
            sl_will_loss = (is_long and pos['stop_loss'] < current) or (not is_long and pos['stop_loss'] > current)
            
            # Formatar com cores e sinais
            tp_sign = "+" if tp_will_profit else "-"
            sl_sign = "-" if sl_will_loss else "+"
            tp_color = Colors.GREEN if tp_will_profit else Colors.RED
            sl_color = Colors.RED if sl_will_loss else Colors.GREEN
            
            print(f"{side_emoji} {Colors.BOLD}{symbol}{Colors.END} {side_color}{pos['side']}{Colors.END}")
            print(f"   Entry: ${entry:,.2f} | Now: ${current:,.2f} | PnL: {pnl_str}")
            print(f"   TP: ${pos['take_profit']:,.2f} {tp_color}({tp_sign}{tp_pnl_impact:.1f}% PnL){Colors.END} | "
                  f"SL: ${pos['stop_loss']:,.2f} {sl_color}({sl_sign}{sl_pnl_impact:.1f}% PnL){Colors.END}")
        
        print(f"{Colors.CYAN}{'─'*60}{Colors.END}")
    
    async def update_paper_positions(self):
        """✨ V3.2.1 - Atualiza posições paper com preço atual e verifica TP/SL"""
        if not self.paper_trader.positions:
            return
        
        for symbol in list(self.paper_trader.positions.keys()):
            try:
                # Obter preço atual
                klines = await self.exchange.get_klines(symbol, "1", limit=1)
                if klines and len(klines) > 0:
                    current_price = float(klines[0][4])  # Close price
                    
                    # Atualizar posição e verificar TP/SL
                    result = self.paper_trader.update_position(symbol, current_price)
                    
                    if result and result['status'] in ['tp_hit', 'sl_hit']:
                        # ✨ V3.3.6 - Notificação visual quando TP/SL é atingido
                        status_emoji = "💰" if result['status'] == 'tp_hit' else "🛑"
                        pnl = result.get('pnl', 0)
                        pnl_str = f"+${pnl:.2f}" if pnl >= 0 else f"${pnl:.2f}"
                        
                        print()
                        print_status(
                            f"{status_emoji} {symbol} FECHADO! PnL: {pnl_str} | "
                            f"Novo saldo: ${self.paper_trader.balance:.2f}",
                            "success" if pnl >= 0 else "error"
                        )
                        
            except Exception as e:
                logger.debug(f"Erro ao atualizar posição paper {symbol}: {e}")
    
    async def close_position(self, symbol: str, reason: str):
        """Fecha uma posição"""
        try:
            if self.trading_mode == 'paper':
                print_status(f"📝 [PAPER] Fechamento simulado de {symbol}", "warning")
                
                if self.telegram:
                    await self.telegram.send_message(
                        f"📝 PAPER CLOSE\n"
                        f"Symbol: {symbol}\n"
                        f"Reason: {reason}"
                    )
                
                if symbol in self.positions:
                    del self.positions[symbol]
                return
            
            # Fechar posição real
            success = await self.exchange.close_position(symbol)
            
            if success:
                # Registrar trade no histórico para ML
                if symbol in self.positions:
                    position = self.positions[symbol]
                    pnl = float(position.get('unrealisedPnl', 0))
                    
                    trade_data = {
                        'symbol': symbol,
                        'direction': position.get('side', '').lower(),
                        'pattern': position.get('pattern', 'unknown'),  # Salvar padrão usado
                        'entry_price': float(position.get('avgPrice', 0)),
                        'exit_price': float(position.get('markPrice', 0)),
                        'pnl': pnl,
                        'reason': reason
                    }
                    
                    self.trade_history.add_trade(trade_data)
                
                print_status(f"Posição {symbol} fechada com sucesso", "success")
                
                if symbol in self.positions:
                    pnl = self.positions[symbol].get('unrealized_pnl', 0)
                    entry = self.positions[symbol].get('entry_price', 0)
                    
                    ticker = await self.exchange.get_ticker(symbol)
                    exit_price = ticker['last_price'] if ticker else 0
                    
                    if self.telegram:
                        await self.telegram.send_message(
                            f"🔒 POSIÇÃO FECHADA\n"
                            f"Symbol: {symbol}\n"
                            f"Reason: {reason}\n"
                            f"Entry: {entry:.2f}\n"
                            f"Exit: {exit_price:.2f}\n"
                            f"PnL: {pnl:.2f} USDT"
                        )
                    
                    del self.positions[symbol]
            else:
                print_status(f"Falha ao fechar {symbol}", "error")
        
        except Exception as e:
            print_status(f"Erro ao fechar posição {symbol}: {e}", "error")
    
    async def close_all_positions(self):
        """Fecha todas as posições (kill switch)"""
        print_status("🛑 KILL SWITCH ATIVADO - Fechando todas as posições", "error")
        
        if self.telegram:
            await self.telegram.send_message("🛑 KILL SWITCH - Fechando todas as posições")
        
        for symbol in list(self.positions.keys()):
            await self.close_position(symbol, "Kill switch ativado")
        
        print_status("Todas as posições fechadas", "success")
    
    def check_kill_switch(self) -> bool:
        """Verifica se arquivo STOP existe"""
        return os.path.exists(self.stop_file)
    
    async def run(self):
        """Loop principal do bot"""
        self.running = True
        
        # Mostrar banner
        print_banner()
        
        # Inicializar
        await self.initialize()
        
        # Configurar scheduler
        print_status("Configurando agendador de tarefas...", "info")
        
        # Analisar mercado a cada 1 minuto (V3.3.2 - mais rápido!)
        analysis_interval = self.config.get('analysis_interval_minutes', 1)
        self.scheduler.add_job(
            self.analyze_and_trade,
            'interval',
            minutes=analysis_interval,
            id='analyze_market'
        )
        
        # Resetar stats diárias às 00:00 UTC
        self.scheduler.add_job(
            self.risk_manager.reset_daily_stats,
            'cron',
            hour=0,
            minute=0,
            id='reset_stats'
        )
        
        self.scheduler.start()
        analysis_interval = self.config.get('analysis_interval_minutes', 1)
        print_status(f"Agendador iniciado - Intervalo de análise: {analysis_interval} minuto(s)", "success")
        
        print(f"\n{Colors.GREEN}{Colors.BOLD}🚀 BOT INICIADO - AGUARDANDO SINAIS DE TRADING{Colors.END}\n")
        
        # Executar primeira análise imediatamente
        await self.analyze_and_trade()
        
        # Loop principal
        try:
            while self.running:
                # Verificar kill switch
                if self.check_kill_switch():
                    print_status("Kill switch detectado!", "error")
                    await self.close_all_positions()
                    self.running = False
                    break
                
                await asyncio.sleep(10)
        
        except KeyboardInterrupt:
            print_status("Interrompido pelo usuário", "warning")
        
        finally:
            await self.shutdown()
    
    async def shutdown(self):
        """Encerra bot gracefully"""
        print_status("Encerrando bot...", "warning")
        
        self.running = False
        
        # Parar scheduler
        if self.scheduler.running:
            self.scheduler.shutdown()
        
        # Fechar conexões
        await self.exchange.close()
        
        # Notificar
        if self.telegram:
            await self.telegram.send_message("🛑 Bot encerrado")
        
        print_status("Bot encerrado com sucesso", "success")


async def main():
    """Função principal"""
    # Configurar signal handlers
    def signal_handler(signum, frame):
        print_status("Sinal de interrupção recebido", "warning")
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Verificar arquivo de configuração
    if not os.path.exists("config.json"):
        print_status("Arquivo config.json não encontrado!", "error")
        print_status("Crie um arquivo config.json com suas configurações", "info")
        sys.exit(1)
    
    # Iniciar bot
    bot = TradingBot()
    
    try:
        await bot.run()
    except Exception as e:
        print_status(f"Erro fatal: {e}", "error")
        await bot.shutdown()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
