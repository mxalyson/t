# 🔧 PROBLEMAS DETECTADOS - Testnet Congelada + Erro de Preço

## 📅 **Data:** 2025-10-09 17:44
## 🚨 **Status:** CRÍTICO

---

## 🚨 **PROBLEMA 1: Testnet Bybit Congelada**

### **Erro:**
```
2025-10-09 17:25:24,168 - runner - WARNING - Nenhum kline retornado para ETHUSDT 2h
2025-10-09 17:25:24,682 - runner - WARNING - Nenhum kline retornado para SOLUSDT 15m
```

**Repetiu de 17:25 até 17:39 (14 minutos!)** ❌

### **Causa:**
- API Bybit Testnet retorna response.retCode = 0 (sucesso)
- MAS `result.list` vem **VAZIO**: `[]`
- Testnet Bybit está **CONGELADA** novamente!

### **Confirmação:**
```python
response = await self._make_request("GET", "/v5/market/kline", params, auth=False)
if response and response.get("retCode") == 0:
    klines = response["result"]["list"]
    # klines = [] ← VAZIO! ❌
```

---

## 🚨 **PROBLEMA 2: Erro de Preço Mínimo (SHORT)**

### **Erro:**
```
Erro da API Bybit (/v5/order/create): {
  'retCode': 30209, 
  'retMsg': 'Failed to submit order(s).The order price is lower than the minimum selling price.'
}
```

### **Dados do trade:**
```
Símbolo: SOLUSDT
Direção: SHORT
Entry: $53.28
TP: $50.62 (-5%)
SL: $54.88 (+3%)
```

### **Causa:**
Para **SHORT**, o TP é **MENOR** que Entry (correto: vender alto, comprar baixo).

MAS Bybit tem um **preço mínimo** para ordens de venda!

**Explicação:**
- SOLUSDT pode ter "minPrice" = $51.00 (exemplo)
- Seu TP: $50.62
- $50.62 < $51.00
- Bybit rejeita! ❌

**Tick Size:**
- Cada símbolo tem um "tick size" (incremento mínimo)
- Ex: SOLUSDT tick = $0.01
- Preço deve ser múltiplo do tick
- Ex: $50.62 ✅, $50.6234 ❌

---

## ✅ **SOLUÇÕES**

---

### **SOLUÇÃO 1: Detectar Testnet Congelada + Retry**

**O que fazer:**

1. **Detectar klines vazios:**
   ```python
   if not klines or len(klines) == 0:
       logger.warning(f"Klines vazios para {symbol} {timeframe}")
       # Retry com delay
   ```

2. **Retry com backoff:**
   ```python
   for attempt in range(3):
       klines = await get_klines(...)
       if klines:
           break
       await asyncio.sleep(2 ** attempt)  # 1s, 2s, 4s
   ```

3. **Alertar usuário:**
   ```
   🚨 TESTNET CONGELADA DETECTADA!
   
   Klines vazios por 5+ minutos
   
   RECOMENDAÇÃO:
   1. Use MAINNET com $500+
   2. Ou aguarde testnet voltar
   3. Verifique: https://testnet.bybit.com
   ```

---

### **SOLUÇÃO 2: Validar Preços TP/SL Antes de Enviar**

**O que fazer:**

1. **Obter limites do símbolo:**
   ```python
   # Chamar /v5/market/instruments-info
   {
     "minPrice": "0.5",      # Preço mínimo
     "maxPrice": "999999",   # Preço máximo
     "tickSize": "0.01",     # Incremento mínimo
     "minOrderQty": "0.1"    # Quantidade mínima
   }
   ```

2. **Validar TP/SL:**
   ```python
   def validate_price(price, minPrice, maxPrice, tickSize):
       # Ajustar para tick size
       adjusted = round(price / tickSize) * tickSize
       
       # Validar limites
       if adjusted < minPrice:
           adjusted = minPrice
       if adjusted > maxPrice:
           adjusted = maxPrice
       
       return adjusted
   ```

3. **Aplicar antes de enviar ordem:**
   ```python
   # Validar TP
   if take_profit:
       take_profit = validate_price(take_profit, ...)
   
   # Validar SL
   if stop_loss:
       stop_loss = validate_price(stop_loss, ...)
   ```

---

### **SOLUÇÃO 3: Fallback para Mainnet Paper Mode**

**Config alternativa:**
```json
{
  "testnet": false,
  "trading_mode": "paper",
  "comment": "Usa MAINNET para dados, mas não executa trades"
}
```

**Vantagens:**
- ✅ Dados reais da mainnet (nunca congelam)
- ✅ Não gasta dinheiro real (paper mode)
- ✅ Testa com dados corretos

---

## 🔧 **IMPLEMENTAÇÃO RÁPIDA**

### **Arquivo: `src/exchange.py`**

**ANTES (Linha 280):**
```python
if response and response.get("retCode") == 0:
    klines = response["result"]["list"]
    
    if klines and len(klines) > 0:
        # Log do primeiro e último candle
```

**DEPOIS:**
```python
if response and response.get("retCode") == 0:
    klines = response["result"]["list"]
    
    # ✨ V3.2.1 - Detectar testnet congelada
    if not klines or len(klines) == 0:
        self.logger.warning(
            f"🚨 API retornou klines VAZIOS para {symbol} {interval}! "
            f"Testnet pode estar congelada!"
        )
        return []  # Retornar vazio explicitamente
    
    if len(klines) > 0:
        # Log do primeiro e último candle
```

---

### **Arquivo: `src/runner.py`**

**ANTES (Linha 256):**
```python
if not klines:
    logger.warning(f"Nenhum kline retornado para {symbol} {timeframe}")
    return pd.DataFrame()
```

**DEPOIS:**
```python
if not klines:
    # ✨ V3.2.1 - Contador de falhas
    cache_key = f"{symbol}_{timeframe}"
    self.kline_failures[cache_key] = self.kline_failures.get(cache_key, 0) + 1
    
    if self.kline_failures[cache_key] >= 5:
        logger.error(
            f"🚨 TESTNET CONGELADA DETECTADA!\n"
            f"   {symbol} {timeframe} falhou {self.kline_failures[cache_key]} vezes!\n"
            f"   RECOMENDAÇÃO: Use MAINNET ou aguarde testnet voltar"
        )
    else:
        logger.warning(f"⚠️ Nenhum kline para {symbol} {timeframe} (tentativa {self.kline_failures[cache_key]}/5)")
    
    return pd.DataFrame()
else:
    # Reset contador em sucesso
    cache_key = f"{symbol}_{timeframe}"
    if cache_key in self.kline_failures:
        del self.kline_failures[cache_key]
```

---

### **Arquivo: `src/exchange.py` - Validar Preços**

**ADICIONAR NOVA FUNÇÃO (Após linha 250):**
```python
async def get_instrument_info(self, symbol: str):
    """Obtém informações do instrumento (limites de preço, tick size, etc)"""
    params = {
        "category": "linear",
        "symbol": symbol
    }
    
    response = await self._make_request("GET", "/v5/market/instruments-info", params, auth=False)
    
    if response and response.get("retCode") == 0:
        instruments = response["result"]["list"]
        if instruments and len(instruments) > 0:
            info = instruments[0]["priceFilter"]
            return {
                "minPrice": float(info["minPrice"]),
                "maxPrice": float(info["maxPrice"]),
                "tickSize": float(info["tickSize"])
            }
    
    return None


def validate_price(self, price: float, instrument_info: dict) -> float:
    """Valida e ajusta preço para limites do símbolo"""
    if not instrument_info:
        return price
    
    minPrice = instrument_info["minPrice"]
    maxPrice = instrument_info["maxPrice"]
    tickSize = instrument_info["tickSize"]
    
    # Ajustar para tick size
    adjusted = round(price / tickSize) * tickSize
    
    # Aplicar limites
    if adjusted < minPrice:
        self.logger.warning(f"Preço {adjusted} < minPrice {minPrice}, ajustando")
        adjusted = minPrice
    
    if adjusted > maxPrice:
        self.logger.warning(f"Preço {adjusted} > maxPrice {maxPrice}, ajustando")
        adjusted = maxPrice
    
    return adjusted
```

**MODIFICAR `place_order` (Linha 344):**
```python
async def place_order(self, symbol: str, side: str, qty: float, order_type: str = "Market", 
                     take_profit: float = None, stop_loss: float = None):
    """Coloca uma ordem na Bybit com TP/SL - COM VALIDAÇÃO DE PREÇO"""
    try:
        # ✨ V3.2.1 - Obter limites do símbolo
        instrument_info = await self.get_instrument_info(symbol)
        
        params = {
            "category": "linear",
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
            "qty": str(qty),
            "timeInForce": "GTC"
        }
        
        # ✨ V3.2.1 - Validar e ajustar TP/SL
        if take_profit and take_profit > 0:
            validated_tp = self.validate_price(take_profit, instrument_info)
            params["takeProfit"] = str(round(validated_tp, 2))
            
            if validated_tp != take_profit:
                self.logger.warning(f"TP ajustado: {take_profit:.2f} → {validated_tp:.2f}")
        
        if stop_loss and stop_loss > 0:
            validated_sl = self.validate_price(stop_loss, instrument_info)
            params["stopLoss"] = str(round(validated_sl, 2))
            
            if validated_sl != stop_loss:
                self.logger.warning(f"SL ajustado: {stop_loss:.2f} → {validated_sl:.2f}")
        
        # ... resto do código
```

---

## 📊 **LOGS ESPERADOS APÓS CORREÇÃO**

### **Testnet Congelada:**
```
[17:50:00] ⚠️ Nenhum kline para BTCUSDT 15m (tentativa 1/5)
[17:52:00] ⚠️ Nenhum kline para BTCUSDT 15m (tentativa 2/5)
[17:54:00] ⚠️ Nenhum kline para BTCUSDT 15m (tentativa 3/5)
[17:56:00] ⚠️ Nenhum kline para BTCUSDT 15m (tentativa 4/5)
[17:58:00] 🚨 TESTNET CONGELADA DETECTADA!
           BTCUSDT 15m falhou 5 vezes!
           RECOMENDAÇÃO: Use MAINNET ou aguarde
```

### **Preço Ajustado:**
```
[17:44:36] ⚠️ TP ajustado: 50.62 → 51.00 (minPrice)
[17:44:36] ✅ Ordem executada com sucesso
```

---

## ✅ **CHECKLIST DE CORREÇÃO**

### **Testnet Congelada:**
- [ ] Adicionar contador de falhas kline
- [ ] Alertar após 5 falhas consecutivas
- [ ] Sugerir mainnet ou aguardar
- [ ] Reset contador em sucesso

### **Validação de Preço:**
- [ ] Criar get_instrument_info()
- [ ] Criar validate_price()
- [ ] Modificar place_order() para validar
- [ ] Logar ajustes de preço

### **Testes:**
- [ ] Testar com testnet congelada
- [ ] Testar SHORT com TP baixo
- [ ] Testar LONG com SL alto
- [ ] Validar logs claros

---

## 🚀 **ALTERNATIVA IMEDIATA**

### **Use Mainnet Paper Mode:**

```json
{
  "api_key": "SUA_KEY_MAINNET",
  "api_secret": "SEU_SECRET_MAINNET",
  
  "testnet": false,
  "trading_mode": "paper",
  
  "comment": "Usa dados reais mas não executa"
}
```

**Vantagens:**
- ✅ Dados sempre atualizados
- ✅ Sem risco (paper mode)
- ✅ Testa com mercado real

---

## 📖 **REFERÊNCIAS**

**Bybit API:**
- Instruments Info: `/v5/market/instruments-info`
- Price Filters: `minPrice`, `maxPrice`, `tickSize`
- Error Code 30209: Price below minimum

**Testnet Status:**
- https://testnet.bybit.com
- https://bybit-exchange.github.io/docs/v5/rate-limit

---

**🚨 PROBLEMAS CRÍTICOS IDENTIFICADOS!**

**PRÓXIMOS PASSOS:**
1. Implementar correções acima
2. Ou usar mainnet paper mode
3. Testar validação de preços

**QUER QUE EU IMPLEMENTE AS CORREÇÕES AGORA?**
