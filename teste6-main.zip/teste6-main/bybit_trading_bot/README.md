# 🚀 Bybit Trading Bot V3.2.1

Bot de trading automático para Bybit com **Paper Mode completo**, tracking de PnL em tempo real e análise técnica avançada.

---

## ✨ **VERSÃO ATUAL: V3.2.1**

### **📝 Paper Trading Completo**
- 💰 **PnL em Tempo Real** - Veja lucros/perdas de cada trade
- 📊 **Resumo Automático** - Stats completas a cada 5 análises
- 💾 **Histórico Persistido** - Salva em `paper_trades.json`
- 🎯 **Validação Visual** - Saiba que está funcionando!

### **🎯 SL/TP Otimizados**
- 📈 **SL:** -5% a -7% (aguenta oscilações de mercado)
- 🎯 **TP:** +8% a +10% (lucros maiores)
- ⚖️ **R:R:** 1:2.00 (melhor retorno)
- 📊 **Win Rate esperado:** 45%+

### **🧹 Logs Limpos**
- 📊 **Console:** Só essencial (13 linhas vs 30+)
- 📁 **Arquivo:** Detalhes completos para debug
- 💰 **Fechamentos:** Logs claros de TP/SL atingidos

### **🛡️ Gestão de Risco**
- 💰 **Partial TP:** Fecha 50% em +2%
- 🛡️ **Break-Even:** Move SL para Entry em +1.5%
- 📉 **Trailing Stop:** Protege lucros automaticamente

### **📊 Logs Limpos e Profissionais**
- ✨ Logs **organizados** e fáceis de ler
- 🎯 Avisos **compactos** (sem poluição)
- 🔍 Fácil **debug** e monitoramento

### **🤖 Machine Learning Básico**
- 📈 Aprende com **trades passados**
- 🚫 Bloqueia **padrões ruins**
- 🎯 Ajusta **confiança** dinamicamente

### **🔍 Detecção de Problemas**
- 🧊 Detecta **testnet congelada** automaticamente
- ⏰ Monitora **dados estagnados**
- 📋 Scripts de **diagnóstico** inclusos

**📖 Ver:** `V3.0_CHANGELOG.md` para detalhes completos

## 🚀 Características

- ✅ Suporte a BTC, ETH, SOL
- ✅ Múltiplos timeframes (15m, 1h, 2h, 4h)
- ✅ Detecção de padrões: OCO, triângulos, bandeiras, retângulos, fundos duplos
- ✅ Indicadores: EMA, RSI, MACD, ATR, Volume
- ✅ Gestão de risco com TP/SL automático
- ✅ Trailing stop
- ✅ Backtesting completo
- ✅ Notificações Telegram
- ✅ Modo paper trading

## 📋 Pré-requisitos

- Python 3.10 ou superior
- Windows 64-bit (ou Linux/Mac)
- Conta Bybit Testnet

## 🔧 Instalação

### 1. Clone ou extraia o projeto

```bash
cd bybit_trading_bot
```

### 2. Crie ambiente virtual

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 3. Instale dependências

```bash
pip install -r requirements.txt
```

## 🔑 Configuração Bybit Testnet

### Obter API Keys

1. Acesse: https://testnet.bybit.com
2. Crie uma conta ou faça login
3. Vá em **API Management** → **Create New Key**
4. Marque permissões:
   - Read (Leitura)
   - Trade (Negociação)
   - Position (Posição)
5. Copie **API Key** e **Secret Key**

### Configurar config.json

Edite `config.json`:

```json
{
  "api_key": "SUA_API_KEY_AQUI",
  "api_secret": "SUA_SECRET_KEY_AQUI",
  "testnet": true,
  ...
}
```

## 🎮 Como Usar

### Modo Paper Trading (Simulação)

```bash
# Windows
run_local.bat

# Linux/Mac
./start.sh
```

O bot iniciará em modo paper por padrão (não envia ordens reais).

### Modo Testnet (Ordens Reais no Testnet)

Edite `config.json`:

```json
"trading_mode": "testnet"
```

Depois execute:

```bash
python -m src.runner
```

### Backtesting

```bash
python -m src.backtester --symbol BTCUSDT --days 30
```

## 🧪 Testes

```bash
pytest tests/ -v
```

## 📊 Estrutura do Projeto

```
bybit_trading_bot/
├── config.json          # Configurações
├── requirements.txt     # Dependências
├── README.md           # Este arquivo
├── run_local.bat       # Iniciar (Windows)
├── start.sh            # Iniciar (Linux/Mac)
├── src/
│   ├── exchange.py          # API Bybit
│   ├── strategy.py          # Estratégia principal
│   ├── pattern_detector.py  # Padrões gráficos
│   ├── indicators.py        # Indicadores técnicos
│   ├── risk.py             # Gestão de risco
│   ├── runner.py           # Loop principal
│   ├── backtester.py       # Backtesting
│   ├── telegram_bot.py     # Notificações
│   └── utils.py            # Utilidades
├── tests/              # Testes unitários
└── logs/              # Logs do bot
```

## 📈 Estratégia de Trading

### Detecção de Padrões

- Ombro-Cabeça-Ombro (OCO)
- Triângulos (ascendente, descendente, simétrico)
- Bandeiras e flâmulas
- Retângulos
- Fundos/topos duplos
- Rompimentos de suporte/resistência

### Indicadores

- **EMA 9/21/50**: Tendência
- **RSI (14)**: Sobrecompra/sobrevenda
- **MACD**: Momentum
- **ATR (14)**: Volatilidade para SL
- **Volume/VWAP**: Confirmação

### Regras de Entrada

Um sinal é válido quando:
1. Padrão gráfico detectado (confiança > 70%)
2. Confirmação de 2+ indicadores
3. Volume acima da média
4. Consenso entre múltiplos timeframes

### Gestão de Risco

- **Position Size**: 1% do capital por trade
- **Take Profit**: 3% (padrão)
- **Stop Loss**: 1.5% ou 2x ATR
- **Trailing Stop**: Opcional
- **Max Loss Diário**: 5%

## ⚙️ Configurações Avançadas

### Ajustar Alavancagem

```json
"leverage": 3  // 3x a 10x recomendado
```

### Trailing Stop

```json
"strategy": {
  "use_trailing_stop": true,
  "trailing_stop_pct": 1.0
}
```

### Notificações Telegram

1. Crie um bot: https://t.me/BotFather
2. Obtenha o token
3. Obtenha seu chat_id: https://t.me/userinfobot

```json
"telegram": {
  "enabled": true,
  "token": "SEU_TOKEN",
  "chat_id": "SEU_CHAT_ID"
}
```

## 🛡️ Segurança

### Kill Switch

Pressione `Ctrl+C` ou crie arquivo `STOP`:

```bash
echo "stop" > STOP
```

O bot fechará todas as posições e encerrará.

### Limites de Perda

O bot para automaticamente se:
- Perda diária > 5%
- Perda por posição > 3%

## 📊 Logs

Logs são salvos em:
- `logs/trading_YYYYMMDD.log`
- Console (stdout)

Níveis:
- INFO: Operações normais
- WARNING: Alertas
- ERROR: Erros críticos

## ⚠️ Avisos Importantes

### ⚠️ RISCOS

- Trading algorítmico envolve **RISCO REAL DE PERDA**
- Teste SEMPRE em testnet primeiro
- Use apenas capital que pode perder
- Não há garantia de lucro
- Volatilidade pode causar perdas rápidas

### 🚫 Limitações

- Depende de conexão estável
- APIs podem ter rate limits
- Padrões gráficos não são 100% precisos
- Slippage pode afetar resultados
- Eventos de cisne negro não são previstos

### ✅ Recomendações

1. Comece com **paper trading**
2. Teste no **testnet** por semanas
3. Use **alavancagem baixa** (3x-5x)
4. Monitore diariamente
5. Ajuste parâmetros gradualmente
6. Mantenha logs e analise resultados

## 🐛 Troubleshooting

### Erro: "Invalid API Key"

- Verifique se copiou corretamente
- Confirme que está usando keys do testnet
- Verifique permissões da API

### Erro: "Insufficient balance"

- Deposite USDT no testnet
- Use o faucet: https://testnet.bybit.com/app/user/assets/home

### Bot não detecta padrões

- Aumente dados históricos
- Reduza `min_pattern_confidence`
- Verifique se há dados suficientes

## 📞 Suporte

- Documentação Bybit: https://bybit-exchange.github.io/docs/
- Issues: Crie uma issue no repositório
- Testnet: https://testnet.bybit.com

## 📄 Licença

Apenas para uso educacional e em testnet. Use por sua conta e risco.

---

**⚠️ AVISO LEGAL**: Este software é fornecido "como está". O autor não se responsabiliza por perdas financeiras. Trading envolve risco.