@echo off
echo Iniciando Bybit Trading Bot (Paper Mode)...
python -m src.runner
pause