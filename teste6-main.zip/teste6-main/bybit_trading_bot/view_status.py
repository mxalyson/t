#!/usr/bin/env python3
"""
📊 VIEW STATUS - Visualiza PnL e Posições Abertas
Execute a qualquer momento: python view_status.py
"""

import json
import os
from datetime import datetime
from colorama import Fore, Style, init

# Inicializar colorama
init(autoreset=True)

def load_paper_trades():
    """Carrega dados do paper trading"""
    trades_file = "paper_trades.json"
    
    if not os.path.exists(trades_file):
        print(f"{Fore.RED}❌ Nenhum histórico encontrado. O bot ainda não operou em paper mode.{Style.RESET_ALL}")
        return None
    
    try:
        with open(trades_file, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"{Fore.RED}❌ Erro ao carregar dados: {e}{Style.RESET_ALL}")
        return None

def format_pnl(pnl):
    """Formata PnL com cores"""
    if pnl >= 0:
        return f"{Fore.GREEN}+${pnl:.2f}{Style.RESET_ALL}"
    else:
        return f"{Fore.RED}${pnl:.2f}{Style.RESET_ALL}"

def format_pnl_pct(pnl_pct):
    """Formata PnL % com cores"""
    if pnl_pct >= 0:
        return f"{Fore.GREEN}+{pnl_pct:.2f}%{Style.RESET_ALL}"
    else:
        return f"{Fore.RED}{pnl_pct:.2f}%{Style.RESET_ALL}"

def print_positions(positions):
    """Mostra posições abertas"""
    if not positions:
        print(f"\n{Fore.YELLOW}📭 Nenhuma posição aberta no momento{Style.RESET_ALL}")
        return
    
    print(f"\n{Fore.CYAN}{'='*80}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}📈 POSIÇÕES ABERTAS{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'='*80}{Style.RESET_ALL}")
    
    for symbol, pos in positions.items():
        side_emoji = "🟢" if pos['side'] == 'Buy' else "🔴"
        side_color = Fore.GREEN if pos['side'] == 'Buy' else Fore.RED
        
        # Calcular PnL atual
        entry = pos['entry_price']
        current = pos.get('current_price', entry)
        qty = pos['quantity']
        
        if pos['side'] == 'Buy':
            pnl = (current - entry) * qty
            pnl_pct = ((current - entry) / entry) * 100
        else:
            pnl = (entry - current) * qty
            pnl_pct = ((entry - current) / entry) * 100
        
        # ✨ V3.3.7 - Calcular impacto real com alavancagem
        leverage = 5
        tp_price_dist = abs(pos['take_profit'] - current) / current * 100
        sl_price_dist = abs(pos['stop_loss'] - current) / current * 100
        
        # Impacto no PnL (com alavancagem)
        tp_pnl_impact = tp_price_dist * leverage
        sl_pnl_impact = sl_price_dist * leverage
        
        # Determinar sinais (+/-)
        is_long = pos['side'] == 'Buy'
        tp_sign = "+" if ((is_long and pos['take_profit'] > current) or (not is_long and pos['take_profit'] < current)) else "-"
        sl_sign = "-" if ((is_long and pos['stop_loss'] < current) or (not is_long and pos['stop_loss'] > current)) else "+"
        
        print(f"\n{side_emoji} {Fore.WHITE}{symbol}{Style.RESET_ALL} - {side_color}{pos['side'].upper()}{Style.RESET_ALL}")
        print(f"   Entry:       ${entry:,.2f}")
        print(f"   Current:     ${current:,.2f}")
        print(f"   PnL:         {format_pnl(pnl)} ({format_pnl_pct(pnl_pct)})")
        print(f"   Quantity:    {qty}")
        
        # margin_used pode não existir em posições antigas
        margin = pos.get('margin_used', pos.get('margin', 0))
        if margin > 0:
            print(f"   Margin:      ${margin:.2f}")
        
        print(f"   Take Profit: ${pos['take_profit']:,.2f} ({tp_sign}{tp_pnl_impact:.1f}% PnL)")
        print(f"   Stop Loss:   ${pos['stop_loss']:,.2f} ({sl_sign}{sl_pnl_impact:.1f}% PnL)")
        print(f"   Pattern:     {pos.get('pattern', 'N/A')}")
        print(f"   Opened:      {pos.get('timestamp', 'N/A')}")

def print_stats(data):
    """Mostra estatísticas gerais"""
    balance = data.get('balance', 10000)
    initial = data.get('initial_balance', 10000)
    closed = data.get('closed_trades', [])
    
    # Calcular stats
    total_pnl = balance - initial
    total_pnl_pct = (total_pnl / initial) * 100
    
    wins = sum(1 for t in closed if t.get('pnl', 0) > 0)
    losses = sum(1 for t in closed if t.get('pnl', 0) <= 0)
    total_trades = len(closed)
    win_rate = (wins / total_trades * 100) if total_trades > 0 else 0
    
    # PnL dos trades fechados
    closed_pnl = sum(t.get('pnl', 0) for t in closed)
    
    # Melhores e piores
    if closed:
        best_trade = max(closed, key=lambda x: x.get('pnl', 0))
        worst_trade = min(closed, key=lambda x: x.get('pnl', 0))
    else:
        best_trade = worst_trade = None
    
    print(f"\n{Fore.CYAN}{'='*80}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}💰 RESUMO GERAL - PAPER TRADING{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'='*80}{Style.RESET_ALL}")
    
    print(f"\n{Fore.WHITE}SALDO:{Style.RESET_ALL}")
    print(f"   Inicial:     ${initial:,.2f}")
    print(f"   Atual:       ${balance:,.2f}")
    print(f"   PnL Total:   {format_pnl(total_pnl)} ({format_pnl_pct(total_pnl_pct)})")
    
    print(f"\n{Fore.WHITE}TRADES:{Style.RESET_ALL}")
    print(f"   Total:       {total_trades}")
    print(f"   Wins:        {Fore.GREEN}{wins}{Style.RESET_ALL}")
    print(f"   Losses:      {Fore.RED}{losses}{Style.RESET_ALL}")
    print(f"   Win Rate:    {Fore.CYAN}{win_rate:.1f}%{Style.RESET_ALL}")
    
    if closed:
        avg_win = sum(t['pnl'] for t in closed if t['pnl'] > 0) / wins if wins > 0 else 0
        avg_loss = sum(t['pnl'] for t in closed if t['pnl'] <= 0) / losses if losses > 0 else 0
        
        print(f"\n{Fore.WHITE}PERFORMANCE:{Style.RESET_ALL}")
        print(f"   Melhor:      {format_pnl(best_trade['pnl'])} ({best_trade['symbol']})")
        print(f"   Pior:        {format_pnl(worst_trade['pnl'])} ({worst_trade['symbol']})")
        print(f"   Média Win:   {format_pnl(avg_win)}")
        print(f"   Média Loss:  {format_pnl(avg_loss)}")

def print_recent_trades(closed_trades, limit=5):
    """Mostra últimos trades fechados"""
    if not closed_trades:
        return
    
    print(f"\n{Fore.CYAN}{'='*80}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}📜 ÚLTIMOS {limit} TRADES FECHADOS{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'='*80}{Style.RESET_ALL}")
    
    recent = sorted(closed_trades, key=lambda x: x.get('close_timestamp', ''), reverse=True)[:limit]
    
    for trade in recent:
        pnl = trade.get('pnl', 0)
        pnl_pct = trade.get('pnl_pct', 0)
        symbol = trade['symbol']
        side = trade['side']
        reason = trade.get('reason', 'Unknown')
        
        side_emoji = "🟢" if side == 'Buy' else "🔴"
        side_color = Fore.GREEN if side == 'Buy' else Fore.RED
        
        result_emoji = "✅" if pnl > 0 else "❌"
        
        print(f"\n{result_emoji} {side_emoji} {Fore.WHITE}{symbol}{Style.RESET_ALL} {side_color}{side}{Style.RESET_ALL}")
        print(f"   Entry:  ${trade['entry_price']:,.2f}")
        print(f"   Exit:   ${trade['exit_price']:,.2f}")
        print(f"   PnL:    {format_pnl(pnl)} ({format_pnl_pct(pnl_pct)})")
        print(f"   Reason: {reason}")
        print(f"   Closed: {trade.get('close_timestamp', 'N/A')}")

def main():
    """Função principal"""
    print(f"\n{Fore.YELLOW}{'='*80}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}📊 BYBIT TRADING BOT - STATUS PAPER TRADING{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}{'='*80}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}⏰ Atualizado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Style.RESET_ALL}")
    
    data = load_paper_trades()
    if not data:
        return
    
    # Mostrar estatísticas gerais
    print_stats(data)
    
    # Mostrar posições abertas (com alavancagem 5x)
    positions = data.get('positions', {})
    print_positions(positions, leverage=5)
    
    # Mostrar últimos trades
    closed_trades = data.get('closed_trades', [])
    print_recent_trades(closed_trades, limit=5)
    
    print(f"\n{Fore.YELLOW}{'='*80}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}✅ Para atualizar, execute novamente: python view_status.py{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}{'='*80}{Style.RESET_ALL}\n")

if __name__ == "__main__":
    main()
