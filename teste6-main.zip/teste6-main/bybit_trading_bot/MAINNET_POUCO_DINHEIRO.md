# 💰 Como Usar na MAINNET com Pouco Dinheiro

## 📋 **IMPORTANTE: LEIA ANTES DE ATIVAR MAINNET!**

⚠️ **MAINNET = DINHEIRO REAL!**
- ❌ Testnet: Dinheiro falso (seguro)
- ✅ Mainnet: Dinheiro real (RISCO!)

---

## 💵 **QUANTO PRECISO?**

### **Cálculo Mínimo:**

```
Margem mínima por trade = Capital × position_size_pct × leverage
```

**Com config padrão:**
- `position_size_pct: 1.0%`
- `leverage: 5x`
- `max_total_open_trades: 3`

**CAPITAL MÍNIMO:**

| Capital | Margem/Trade | Trades Simultâneos | Total Usado |
|---------|--------------|-------------------|-------------|
| $100 | $1 | 3 | $3 (3%) |
| $200 | $2 | 3 | $6 (3%) |
| $500 | $5 | 3 | $15 (3%) |
| $1,000 | $10 | 3 | $30 (3%) ✅ |
| $2,000 | $20 | 3 | $60 (3%) ✅ |

**RECOMENDADO:**
- **Mínimo absoluto:** $500 USDT
- **Confortável:** $1,000+ USDT
- **Ideal:** $2,000+ USDT

---

## ⚙️ **CONFIGURAÇÃO PARA POUCO CAPITAL**

### **1. Para $500 - $1,000 (Conservador)**

**config.json:**
```json
{
  "trading_mode": "live",
  "testnet": false,
  
  "leverage": 3,
  "position_size_pct": 0.5,
  "max_total_open_trades": 2,
  
  "default_tp_pct": 8.0,
  "default_sl_pct": 5.0,
  
  "min_trade_confidence": 0.60,
  
  "risk": {
    "max_daily_loss_pct": 3.0,
    "max_position_loss_pct": 5.0
  }
}
```

**Explicação:**
- `leverage: 3` - Alavancagem menor = menos risco
- `position_size_pct: 0.5` - Usa só 0.5% por trade
- `max_total_open_trades: 2` - Máximo 2 trades simultâneos
- `min_trade_confidence: 0.60` - Mais seletivo (60% confiança)
- `max_daily_loss_pct: 3.0` - Para em -3% de perda diária

**Com $1,000:**
- Margem/trade: $1,000 × 0.5% × 3 = $15
- 2 trades simultâneos: $30 total (3%)
- Perda máxima/trade: $1,000 × 5% = $50
- Perda máxima/dia: $1,000 × 3% = $30

---

### **2. Para $1,000 - $2,000 (Moderado)**

**config.json:**
```json
{
  "trading_mode": "live",
  "testnet": false,
  
  "leverage": 5,
  "position_size_pct": 0.8,
  "max_total_open_trades": 2,
  
  "default_tp_pct": 8.0,
  "default_sl_pct": 5.0,
  
  "min_trade_confidence": 0.58,
  
  "risk": {
    "max_daily_loss_pct": 4.0,
    "max_position_loss_pct": 5.0
  }
}
```

**Com $2,000:**
- Margem/trade: $2,000 × 0.8% × 5 = $80
- 2 trades simultâneos: $160 total (8%)
- Perda máxima/trade: $2,000 × 5% = $100
- Perda máxima/dia: $2,000 × 4% = $80

---

### **3. Para $2,000+ (Padrão)**

**config.json:**
```json
{
  "trading_mode": "live",
  "testnet": false,
  
  "leverage": 5,
  "position_size_pct": 1.0,
  "max_total_open_trades": 3,
  
  "default_tp_pct": 8.0,
  "default_sl_pct": 5.0,
  
  "min_trade_confidence": 0.55,
  
  "risk": {
    "max_daily_loss_pct": 5.0,
    "max_position_loss_pct": 5.0
  }
}
```

**Com $3,000:**
- Margem/trade: $3,000 × 1% × 5 = $150
- 3 trades simultâneos: $450 total (15%)
- Perda máxima/trade: $3,000 × 5% = $150
- Perda máxima/dia: $3,000 × 5% = $150

---

## 🔑 **COMO ATIVAR MAINNET**

### **Passo 1: Criar API Keys na Bybit**

1. **Login na Bybit:** https://www.bybit.com
2. **API Management:**
   - Perfil → API → Create New Key
   - Tipo: **API Transaction**
3. **Permissões (IMPORTANTE!):**
   - ✅ **Contract: Trade**
   - ✅ **Contract: Position**
   - ✅ **Contract: Order**
   - ✅ **Wallet: Read**
   - ❌ **Wallet: Transfer** (DESATIVADO!)
   - ❌ **Wallet: Withdraw** (DESATIVADO!)
4. **IP Whitelist:**
   - Adicione seu IP (mais seguro)
   - Ou deixe vazio (menos seguro)
5. **Copie:**
   - API Key
   - API Secret

---

### **Passo 2: Editar config.json**

**ANTES (Testnet):**
```json
{
  "api_key": "YHwt45TQx8LhFAGZLn",
  "api_secret": "WcWMWiBTyBigLMQdIeS6...",
  "testnet": true,
  "trading_mode": "testnet"
}
```

**DEPOIS (Mainnet):**
```json
{
  "api_key": "SUA_API_KEY_MAINNET_AQUI",
  "api_secret": "SEU_API_SECRET_MAINNET_AQUI",
  "testnet": false,
  "trading_mode": "live",
  
  "position_size_pct": 0.5,
  "leverage": 3,
  "max_total_open_trades": 2,
  "min_trade_confidence": 0.60
}
```

⚠️ **ATENÇÃO:**
- Use suas **NOVAS** API Keys da mainnet!
- `testnet: false` - Obrigatório!
- `trading_mode: "live"` - Obrigatório!

---

### **Passo 3: Depositar USDT**

1. **Depósito mínimo:** $500 USDT
2. **Recomendado:** $1,000+ USDT
3. **Carteira:** Unified Trading Account
4. **Moeda:** USDT

---

### **Passo 4: Testar com 1 Símbolo Primeiro**

**config.json inicial:**
```json
{
  "symbols": ["BTCUSDT"],
  "max_total_open_trades": 1,
  "position_size_pct": 0.3
}
```

**Teste 5-10 trades antes de expandir!**

---

### **Passo 5: Executar**

```bash
python -m src.runner
```

**Logs esperados:**
```
[14:00:00] ✅ Conexão com Bybit estabelecida
[14:00:01] ✅   ✓ BTCUSDT: 3x (MAINNET!)
[14:00:02] ✅ Saldo disponível: 1000.00 USDT

🚀 BOT INICIADO - MAINNET ATIVO ⚠️
```

---

## 📊 **EXPECTATIVAS REALISTAS**

### **Com $1,000 Capital:**

**Conservador (0.5% position):**
```
Trades/dia: 2-3
Win rate: 45%
Avg win: +$40
Avg loss: -$25
Lucro esperado/mês: +$120 - $180 (+12-18%)
```

**Moderado (0.8% position):**
```
Trades/dia: 3-4
Win rate: 45%
Avg win: +$65
Avg loss: -$40
Lucro esperado/mês: +$200 - $300 (+20-30%)
```

---

## ⚠️ **RISCOS**

### **1. Perda de Capital** ❌
- Você pode perder TUDO!
- Só invista o que pode perder
- SL nem sempre funciona (gaps, slippage)

### **2. Volatilidade** 📉
- Cripto é MUITO volátil
- Perdas de -5% em 1 dia são normais
- Pode ter 5 perdas seguidas

### **3. Bugs** 🐛
- Bot pode ter bugs
- Testar MUITO no testnet antes!
- Sempre monitore manualmente

### **4. Exchange** 🏦
- Bybit pode cair
- Funding rates negativos
- Liquidações em cascata

---

## 🛡️ **PROTEÇÕES**

### **1. Stop Loss Automático**
```json
"default_sl_pct": 5.0
```
- Limita perda a -5% por trade
- Bybit fecha automaticamente

### **2. Max Daily Loss**
```json
"max_daily_loss_pct": 3.0
```
- Bot para se perder -3% no dia
- Protege de sequências de perdas

### **3. Max Trades Simultâneos**
```json
"max_total_open_trades": 2
```
- Máximo 2 trades ao mesmo tempo
- Reduz exposição

### **4. Confiança Mínima**
```json
"min_trade_confidence": 0.60
```
- Só entra em sinais de 60%+
- Filtra trades fracos

---

## 📋 **CHECKLIST ANTES DE ATIVAR MAINNET**

### **Testnet:**
- [ ] Testei por 7+ dias no testnet
- [ ] Win rate > 40%
- [ ] Entendi como funciona
- [ ] Testei partial TP e break-even
- [ ] Bot não trava

### **Configuração:**
- [ ] API Keys da MAINNET criadas
- [ ] Permissões corretas (sem withdraw!)
- [ ] `testnet: false`
- [ ] `trading_mode: "live"`
- [ ] `position_size_pct` ajustado para capital
- [ ] `leverage` conservador (3-5x)
- [ ] `max_daily_loss_pct` configurado

### **Capital:**
- [ ] Depositei $500+ USDT
- [ ] É dinheiro que POSSO PERDER
- [ ] Não é minha reserva de emergência
- [ ] Não é dinheiro emprestado

### **Monitoramento:**
- [ ] Vou monitorar diariamente
- [ ] Tenho acesso ao Bybit app
- [ ] Sei como fechar posições manualmente
- [ ] Tenho plano B se bot falhar

---

## 🚀 **EXEMPLO: COMEÇANDO COM $1,000**

### **Dia 1: Setup**
```json
{
  "symbols": ["BTCUSDT"],
  "leverage": 3,
  "position_size_pct": 0.5,
  "max_total_open_trades": 1,
  "min_trade_confidence": 0.65
}
```

**Resultado esperado:**
- 1-2 trades
- Margem: $15/trade
- Lucro/perda: -$25 a +$40

---

### **Semana 1: Observar**
- ✅ Win rate > 40%?
- ✅ Bot funcionando?
- ✅ Sem bugs?

**Se SIM:**
```json
{
  "symbols": ["BTCUSDT", "ETHUSDT"],
  "max_total_open_trades": 2
}
```

---

### **Semana 2-4: Expandir**
- ✅ Tudo ok na semana 1?
- ✅ Lucro líquido?

**Se SIM:**
```json
{
  "symbols": ["BTCUSDT", "ETHUSDT"],
  "position_size_pct": 0.8,
  "max_total_open_trades": 2,
  "min_trade_confidence": 0.58
}
```

---

### **Mês 2+: Otimizar**
- Ajustar `min_trade_confidence`
- Adicionar SOLUSDT
- Aumentar `position_size_pct` gradualmente

---

## 💡 **DICAS**

### **1. Comece PEQUENO**
- Primeiro trade: 0.3% do capital
- Observe 5 trades
- Aumente gradualmente

### **2. Monitore DIARIAMENTE**
- Check saldo todo dia
- Veja trades fechados
- Ajuste se necessário

### **3. Tenha PACIÊNCIA**
- Lucros consistentes > lucros rápidos
- 10-20% ao mês é ÓTIMO
- Não force trades

### **4. STOP Loss**
- Se perder 10% do capital: PARE!
- Revise estratégia
- Volte para testnet

### **5. Reinvestimento**
- Lucrou? Retire 50%
- Reinvista 50%
- Proteja seu capital inicial

---

## 📊 **SIMULAÇÃO: $1,000 POR 3 MESES**

### **Cenário Conservador:**
```
Capital inicial: $1,000
Position size: 0.5%
Trades/dia: 2
Win rate: 40%

Mês 1: +$120 → $1,120
Mês 2: +$135 → $1,255
Mês 3: +$150 → $1,405

Lucro total: +$405 (+40.5%)
```

### **Cenário Realista:**
```
Capital inicial: $1,000
Position size: 0.5%
Trades/dia: 2-3
Win rate: 45%

Mês 1: +$180 → $1,180
Mês 2: +$210 → $1,390
Mês 3: +$250 → $1,640

Lucro total: +$640 (+64%)
```

### **Cenário Pessimista:**
```
Capital inicial: $1,000
Position size: 0.5%
Trades/dia: 2
Win rate: 30%

Mês 1: -$80 → $920
Mês 2: +$40 → $960
Mês 3: -$60 → $900

Perda total: -$100 (-10%)
```

---

## ❌ **QUANDO NÃO USAR MAINNET**

- ❌ Não testou 7+ dias no testnet
- ❌ Win rate < 35% no testnet
- ❌ Não entende como funciona
- ❌ Não pode perder o dinheiro
- ❌ Não vai monitorar diariamente
- ❌ Usa dinheiro emprestado
- ❌ É sua reserva de emergência

---

## ✅ **RESUMO**

### **Capital Mínimo:**
- **Absoluto:** $500 USDT
- **Confortável:** $1,000 USDT
- **Ideal:** $2,000+ USDT

### **Config Conservadora:**
```json
{
  "testnet": false,
  "trading_mode": "live",
  "leverage": 3,
  "position_size_pct": 0.5,
  "max_total_open_trades": 2,
  "min_trade_confidence": 0.60
}
```

### **Expectativa:**
- Win rate: 40-50%
- Lucro mensal: 10-25%
- Perdas possíveis: -5% a -15%

### **Checklist:**
1. [x] Testei 7+ dias
2. [x] API Keys mainnet
3. [x] Config ajustado
4. [x] Capital depositado
5. [x] Monitoramento diário

---

**⚠️ LEMBRE-SE: BOT NÃO É GARANTIA DE LUCRO!**

**VOCÊ PODE PERDER TODO O CAPITAL!**

**SÓ INVISTA O QUE PODE PERDER!**

---

## 📞 **SUPORTE**

- 📄 Leia: `V3.2_CHANGELOG.md`
- 🐛 Bugs: Crie issue no GitHub
- ❓ Dúvidas: Leia documentação completa

**BOA SORTE E TRADE COM RESPONSABILIDADE!** 🚀
